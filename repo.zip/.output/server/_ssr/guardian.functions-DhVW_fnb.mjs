import { c as createServerRpc } from "./createServerRpc--OrbljSy.mjs";
import { c as createServerFn } from "./server-g-lQHb1O.mjs";
import { r as requireSupabaseAuth } from "./auth-middleware-B5YcFrfv.mjs";

import "../_libs/seroval.mjs";
import "../_libs/react.mjs";
import { a as objectType, y as stringType } from "../_libs/zod.mjs";

import "../_libs/h3-v2.mjs";
import "../_libs/unenv.mjs";


import "../_libs/rou3.mjs";
import "../_libs/srvx.mjs";





import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval-plugins.mjs";

import "../_libs/tanstack__react-router.mjs";
import "../_libs/react-dom.mjs";
import "../_libs/isbot.mjs";
import "../_libs/supabase__supabase-js.mjs";
import "../_libs/supabase__postgrest-js.mjs";
import "../_libs/supabase__realtime-js.mjs";
import "../_libs/supabase__phoenix.mjs";
import "../_libs/supabase__storage-js.mjs";
import "../_libs/iceberg-js.mjs";
import "../_libs/supabase__auth-js.mjs";
import "../_libs/tslib.mjs";
import "../_libs/supabase__functions-js.mjs";
const SITE_NAME = "BODYFUEL";
const SENDER_DOMAIN = "notify.bodyfuel-coaching.com";
const FROM_DOMAIN = "bodyfuel-coaching.com";
const APP_URL = "https://bodyfuel-coaching.com";
const startGuardianConsent_createServerFn_handler = createServerRpc({
  id: "d277acad6be5f1f45ce1e8d9d17ccbb7dc763308137f9713b2e13a2dfe13dca7",
  name: "startGuardianConsent",
  filename: "src/lib/guardian.functions.ts"
}, (opts) => startGuardianConsent.__executeServer(opts));
const startGuardianConsent = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((data) => {
  return objectType({
    birthdate: stringType().regex(/^\d{4}-\d{2}-\d{2}$/),
    guardianName: stringType().trim().min(2).max(120).optional(),
    guardianEmail: stringType().trim().email().max(255).transform((s) => s.toLowerCase()).optional(),
    minorName: stringType().trim().max(120).optional()
  }).parse(data);
}).handler(startGuardianConsent_createServerFn_handler, async ({
  data,
  context
}) => {
  const {
    supabaseAdmin
  } = await import("./client.server-D5ro3rAQ.mjs");
  const userId = context.userId;
  const today = /* @__PURE__ */ new Date();
  const dob = new Date(data.birthdate);
  const age = Math.floor((today.getTime() - dob.getTime()) / (365.25 * 24 * 3600 * 1e3));
  const isMinor = age < 18;
  if (!isMinor) {
    await supabaseAdmin.from("profiles").update({
      birthdate: data.birthdate,
      is_minor: false,
      requires_guardian_consent: false,
      account_status: "active"
    }).eq("id", userId);
    return {
      ok: true,
      isMinor: false
    };
  }
  if (!data.guardianName || !data.guardianEmail) {
    return {
      ok: false,
      isMinor: true,
      error: "Eltern-Daten fehlen"
    };
  }
  await supabaseAdmin.from("profiles").update({
    birthdate: data.birthdate,
    is_minor: true,
    requires_guardian_consent: true,
    guardian_name: data.guardianName,
    guardian_email: data.guardianEmail,
    account_status: "pending_guardian_consent"
  }).eq("id", userId);
  const {
    data: token,
    error: tErr
  } = await supabaseAdmin.from("guardian_consent_tokens").insert({
    user_id: userId,
    guardian_email: data.guardianEmail,
    guardian_name: data.guardianName
  }).select("token").single();
  if (tErr || !token) {
    return {
      ok: false,
      isMinor: true,
      error: tErr?.message ?? "Token-Erstellung fehlgeschlagen"
    };
  }
  const {
    data: prof
  } = await supabaseAdmin.from("profiles").select("display_name").eq("id", userId).maybeSingle();
  const minorName = data.minorName ?? prof?.display_name ?? "Ihr Kind";
  const {
    TEMPLATES
  } = await import("./registry-BHGsuy94.mjs");
  const React = await import("../_libs/react.mjs").then(function(n) {
    return n.R;
  });
  const {
    render
  } = await import("../_libs/react-email__components.mjs");
  const tpl = TEMPLATES["guardian-consent"];
  if (!tpl) return {
    ok: false,
    isMinor: true,
    error: "Template fehlt"
  };
  const consentUrl = `${APP_URL}/guardian-consent?token=${token.token}`;
  const payload = {
    minorName,
    guardianName: data.guardianName,
    consentUrl,
    siteName: SITE_NAME
  };
  const element = React.createElement(tpl.component, payload);
  const html = await render(element);
  const text = await render(element, {
    plainText: true
  });
  const subject = typeof tpl.subject === "function" ? tpl.subject(payload) : tpl.subject;
  const idempotencyKey = `guardian-consent:${userId}:${token.token}`;
  await supabaseAdmin.from("email_send_log").insert({
    message_id: idempotencyKey,
    template_name: "guardian-consent",
    recipient_email: data.guardianEmail,
    status: "pending"
  });
  await supabaseAdmin.rpc("enqueue_email", {
    queue_name: "transactional_emails",
    payload: {
      message_id: idempotencyKey,
      to: data.guardianEmail,
      from: `${SITE_NAME} <noreply@${FROM_DOMAIN}>`,
      sender_domain: SENDER_DOMAIN,
      subject,
      html,
      text,
      purpose: "transactional",
      label: "guardian-consent",
      idempotency_key: idempotencyKey,
      queued_at: (/* @__PURE__ */ new Date()).toISOString()
    }
  });
  return {
    ok: true,
    isMinor: true
  };
});
const resendGuardianConsent_createServerFn_handler = createServerRpc({
  id: "87547215637504640201735b1bb8ea87141fa8b4ae48a16562655c65de621478",
  name: "resendGuardianConsent",
  filename: "src/lib/guardian.functions.ts"
}, (opts) => resendGuardianConsent.__executeServer(opts));
const resendGuardianConsent = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).handler(resendGuardianConsent_createServerFn_handler, async ({
  context
}) => {
  const {
    supabaseAdmin
  } = await import("./client.server-D5ro3rAQ.mjs");
  const userId = context.userId;
  const {
    data: prof
  } = await supabaseAdmin.from("profiles").select("birthdate, guardian_name, guardian_email, display_name").eq("id", userId).maybeSingle();
  if (!prof?.guardian_email || !prof?.guardian_name || !prof?.birthdate) {
    return {
      ok: false,
      error: "Keine Eltern-Daten hinterlegt"
    };
  }
  return await startGuardianConsent({
    data: {
      birthdate: prof.birthdate,
      guardianName: prof.guardian_name,
      guardianEmail: prof.guardian_email,
      minorName: prof.display_name ?? void 0
    }
  });
});
const getMyGuardianStatus_createServerFn_handler = createServerRpc({
  id: "7d491ca1d81443cdf9659fbe558f4a190f6f3b118fb9f9da4ea3b5000149ddf1",
  name: "getMyGuardianStatus",
  filename: "src/lib/guardian.functions.ts"
}, (opts) => getMyGuardianStatus.__executeServer(opts));
const getMyGuardianStatus = createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).handler(getMyGuardianStatus_createServerFn_handler, async ({
  context
}) => {
  const {
    supabase,
    userId
  } = context;
  const {
    data
  } = await supabase.from("profiles").select("birthdate, is_minor, requires_guardian_consent, guardian_name, guardian_email, guardian_consent_at, guardian_consent_docs, account_status").eq("id", userId).maybeSingle();
  return data;
});
export {
  getMyGuardianStatus_createServerFn_handler,
  resendGuardianConsent_createServerFn_handler,
  startGuardianConsent_createServerFn_handler
};
