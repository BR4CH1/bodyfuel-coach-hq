import { j as jsxRuntimeExports, r as reactExports } from "../_libs/react.mjs";
import { L as Link } from "../_libs/tanstack__react-router.mjs";
import { a as useServerFn, u as useSession } from "./router-BmNvgrMe.mjs";
import { A as AppLayout } from "./AppLayout-lnbnJZfJ.mjs";
import { B as BullsGate } from "./BullsGate-B_ZXGn5k.mjs";
import { B as BullsHero } from "./BullsHero-CHHpC12P.mjs";
import { T as TrialTrainingPlan, P as PlanContentView } from "./TrialPlanView-DR4QuuIf.mjs";
import { L as LivePlanBanner, T as TrainingTracker } from "./LivePlanBanner-CW_PVgtM.mjs";
import { A as AthleteProfileBanner } from "./AthleteProfileBanner-Ci0pHs8O.mjs";
import { B as BullsAthleteAthleticSession } from "./BullsAthleteAthleticSession-CzbGEHtH.mjs";
import { u as useTrial } from "./use-trial-Bz4g3KMx.mjs";
import { t as trackHubEvent } from "./bulls.functions-VCy1qC3v.mjs";
import "../_libs/sonner.mjs";
import "../_libs/idb.mjs";

import "../_libs/seroval.mjs";
import "../_libs/unenv.mjs";

import "../_libs/lovable.dev__mcp-js.mjs";
import "../_libs/modelcontextprotocol__sdk.mjs";
import "../_libs/zod-to-json-schema.mjs";
import "../_libs/ajv-formats.mjs";
import "../_libs/stripe.mjs";
import { aD as ArrowLeft, A as Activity, a as ChartColumn, p as Sparkles } from "../_libs/lucide-react.mjs";
import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval-plugins.mjs";


import "../_libs/react-dom.mjs";
import "../_libs/isbot.mjs";
import "../_libs/tanstack__query-core.mjs";
import "../_libs/tanstack__react-query.mjs";
import "./client-mgvTz6tP.mjs";
import "../_libs/supabase__supabase-js.mjs";
import "../_libs/supabase__postgrest-js.mjs";
import "../_libs/supabase__realtime-js.mjs";
import "../_libs/supabase__phoenix.mjs";
import "../_libs/supabase__storage-js.mjs";

import "../_libs/iceberg-js.mjs";
import "../_libs/supabase__auth-js.mjs";
import "../_libs/tslib.mjs";
import "../_libs/supabase__functions-js.mjs";

import "../_libs/radix-ui__react-slot.mjs";
import "../_libs/radix-ui__react-compose-refs.mjs";
import "../_libs/class-variance-authority.mjs";
import "../_libs/clsx.mjs";
import "../_libs/tailwind-merge.mjs";
import "../_libs/radix-ui__react-switch.mjs";
import "../_libs/radix-ui__primitive.mjs";
import "../_libs/radix-ui__react-context.mjs";
import "../_libs/@radix-ui/react-use-controllable-state+[...].mjs";
import "../_libs/@radix-ui/react-use-layout-effect+[...].mjs";
import "../_libs/radix-ui__react-use-previous.mjs";
import "../_libs/radix-ui__react-use-size.mjs";
import "../_libs/radix-ui__react-primitive.mjs";
import "./createSsrRpc-r3tzPO1F.mjs";
import "./server-g-lQHb1O.mjs";
import "../_libs/h3-v2.mjs";
import "../_libs/rou3.mjs";
import "../_libs/srvx.mjs";




import "./auth-middleware-B5YcFrfv.mjs";
import "../_libs/radix-ui__react-label.mjs";
import "../_libs/tanstack__zod-adapter.mjs";
import "../_libs/zod.mjs";
import "../_libs/radix-ui__react-dialog.mjs";
import "../_libs/radix-ui__react-id.mjs";
import "../_libs/@radix-ui/react-dismissable-layer+[...].mjs";
import "../_libs/@radix-ui/react-use-callback-ref+[...].mjs";
import "../_libs/radix-ui__react-focus-scope.mjs";
import "../_libs/radix-ui__react-portal.mjs";
import "../_libs/radix-ui__react-presence.mjs";
import "../_libs/radix-ui__react-focus-guards.mjs";
import "../_libs/react-remove-scroll.mjs";
import "../_libs/react-remove-scroll-bar.mjs";
import "../_libs/react-style-singleton.mjs";
import "../_libs/get-nonce.mjs";
import "../_libs/use-sidecar.mjs";
import "../_libs/use-callback-ref.mjs";
import "../_libs/aria-hidden.mjs";
import "../_libs/radix-ui__react-checkbox.mjs";
import "./coach-analytics.rules-DadTu4Zq.mjs";
import "./football-positions-BJzdkmjv.mjs";
import "./athlete-training-session-pool-CmIQKgmz.mjs";
import "../_libs/lovable.dev__webhooks-js.mjs";
import "./registry-BHGsuy94.mjs";
import "../_libs/react-email__html.mjs";
import "../_libs/react-email__head.mjs";
import "../_libs/react-email__preview.mjs";
import "../_libs/react-email__body.mjs";
import "../_libs/react-email__container.mjs";
import "../_libs/react-email__section.mjs";
import "../_libs/react-email__heading.mjs";
import "../_libs/react-email__text.mjs";
import "../_libs/react-email__button.mjs";
import "../_libs/react-email__hr.mjs";
import "../_libs/react-email__img.mjs";
import "./task-engine.server-BbzZOvQb.mjs";
import "./stripe.server-mcZ3T1eX.mjs";
import "../_libs/lovable.dev__email-js.mjs";
import "../_libs/react-email__render.mjs";
import "../_libs/prettier.mjs";
import "../_libs/html-to-text.mjs";
import "../_libs/selderee__plugin-htmlparser2.mjs";
import "../_libs/selderee.mjs";
import "../_libs/parseley.mjs";
import "../_libs/leac.mjs";
import "../_libs/peberminta.mjs";
import "../_libs/domhandler.mjs";
import "../_libs/domelementtype.mjs";
import "../_libs/htmlparser2.mjs";
import "../_libs/entities.mjs";
import "../_libs/deepmerge.mjs";
import "../_libs/dom-serializer.mjs";
import "../_libs/react-email__link.mjs";
import "../_libs/jose.mjs";
import "../_libs/ajv.mjs";
import "../_libs/fast-deep-equal.mjs";
import "../_libs/json-schema-traverse.mjs";
import "../_libs/fast-uri.mjs";
import "./Logo-B675pmm_.mjs";
import "./textarea-CAY_SJkd.mjs";
import "./autopilot-jobs.functions-DxvdXJgH.mjs";
import "./OrganizationContextSwitcher-DxSxAmgQ.mjs";
import "./course-instructor.functions-BA-q0LmI.mjs";
import "./bulls-nutrition.functions-wjyzwTVV.mjs";
import "./nutrition.functions-BVD9gwX2.mjs";
import "./meal-skips.functions-2659tu9a.mjs";
import "./DayPlanView-D2AHUXcq.mjs";
import "./trialPlans-V1Tkje_M.mjs";
import "./trial.functions-D9fN4_x8.mjs";
import "./ClientRecharts-I4-LrxpH.mjs";
import "./exercise-name-match-Bk3cpj_r.mjs";
import "./TrainingSessionsList-BpQ9uaZp.mjs";
import "./athlete-profile.functions-DD2AJ-xX.mjs";
function TrainingPage() {
  const track = useServerFn(trackHubEvent);
  reactExports.useEffect(() => {
    track({
      data: {
        kind: "training_plan_opened"
      }
    }).catch(() => {
    });
  }, [track]);
  const {
    supabaseUser
  } = useSession();
  const {
    isTrial,
    isExpired
  } = useTrial();
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-6", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs(Link, { to: "/bulls", className: "inline-flex items-center gap-1 text-xs text-muted-foreground hover:text-bulls-red", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowLeft, { className: "h-3 w-3" }),
      " Zurück zum Hub"
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(BullsHero, { eyebrow: "Training", title: "Deine Trainingswoche", subtitle: "Vollständiger Trainingsplan, Sätze tracken, Progression — im Bulls-Look." }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("section", { className: "grid gap-3 sm:grid-cols-3", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(QuickLink, { to: "/bulls/performance", icon: /* @__PURE__ */ jsxRuntimeExports.jsx(Activity, { className: "h-5 w-5" }), title: "Performance Check", desc: "Speed · Agility · Power · Strength" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(QuickLink, { to: "/progress", icon: /* @__PURE__ */ jsxRuntimeExports.jsx(ChartColumn, { className: "h-5 w-5" }), title: "Trainingsanalyse", desc: "Verbesserungen & Trends" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(QuickLink, { to: "/achievements", icon: /* @__PURE__ */ jsxRuntimeExports.jsx(Sparkles, { className: "h-5 w-5" }), title: "Erfolge", desc: "Adhärenz & Volumen" })
    ] }),
    supabaseUser && /* @__PURE__ */ jsxRuntimeExports.jsx(AthleteProfileBanner, {}),
    supabaseUser && !isTrial && !isExpired && /* @__PURE__ */ jsxRuntimeExports.jsx(LivePlanBanner, { userId: supabaseUser.id }),
    supabaseUser && /* @__PURE__ */ jsxRuntimeExports.jsx(BullsAthleteAthleticSession, {}),
    isTrial || isExpired ? /* @__PURE__ */ jsxRuntimeExports.jsx(TrialTrainingPlan, {}) : supabaseUser && /* @__PURE__ */ jsxRuntimeExports.jsx(PlanContentView, { clientId: supabaseUser.id, planType: "training" }),
    supabaseUser && !isExpired && /* @__PURE__ */ jsxRuntimeExports.jsx("section", { className: "space-y-4", children: /* @__PURE__ */ jsxRuntimeExports.jsx(TrainingTracker, { clientId: supabaseUser.id }) })
  ] });
}
function QuickLink({
  to,
  icon,
  title,
  desc
}) {
  return /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to, className: "flex items-center justify-between gap-3 rounded-2xl border border-border bg-card p-4 transition hover:border-bulls-red/60", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid h-10 w-10 place-items-center rounded-xl bg-bulls-red/15 text-bulls-red", children: icon }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-sm font-bold", children: title }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "truncate text-xs text-muted-foreground", children: desc })
    ] })
  ] }) });
}
const SplitComponent = () => /* @__PURE__ */ jsxRuntimeExports.jsx(AppLayout, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(BullsGate, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(TrainingPage, {}) }) });
export {
  SplitComponent as component
};
