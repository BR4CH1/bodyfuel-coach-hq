import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import { e as useNavigate } from "../_libs/tanstack__react-router.mjs";
import { u as useSession, a as useServerFn, m as getMyOrgContexts } from "./router-BmNvgrMe.mjs";
import { u as useQuery } from "../_libs/tanstack__react-query.mjs";
import { av as Building2, f as ChevronDown } from "../_libs/lucide-react.mjs";
const ACTIVE_KEY = "bodyfuel.activeContext";
const MODE_PREFIX = "bodyfuel.orgMode:";
const PERSONAL_CONTEXT = "personal";
const PERSONAL_CONTEXT_ALIASES = /* @__PURE__ */ new Set([PERSONAL_CONTEXT, "bodyfuel", "mein-bodyfuel", "mein_bodyfuel"]);
function getActiveContext() {
  if (typeof window === "undefined") return null;
  const value = localStorage.getItem(ACTIVE_KEY);
  if (!value) return null;
  if (PERSONAL_CONTEXT_ALIASES.has(value)) {
    localStorage.removeItem(ACTIVE_KEY);
    return null;
  }
  return value;
}
function setActiveContext(slug) {
  if (typeof window === "undefined") return;
  if (slug && !PERSONAL_CONTEXT_ALIASES.has(slug)) localStorage.setItem(ACTIVE_KEY, slug);
  else localStorage.removeItem(ACTIVE_KEY);
  window.dispatchEvent(new CustomEvent("bodyfuel:active-context-change"));
}
function activatePersonalBodyFuelContext() {
  setActiveContext(null);
}
function getOrgMode(slug) {
  if (typeof window === "undefined") return null;
  const v = localStorage.getItem(MODE_PREFIX + slug);
  return v === "athlete" || v === "staff" ? v : null;
}
function setOrgMode(slug, mode) {
  if (typeof window === "undefined") return;
  localStorage.setItem(MODE_PREFIX + slug, mode);
}
const STAFF_ROLE_LABEL = {
  organization_admin: "Admin",
  team_coach: "Team Coach",
  performance_coach: "Performance Coach",
  nutrition_coach: "Nutrition Coach",
  community_manager: "Community",
  custom: "Staff"
};
function staffLabel(role) {
  return STAFF_ROLE_LABEL[role] ?? "Staff";
}
function OrganizationContextSwitcher({ compact = false }) {
  const { supabaseUser } = useSession();
  const navigate = useNavigate();
  const fetchCtx = useServerFn(getMyOrgContexts);
  const { data: contexts } = useQuery({
    queryKey: ["my-org-contexts", supabaseUser?.id ?? "anon"],
    enabled: !!supabaseUser,
    queryFn: () => fetchCtx()
  });
  const [open, setOpen] = reactExports.useState(false);
  const [active, setActive] = reactExports.useState(getActiveContext());
  reactExports.useEffect(() => {
    const handler = () => setActive(getActiveContext());
    window.addEventListener("storage", handler);
    window.addEventListener("bodyfuel:active-context-change", handler);
    return () => {
      window.removeEventListener("storage", handler);
      window.removeEventListener("bodyfuel:active-context-change", handler);
    };
  }, []);
  if (!supabaseUser || !contexts || contexts.length === 0) return null;
  const activeEntry = contexts.find((e) => e.organization.slug === active);
  const label = activeEntry?.organization.name ?? "Mein BODYFUEL";
  const goPersonal = () => {
    activatePersonalBodyFuelContext();
    setActive(null);
    setOpen(false);
    navigate({ to: "/dashboard" });
  };
  const goOrg = (entry, forceMode) => {
    const slug = entry.organization.slug;
    setActiveContext(slug);
    setActive(slug);
    setOpen(false);
    const hasAthlete = !!entry.athlete;
    const hasStaff = !!entry.staff;
    let mode;
    if (forceMode) mode = forceMode;
    else if (hasAthlete && hasStaff) mode = getOrgMode(slug) ?? "athlete";
    else if (hasStaff) mode = "staff";
    else mode = "athlete";
    setOrgMode(slug, mode);
    if (mode === "staff") {
      navigate({ to: "/coach/teams/$orgId", params: { orgId: entry.organization.id } });
    } else {
      navigate({ to: "/$orgSlug/home", params: { orgSlug: slug } });
    }
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs(
      "button",
      {
        type: "button",
        onClick: () => setOpen((v) => !v),
        className: `flex items-center gap-2 rounded-md border border-border bg-card px-3 py-1.5 text-xs font-semibold uppercase tracking-wider hover:bg-secondary ${compact ? "" : ""}`,
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Building2, { className: "h-3.5 w-3.5" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "truncate max-w-[140px]", children: label }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronDown, { className: "h-3.5 w-3.5" })
        ]
      }
    ),
    open && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "absolute right-0 z-50 mt-1 w-72 rounded-md border border-border bg-popover p-1 shadow-lg", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          type: "button",
          onClick: goPersonal,
          className: `block w-full rounded px-3 py-2 text-left text-sm hover:bg-secondary ${!active ? "font-bold" : ""}`,
          children: "Mein BODYFUEL"
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "my-1 border-t border-border" }),
      contexts.map((e) => {
        const hasAthlete = !!e.athlete;
        const hasStaff = !!e.staff;
        const dual = hasAthlete && hasStaff;
        const isActive = active === e.organization.slug;
        const currentMode = dual ? getOrgMode(e.organization.slug) ?? "athlete" : null;
        return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: () => goOrg(e),
              className: `flex w-full items-center justify-between rounded px-3 py-2 text-left text-sm hover:bg-secondary ${isActive ? "font-bold" : ""}`,
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "truncate", children: e.organization.name }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "ml-2 flex shrink-0 gap-1", children: [
                  hasAthlete && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "rounded-sm bg-secondary px-1.5 py-0.5 text-[9px] font-semibold uppercase tracking-wider text-muted-foreground", children: "Athlete" }),
                  hasStaff && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "rounded-sm bg-primary/10 px-1.5 py-0.5 text-[9px] font-semibold uppercase tracking-wider text-primary", children: staffLabel(e.staff.role) })
                ] })
              ]
            }
          ),
          dual && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-1 flex gap-1 px-3 pb-1", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                type: "button",
                onClick: () => goOrg(e, "athlete"),
                className: `flex-1 rounded px-2 py-1 text-[10px] font-semibold uppercase tracking-wider ${currentMode === "athlete" && isActive ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground hover:bg-secondary/70"}`,
                children: "Athletenbereich"
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                type: "button",
                onClick: () => goOrg(e, "staff"),
                className: `flex-1 rounded px-2 py-1 text-[10px] font-semibold uppercase tracking-wider ${currentMode === "staff" && isActive ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground hover:bg-secondary/70"}`,
                children: "Staffbereich"
              }
            )
          ] })
        ] }, e.organization.id);
      })
    ] })
  ] });
}
export {
  OrganizationContextSwitcher as O,
  getOrgMode as a,
  setOrgMode as b,
  activatePersonalBodyFuelContext as c,
  getActiveContext as g,
  setActiveContext as s
};
