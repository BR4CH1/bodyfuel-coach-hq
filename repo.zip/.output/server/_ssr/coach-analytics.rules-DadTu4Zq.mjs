function classifyAthlete(s) {
  if (s.days_inactive != null && s.days_inactive >= 14) return "critical";
  if (s.compliance != null && s.compliance < 30) return "critical";
  if (s.compliance_delta != null && s.compliance_delta <= -25) return "critical";
  if (s.days_inactive != null && s.days_inactive >= 7) return "attention";
  if (s.compliance != null && s.compliance < 50) return "attention";
  if (s.compliance_delta != null && s.compliance_delta <= -10) return "attention";
  if (s.compliance_delta != null && s.compliance_delta >= 20) return "positive";
  if (s.compliance != null && s.compliance >= 80) return "positive";
  if (s.compliance == null && s.days_inactive == null) return "watch";
  return "stable";
}
function buildAttentionList(signals) {
  const priority = {
    critical: 0,
    attention: 1,
    watch: 2,
    stable: 3,
    positive: 4
  };
  return [...signals].sort((a, b) => {
    const pa = priority[classifyAthlete(a)];
    const pb = priority[classifyAthlete(b)];
    if (pa !== pb) return pa - pb;
    const ca = a.compliance ?? 101;
    const cb = b.compliance ?? 101;
    return ca - cb;
  });
}
const STATUS_LABEL = {
  critical: "Kritisch",
  attention: "Aufmerksamkeit",
  watch: "Beobachten",
  stable: "Stabil",
  positive: "Positiv"
};
function explainAthlete(s) {
  const t = [];
  if (s.days_inactive != null && s.days_inactive >= 14) {
    t.push({ kind: "inactivity_critical", label: "Inaktivität", detail: `${s.days_inactive} Tage keine Aktivität` });
  } else if (s.days_inactive != null && s.days_inactive >= 7) {
    t.push({ kind: "inactivity", label: "Inaktivität", detail: `${s.days_inactive} Tage keine Aktivität` });
  }
  if (s.compliance != null && s.compliance < 30) {
    t.push({ kind: "compliance_critical", label: "Compliance", detail: `nur ${s.compliance} % in dieser Woche` });
  } else if (s.compliance != null && s.compliance < 50) {
    t.push({ kind: "compliance_low", label: "Compliance", detail: `nur ${s.compliance} % in dieser Woche` });
  }
  if (s.compliance_delta != null && s.compliance_delta <= -25) {
    t.push({ kind: "compliance_drop_critical", label: "Compliance ↓", detail: `${s.compliance_delta} Prozentpunkte ggü. Vorwoche` });
  } else if (s.compliance_delta != null && s.compliance_delta <= -10) {
    t.push({ kind: "compliance_drop", label: "Compliance ↓", detail: `${s.compliance_delta} Prozentpunkte ggü. Vorwoche` });
  } else if (s.compliance_delta != null && s.compliance_delta >= 20) {
    t.push({ kind: "compliance_rise", label: "Compliance ↑", detail: `+${s.compliance_delta} Prozentpunkte ggü. Vorwoche` });
  }
  return t;
}
export {
  STATUS_LABEL as S,
  buildAttentionList as b,
  classifyAthlete as c,
  explainAthlete as e
};
