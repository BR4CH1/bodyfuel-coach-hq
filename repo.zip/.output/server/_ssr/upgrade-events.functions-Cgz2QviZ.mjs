import { c as createSsrRpc } from "./createSsrRpc-r3tzPO1F.mjs";
import { c as createServerFn } from "./server-g-lQHb1O.mjs";
import { r as requireSupabaseAuth } from "./auth-middleware-B5YcFrfv.mjs";
const trackUpgradeEvent = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => d).handler(createSsrRpc("3cc68ac38ce2eb97af677497431efe31bb8b5bbf714b8f915880ca2af19e57f0"));
const getTierMetrics = createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).handler(createSsrRpc("b7b4408248285dcce3fd7fe45df3fea58460242a05d726ff11e99d9395c6c665"));
export {
  getTierMetrics as g,
  trackUpgradeEvent as t
};
