import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import { e as useNavigate, L as Link } from "../_libs/tanstack__react-router.mjs";
import { u as useSession, j as useEntitlements, a as useServerFn } from "./router-BmNvgrMe.mjs";
import { u as useQuery } from "../_libs/tanstack__react-query.mjs";
import { g as getBullsDailyNutritionTargets } from "./bulls-nutrition.functions-wjyzwTVV.mjs";
import { X, p as Sparkles } from "../_libs/lucide-react.mjs";
const todayIso = () => (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
const DISMISS_KEY = "bf:bulls-onboarding-popup:dismissed-date";
function BullsPerformanceOnboardingPopup() {
  const { supabaseUser } = useSession();
  const [dismissedToday, setDismissedToday] = reactExports.useState(true);
  const getTargets = useServerFn(getBullsDailyNutritionTargets);
  reactExports.useEffect(() => {
    try {
      const stored = localStorage.getItem(DISMISS_KEY);
      setDismissedToday(stored === todayIso());
    } catch {
      setDismissedToday(false);
    }
  }, []);
  const { data } = useQuery({
    queryKey: ["bulls-perf-onboarding-check", supabaseUser?.id],
    queryFn: () => getTargets({ data: { date: todayIso() } }),
    enabled: !!supabaseUser?.id,
    staleTime: 6e4,
    retry: false
  });
  const dismiss = () => {
    try {
      localStorage.setItem(DISMISS_KEY, todayIso());
    } catch {
    }
    setDismissedToday(true);
  };
  if (!data?.needsProfile || dismissedToday) return null;
  return /* @__PURE__ */ jsxRuntimeExports.jsx(
    "div",
    {
      role: "dialog",
      "aria-modal": "true",
      className: "fixed inset-0 z-[100] flex items-end justify-center bg-black/70 p-4 backdrop-blur-sm sm:items-center",
      children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative w-full max-w-md overflow-hidden rounded-3xl border border-bulls-red/50 bg-card p-6 shadow-2xl", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            "aria-label": "Später",
            onClick: () => dismiss(),
            className: "absolute right-3 top-3 rounded-full p-1.5 text-muted-foreground hover:bg-accent hover:text-foreground",
            children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "h-4 w-4" })
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Sparkles, { className: "h-4 w-4 text-bulls-red" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs uppercase tracking-[0.2em] text-bulls-red", children: "Performance-Profil fehlt" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "mt-3 font-display text-xl font-bold", children: "Vervollständige dein Bulls-Profil" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-2 text-sm text-muted-foreground", children: "Damit dein individueller Ernährungsplan automatisch erstellt und wöchentlich angepasst werden kann, brauchen wir noch ein paar Angaben: Biometrie, Ziel, Lieblingsfoods, No-Gos, Allergien und Meal-Prep-Vorlieben." }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("ul", { className: "mt-4 space-y-1.5 text-xs text-muted-foreground", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: "• Dauert ca. 2 Minuten" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: "• Coach plant Training – BodyFuel plant deine Ernährung" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: "• Kein manuelles „Plan erstellen“ mehr nötig" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-6 flex flex-col gap-2 sm:flex-row-reverse", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            Link,
            {
              to: "/$orgSlug/onboarding",
              params: { orgSlug: "bulls" },
              className: "inline-flex flex-1 items-center justify-center rounded-xl bg-bulls-red px-4 py-3 text-sm font-bold uppercase tracking-wider text-white hover:bg-bulls-red/90",
              children: "Jetzt vervollständigen"
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              onClick: () => dismiss(),
              className: "rounded-xl border border-border px-4 py-3 text-xs text-muted-foreground hover:text-foreground",
              children: "Später"
            }
          )
        ] })
      ] })
    }
  );
}
function BullsGate({ children }) {
  const { hasGroup, loading, supabaseUser, isFreeUser } = useSession();
  const ent = useEntitlements();
  const navigate = useNavigate();
  const isBullsOrgAthlete = ent.primaryOrgSlug === "bulls";
  const hasBullsAccess = hasGroup("bulls") || isBullsOrgAthlete;
  reactExports.useEffect(() => {
    if (loading || ent.loading) return;
    if (!supabaseUser) {
      navigate({ to: "/auth", search: { next: void 0 } });
      return;
    }
    if (!hasBullsAccess) {
      navigate({ to: isFreeUser ? "/tracker/app" : "/dashboard" });
    }
  }, [hasBullsAccess, loading, ent.loading, supabaseUser, isFreeUser, navigate]);
  if (loading || ent.loading) return null;
  if (!supabaseUser || !hasBullsAccess) return null;
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bulls-theme", children: [
    children,
    /* @__PURE__ */ jsxRuntimeExports.jsx(BullsPerformanceOnboardingPopup, {})
  ] });
}
export {
  BullsGate as B
};
