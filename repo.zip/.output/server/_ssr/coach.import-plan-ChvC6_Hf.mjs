import { j as jsxRuntimeExports, r as reactExports } from "../_libs/react.mjs";
import { e as useNavigate } from "../_libs/tanstack__react-router.mjs";
import { u as useSession, aj as Route$1e, a as useServerFn } from "./router-BmNvgrMe.mjs";
import { u as useQuery } from "../_libs/tanstack__react-query.mjs";
import { t as toast } from "../_libs/sonner.mjs";
import { A as AppLayout } from "./AppLayout-lnbnJZfJ.mjs";
import { p as parseCustomerTrainingPlan } from "./customer-training-plan.functions-i25vZFMB.mjs";
import { saveCoachTrainingPlanDraft, parseCoachNutritionPlan, saveCoachNutritionPlanDraft } from "./coach-plan-import.functions-CpKrIzPa.mjs";
import { l as listCustomerNutritionPlans } from "./coach-plan-history.functions-Bmsgu7vX.mjs";
import "../_libs/idb.mjs";

import "../_libs/seroval.mjs";
import "../_libs/unenv.mjs";

import "../_libs/lovable.dev__mcp-js.mjs";
import "../_libs/modelcontextprotocol__sdk.mjs";
import "../_libs/zod-to-json-schema.mjs";
import "../_libs/ajv-formats.mjs";
import "../_libs/stripe.mjs";
import { aC as Upload, x as Type, ap as FileText, L as LoaderCircle, b3 as WandSparkles, ay as Save, o as Trash2, W as Plus } from "../_libs/lucide-react.mjs";
import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval-plugins.mjs";


import "../_libs/react-dom.mjs";
import "../_libs/isbot.mjs";
import "../_libs/tanstack__query-core.mjs";
import "./client-mgvTz6tP.mjs";
import "../_libs/supabase__supabase-js.mjs";
import "../_libs/supabase__postgrest-js.mjs";
import "../_libs/supabase__realtime-js.mjs";
import "../_libs/supabase__phoenix.mjs";
import "../_libs/supabase__storage-js.mjs";

import "../_libs/iceberg-js.mjs";
import "../_libs/supabase__auth-js.mjs";
import "../_libs/tslib.mjs";
import "../_libs/supabase__functions-js.mjs";

import "../_libs/radix-ui__react-slot.mjs";
import "../_libs/radix-ui__react-compose-refs.mjs";
import "../_libs/class-variance-authority.mjs";
import "../_libs/clsx.mjs";
import "../_libs/tailwind-merge.mjs";
import "../_libs/radix-ui__react-switch.mjs";
import "../_libs/radix-ui__primitive.mjs";
import "../_libs/radix-ui__react-context.mjs";
import "../_libs/@radix-ui/react-use-controllable-state+[...].mjs";
import "../_libs/@radix-ui/react-use-layout-effect+[...].mjs";
import "../_libs/radix-ui__react-use-previous.mjs";
import "../_libs/radix-ui__react-use-size.mjs";
import "../_libs/radix-ui__react-primitive.mjs";
import "./createSsrRpc-r3tzPO1F.mjs";
import "./server-g-lQHb1O.mjs";
import "../_libs/h3-v2.mjs";
import "../_libs/rou3.mjs";
import "../_libs/srvx.mjs";




import "./auth-middleware-B5YcFrfv.mjs";
import "../_libs/radix-ui__react-label.mjs";
import "../_libs/tanstack__zod-adapter.mjs";
import "../_libs/zod.mjs";
import "../_libs/radix-ui__react-dialog.mjs";
import "../_libs/radix-ui__react-id.mjs";
import "../_libs/@radix-ui/react-dismissable-layer+[...].mjs";
import "../_libs/@radix-ui/react-use-callback-ref+[...].mjs";
import "../_libs/radix-ui__react-focus-scope.mjs";
import "../_libs/radix-ui__react-portal.mjs";
import "../_libs/radix-ui__react-presence.mjs";
import "../_libs/radix-ui__react-focus-guards.mjs";
import "../_libs/react-remove-scroll.mjs";
import "../_libs/react-remove-scroll-bar.mjs";
import "../_libs/react-style-singleton.mjs";
import "../_libs/get-nonce.mjs";
import "../_libs/use-sidecar.mjs";
import "../_libs/use-callback-ref.mjs";
import "../_libs/aria-hidden.mjs";
import "../_libs/radix-ui__react-checkbox.mjs";
import "./coach-analytics.rules-DadTu4Zq.mjs";
import "./football-positions-BJzdkmjv.mjs";
import "./athlete-training-session-pool-CmIQKgmz.mjs";
import "../_libs/lovable.dev__webhooks-js.mjs";
import "./registry-BHGsuy94.mjs";
import "../_libs/react-email__html.mjs";
import "../_libs/react-email__head.mjs";
import "../_libs/react-email__preview.mjs";
import "../_libs/react-email__body.mjs";
import "../_libs/react-email__container.mjs";
import "../_libs/react-email__section.mjs";
import "../_libs/react-email__heading.mjs";
import "../_libs/react-email__text.mjs";
import "../_libs/react-email__button.mjs";
import "../_libs/react-email__hr.mjs";
import "../_libs/react-email__img.mjs";
import "./task-engine.server-BbzZOvQb.mjs";
import "./stripe.server-mcZ3T1eX.mjs";
import "../_libs/lovable.dev__email-js.mjs";
import "../_libs/react-email__render.mjs";
import "../_libs/prettier.mjs";
import "../_libs/html-to-text.mjs";
import "../_libs/selderee__plugin-htmlparser2.mjs";
import "../_libs/selderee.mjs";
import "../_libs/parseley.mjs";
import "../_libs/leac.mjs";
import "../_libs/peberminta.mjs";
import "../_libs/domhandler.mjs";
import "../_libs/domelementtype.mjs";
import "../_libs/htmlparser2.mjs";
import "../_libs/entities.mjs";
import "../_libs/deepmerge.mjs";
import "../_libs/dom-serializer.mjs";
import "../_libs/react-email__link.mjs";
import "../_libs/jose.mjs";
import "../_libs/ajv.mjs";
import "../_libs/fast-deep-equal.mjs";
import "../_libs/json-schema-traverse.mjs";
import "../_libs/fast-uri.mjs";
import "./Logo-B675pmm_.mjs";
import "./textarea-CAY_SJkd.mjs";
import "./autopilot-jobs.functions-DxvdXJgH.mjs";
import "./OrganizationContextSwitcher-DxSxAmgQ.mjs";
import "./course-instructor.functions-BA-q0LmI.mjs";
const emptyExercise = () => ({
  name: "",
  category: null,
  target_sets: 3,
  target_reps: "8",
  target_weights: null,
  rest_seconds: 90,
  notes: null
});
const emptyTrainingDay = () => ({
  name: "Trainingstag",
  focus: null,
  week_number: 1,
  exercises: [emptyExercise()]
});
const emptyMeal = () => ({
  slot: "breakfast",
  name: "",
  description: null,
  ingredients: [{
    name: "",
    grams: 100
  }]
});
const emptyNutritionDay = () => ({
  name: "Tag 1",
  meals: [emptyMeal()]
});
function ImportPage() {
  const {
    supabaseUser,
    isCoach
  } = useSession();
  const navigate = useNavigate();
  const {
    client,
    type
  } = Route$1e.useSearch();
  const parseTrFn = useServerFn(parseCustomerTrainingPlan);
  const saveTrFn = useServerFn(saveCoachTrainingPlanDraft);
  const parseNuFn = useServerFn(parseCoachNutritionPlan);
  const saveNuFn = useServerFn(saveCoachNutritionPlanDraft);
  const listPlansFn = useServerFn(listCustomerNutritionPlans);
  const [mode, setMode] = reactExports.useState("upload");
  const [busy, setBusy] = reactExports.useState(false);
  const [saving, setSaving] = reactExports.useState(false);
  const [text, setText] = reactExports.useState("");
  const [trPlan, setTrPlan] = reactExports.useState({
    title: "",
    weeks_count: 1,
    days: [emptyTrainingDay()]
  });
  const [nuPlan, setNuPlan] = reactExports.useState({
    title: "",
    days: [emptyNutritionDay()]
  });
  const [saveMode, setSaveMode] = reactExports.useState("new_plan");
  const [targetPlanId, setTargetPlanId] = reactExports.useState("");
  const [targetWeekNumber, setTargetWeekNumber] = reactExports.useState(2);
  const [startDate, setStartDate] = reactExports.useState((/* @__PURE__ */ new Date()).toISOString().slice(0, 10));
  const plansQuery = useQuery({
    queryKey: ["coach-nutrition-plans", client],
    queryFn: () => listPlansFn({
      data: {
        client_id: client
      }
    }),
    enabled: !!client && type === "nutrition" && !!supabaseUser && isCoach
  });
  if (!supabaseUser) return /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-muted-foreground", children: "Bitte einloggen." });
  if (!isCoach) return /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-destructive", children: "Nur für Coaches." });
  if (!client) return /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-destructive", children: "Kein Kunde ausgewählt." });
  const fileToDataUrl = (file) => new Promise((res, rej) => {
    const r = new FileReader();
    r.onload = () => res(String(r.result));
    r.onerror = () => rej(r.error);
    r.readAsDataURL(file);
  });
  const handleFile = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 15 * 1024 * 1024) return toast.error("Datei zu groß (max. 15 MB)");
    setBusy(true);
    try {
      const dataUrl = await fileToDataUrl(file);
      const isPdf = file.type === "application/pdf" || /\.pdf$/i.test(file.name);
      const payload = {
        mode: isPdf ? "pdf" : "image",
        payload: dataUrl,
        filename: file.name
      };
      if (type === "training") {
        const res = await parseTrFn({
          data: payload
        });
        setTrPlan({
          ...res,
          title: res.title || file.name.replace(/\.(pdf|png|jpe?g|webp)$/i, "")
        });
      } else {
        const res = await parseNuFn({
          data: payload
        });
        setNuPlan({
          ...res,
          title: res.title || file.name.replace(/\.(pdf|png|jpe?g|webp)$/i, "")
        });
      }
      toast.success("Plan erkannt — bitte prüfen und speichern.");
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Konnte nicht lesen");
    } finally {
      setBusy(false);
      e.target.value = "";
    }
  };
  const parseText = async () => {
    if (text.trim().length < 20) return toast.error("Bitte mehr Text einfügen.");
    setBusy(true);
    try {
      if (type === "training") {
        const res = await parseTrFn({
          data: {
            mode: "text",
            payload: text
          }
        });
        setTrPlan({
          ...res,
          title: res.title || "Eigener Trainingsplan"
        });
      } else {
        const res = await parseNuFn({
          data: {
            mode: "text",
            payload: text
          }
        });
        setNuPlan({
          ...res,
          title: res.title || "Eigener Ernährungsplan"
        });
      }
      toast.success("Plan erkannt — bitte prüfen und speichern.");
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Konnte nicht parsen");
    } finally {
      setBusy(false);
    }
  };
  const doSaveNutrition = async (cleaned, force) => {
    const payload = {
      client_id: client,
      plan: cleaned,
      title: nuPlan.title,
      mode: saveMode,
      force
    };
    if (saveMode === "append_week" || saveMode === "replace_week" || saveMode === "replace_plan") {
      if (!targetPlanId) throw new Error("Bitte einen Zielplan auswählen.");
      payload.target_plan_id = targetPlanId;
    }
    if (saveMode === "replace_week") payload.target_week_number = targetWeekNumber;
    if (saveMode === "new_plan" || saveMode === "replace_plan") payload.start_date = startDate;
    await saveNuFn({
      data: payload
    });
  };
  const save = async () => {
    setSaving(true);
    try {
      if (type === "training") {
        if (!trPlan.days.some((d) => d.exercises.some((e) => e.name.trim()))) {
          throw new Error("Mindestens eine Übung erforderlich.");
        }
        const cleaned = {
          ...trPlan,
          days: trPlan.days.map((d) => ({
            ...d,
            exercises: d.exercises.filter((e) => e.name.trim())
          })).filter((d) => d.exercises.length)
        };
        await saveTrFn({
          data: {
            client_id: client,
            plan: cleaned,
            title: trPlan.title
          }
        });
      } else {
        if (!nuPlan.days.some((d) => d.meals.some((m) => m.name.trim() && m.ingredients.some((i) => i.name.trim())))) {
          throw new Error("Mindestens eine Mahlzeit mit Zutaten erforderlich.");
        }
        const cleaned = {
          ...nuPlan,
          days: nuPlan.days.map((d) => ({
            ...d,
            meals: d.meals.filter((m) => m.name.trim()).map((m) => ({
              ...m,
              ingredients: m.ingredients.filter((i) => i.name.trim())
            })).filter((m) => m.ingredients.length)
          })).filter((d) => d.meals.length)
        };
        try {
          await doSaveNutrition(cleaned, false);
        } catch (err) {
          const msg = err instanceof Error ? err.message : "";
          if (msg.startsWith("CONFLICT:")) {
            const ok = window.confirm("Für diesen Zeitraum existiert bereits ein Plan.\n\nOK  = Trotzdem zusätzlich als neuen Plan speichern\nAbbrechen = Import stoppen (dann oben 'An bestehenden anhängen' oder 'Ersetzen' wählen)");
            if (!ok) {
              setSaving(false);
              return;
            }
            await doSaveNutrition(cleaned, true);
          } else {
            throw err;
          }
        }
      }
      toast.success("Plan gespeichert.");
      navigate({
        to: "/coach/customers/$userId",
        params: {
          userId: client
        }
      });
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Speichern fehlgeschlagen");
    } finally {
      setSaving(false);
    }
  };
  const typeLabel = type === "training" ? "Trainingsplan" : "Ernährungsplan";
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-6", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs uppercase tracking-[0.2em] text-muted-foreground", children: "Coach · Import" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("h1", { className: "font-display text-3xl font-bold sm:text-4xl", children: [
        "Eigenen ",
        typeLabel,
        " importieren"
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-2 text-sm text-muted-foreground", children: "Lade PDF/Bild hoch, füge Text ein oder erstelle manuell. Der Plan wird als Entwurf für den Kunden angelegt — du gibst ihn anschließend wie gewohnt frei." })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid gap-2 sm:grid-cols-3", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(ModeBtn, { active: mode === "upload", onClick: () => setMode("upload"), icon: /* @__PURE__ */ jsxRuntimeExports.jsx(Upload, { className: "h-4 w-4" }), label: "PDF / Bild" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(ModeBtn, { active: mode === "text", onClick: () => setMode("text"), icon: /* @__PURE__ */ jsxRuntimeExports.jsx(Type, { className: "h-4 w-4" }), label: "Text einfügen" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(ModeBtn, { active: mode === "manual", onClick: () => setMode("manual"), icon: /* @__PURE__ */ jsxRuntimeExports.jsx(FileText, { className: "h-4 w-4" }), label: "Manuell" })
    ] }),
    mode === "upload" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl border border-gold/40 bg-card p-5", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "font-display text-lg font-bold", children: "PDF oder Bild hochladen" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "mt-1 text-xs text-muted-foreground", children: [
        "Die KI extrahiert die Struktur. ",
        type === "nutrition" ? "Nährwerte werden serverseitig aus der DB berechnet." : "Übungen, Sätze, Wiederholungen werden erkannt."
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "mt-4 inline-flex cursor-pointer items-center gap-2 rounded-md bg-gradient-gold px-4 py-2 text-sm font-semibold text-primary-foreground hover:opacity-90", children: [
        busy ? /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "h-4 w-4 animate-spin" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Upload, { className: "h-4 w-4" }),
        busy ? "Lese Plan..." : "Datei wählen",
        /* @__PURE__ */ jsxRuntimeExports.jsx("input", { type: "file", accept: "application/pdf,image/*", className: "hidden", onChange: handleFile, disabled: busy })
      ] })
    ] }),
    mode === "text" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl border border-gold/40 bg-card p-5", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "font-display text-lg font-bold", children: "Plan als Text einfügen" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("textarea", { value: text, onChange: (e) => setText(e.target.value), placeholder: type === "training" ? "Beispiel:\nTag 1 — Push\nBankdrücken 4x8 60kg\n..." : "Beispiel:\nTag 1\nFrühstück: 80g Haferflocken, 150g Apfel, 200g Milch\nMittag: 200g Hähnchen, 150g Reis, 200g Brokkoli\n...", rows: 10, className: "mt-3 w-full rounded-md border border-input bg-background px-3 py-2 font-mono text-sm" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { onClick: parseText, disabled: busy, className: "mt-3 inline-flex items-center gap-2 rounded-md bg-gradient-gold px-4 py-2 text-sm font-semibold text-primary-foreground disabled:opacity-50", children: [
        busy ? /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "h-4 w-4 animate-spin" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(WandSparkles, { className: "h-4 w-4" }),
        "Mit KI strukturieren"
      ] })
    ] }),
    type === "nutrition" && /* @__PURE__ */ jsxRuntimeExports.jsx(NutritionSaveModeCard, { plans: plansQuery.data?.all ?? [], isLoading: plansQuery.isLoading, mode: saveMode, setMode: setSaveMode, targetPlanId, setTargetPlanId, targetWeekNumber, setTargetWeekNumber, startDate, setStartDate }),
    type === "training" ? /* @__PURE__ */ jsxRuntimeExports.jsx(TrainingEditor, { plan: trPlan, setPlan: setTrPlan }) : /* @__PURE__ */ jsxRuntimeExports.jsx(NutritionEditor, { plan: nuPlan, setPlan: setNuPlan }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex justify-end", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { onClick: save, disabled: saving, className: "inline-flex items-center gap-2 rounded-md bg-gradient-gold px-5 py-2.5 text-sm font-semibold text-primary-foreground disabled:opacity-50", children: [
      saving ? /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "h-4 w-4 animate-spin" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Save, { className: "h-4 w-4" }),
      "Als Entwurf speichern"
    ] }) })
  ] });
}
function NutritionSaveModeCard({
  plans,
  isLoading,
  mode,
  setMode,
  targetPlanId,
  setTargetPlanId,
  targetWeekNumber,
  setTargetWeekNumber,
  startDate,
  setStartDate
}) {
  const active = plans.filter((p) => p.status !== "archived");
  const options = [{
    value: "append_week",
    label: "An bestehenden Plan anhängen",
    hint: "Neue Woche wird angehängt"
  }, {
    value: "new_plan",
    label: "Als neuen Plan speichern",
    hint: "Zusätzlicher Plan, andere bleiben"
  }, {
    value: "replace_week",
    label: "Bestehende Woche ersetzen",
    hint: "Tage einer Woche werden ersetzt"
  }, {
    value: "replace_plan",
    label: "Kompletten Plan ersetzen",
    hint: "Zielplan wird archiviert"
  }];
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl border border-gold/30 bg-card p-5", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "font-display text-lg font-bold", children: "Speichern als" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-1 text-xs text-muted-foreground", children: "Bestimme, wie dieser Import beim Kunden abgelegt wird. Es wird nichts automatisch überschrieben." }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-3 grid gap-2 sm:grid-cols-2", children: options.map((o) => /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { onClick: () => setMode(o.value), className: `rounded-xl border px-3 py-2 text-left text-xs transition ${mode === o.value ? "border-gold/60 bg-gold/10" : "border-border bg-background/40 hover:border-gold/40"}`, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm font-semibold", children: o.label }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[11px] text-muted-foreground", children: o.hint })
    ] }, o.value)) }),
    (mode === "append_week" || mode === "replace_week" || mode === "replace_plan") && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-4 grid gap-3 sm:grid-cols-2", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "text-xs", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "mb-1 block font-semibold text-muted-foreground", children: "Zielplan" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("select", { value: targetPlanId, onChange: (e) => setTargetPlanId(e.target.value), className: "w-full rounded-md border border-input bg-background px-2 py-2 text-sm", disabled: isLoading, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "", children: "— wählen —" }),
          active.map((p) => /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: p.id, children: (p.title || "Ohne Titel") + (p.scheduled_start_date ? ` — ${p.scheduled_start_date}` : "") + (p.weeks_count ? ` (${p.weeks_count} Wo.)` : "") }, p.id))
        ] })
      ] }),
      mode === "replace_week" && /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "text-xs", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "mb-1 block font-semibold text-muted-foreground", children: "Wochennummer" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("input", { type: "number", min: 1, max: 52, value: targetWeekNumber, onChange: (e) => setTargetWeekNumber(Math.max(1, Number(e.target.value) || 1)), className: "w-full rounded-md border border-input bg-background px-2 py-2 text-sm" })
      ] })
    ] }),
    (mode === "new_plan" || mode === "replace_plan") && /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "mt-4 block text-xs", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "mb-1 block font-semibold text-muted-foreground", children: "Startdatum" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("input", { type: "date", value: startDate, onChange: (e) => setStartDate(e.target.value), className: "w-full max-w-xs rounded-md border border-input bg-background px-2 py-2 text-sm" })
    ] })
  ] });
}
function ModeBtn({
  active,
  onClick,
  icon,
  label
}) {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { onClick, className: `flex items-center justify-center gap-2 rounded-xl border px-4 py-3 text-sm font-medium transition ${active ? "border-gold/60 bg-gold/10 text-foreground" : "border-border bg-card text-muted-foreground hover:border-gold/40"}`, children: [
    icon,
    label
  ] });
}
function TrainingEditor({
  plan,
  setPlan
}) {
  const updateDay = (i, patch) => setPlan((p) => ({
    ...p,
    days: p.days.map((d, idx) => idx === i ? {
      ...d,
      ...patch
    } : d)
  }));
  const updateEx = (di, ei, patch) => setPlan((p) => ({
    ...p,
    days: p.days.map((d, idx) => idx === di ? {
      ...d,
      exercises: d.exercises.map((e, eidx) => eidx === ei ? {
        ...e,
        ...patch
      } : e)
    } : d)
  }));
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl border border-border bg-card p-5", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "font-display text-lg font-bold", children: "Plan-Editor" }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-3 grid gap-3 sm:grid-cols-[1fr_auto]", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("input", { type: "text", value: plan.title ?? "", onChange: (e) => setPlan((p) => ({
        ...p,
        title: e.target.value
      })), placeholder: "Titel des Plans", className: "rounded-md border border-input bg-background px-3 py-2 text-sm" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "flex items-center gap-2 text-xs text-muted-foreground", children: [
        "Wochen:",
        /* @__PURE__ */ jsxRuntimeExports.jsx("input", { type: "number", min: 1, max: 12, value: plan.weeks_count ?? 1, onChange: (e) => setPlan((p) => ({
          ...p,
          weeks_count: Math.max(1, Math.min(12, Number(e.target.value) || 1))
        })), className: "w-16 rounded-md border border-input bg-background px-2 py-2 text-sm" })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-4 space-y-4", children: [
      plan.days.map((d, di) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-xl border border-border bg-background/40 p-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("input", { value: d.name, onChange: (e) => updateDay(di, {
            name: e.target.value
          }), className: "flex-1 min-w-[140px] rounded-md border border-input bg-background px-3 py-1.5 text-sm font-semibold" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("input", { value: d.focus ?? "", onChange: (e) => updateDay(di, {
            focus: e.target.value || null
          }), placeholder: "Fokus (z.B. Push)", className: "flex-1 min-w-[140px] rounded-md border border-input bg-background px-3 py-1.5 text-sm" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("input", { type: "number", min: 1, max: 12, value: d.week_number ?? 1, onChange: (e) => updateDay(di, {
            week_number: Math.max(1, Math.min(12, Number(e.target.value) || 1))
          }), className: "w-16 rounded-md border border-input bg-background px-2 py-1.5 text-sm", title: "Woche" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: () => setPlan((p) => ({
            ...p,
            days: p.days.filter((_, i) => i !== di)
          })), className: "rounded-md border border-destructive/40 p-1.5 text-destructive hover:bg-destructive/10", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "h-4 w-4" }) })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-3 space-y-2", children: [
          d.exercises.map((ex, ei) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid gap-2 rounded-lg border border-border bg-card p-2 sm:grid-cols-[2fr_60px_80px_100px_80px_32px]", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("input", { value: ex.name, onChange: (e) => updateEx(di, ei, {
              name: e.target.value
            }), placeholder: "Übung", className: "rounded-md border border-input bg-background px-2 py-1.5 text-sm" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("input", { type: "number", value: ex.target_sets ?? "", onChange: (e) => updateEx(di, ei, {
              target_sets: e.target.value ? Number(e.target.value) : null
            }), placeholder: "Sätze", className: "rounded-md border border-input bg-background px-2 py-1.5 text-sm" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("input", { value: ex.target_reps ?? "", onChange: (e) => updateEx(di, ei, {
              target_reps: e.target.value || null
            }), placeholder: "Wdh.", className: "rounded-md border border-input bg-background px-2 py-1.5 text-sm" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("input", { value: ex.target_weights ?? "", onChange: (e) => updateEx(di, ei, {
              target_weights: e.target.value || null
            }), placeholder: "kg", className: "rounded-md border border-input bg-background px-2 py-1.5 text-sm" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("input", { type: "number", value: ex.rest_seconds ?? "", onChange: (e) => updateEx(di, ei, {
              rest_seconds: e.target.value ? Number(e.target.value) : null
            }), placeholder: "Pause s", className: "rounded-md border border-input bg-background px-2 py-1.5 text-sm" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: () => updateDay(di, {
              exercises: d.exercises.filter((_, i) => i !== ei)
            }), className: "rounded-md p-1.5 text-muted-foreground hover:bg-destructive/10 hover:text-destructive", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "h-4 w-4" }) })
          ] }, ei)),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { onClick: () => updateDay(di, {
            exercises: [...d.exercises, emptyExercise()]
          }), className: "inline-flex items-center gap-1 rounded-md border border-border px-3 py-1.5 text-xs hover:border-gold/50", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Plus, { className: "h-3 w-3" }),
            " Übung"
          ] })
        ] })
      ] }, di)),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { onClick: () => setPlan((p) => ({
        ...p,
        days: [...p.days, emptyTrainingDay()]
      })), className: "inline-flex items-center gap-1 rounded-md border border-border px-3 py-2 text-sm hover:border-gold/50", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Plus, { className: "h-4 w-4" }),
        " Tag hinzufügen"
      ] })
    ] })
  ] });
}
const SLOT_LABELS = {
  breakfast: "Frühstück",
  lunch: "Mittagessen",
  dinner: "Abendessen",
  snack: "Snack"
};
function NutritionEditor({
  plan,
  setPlan
}) {
  const updDay = (i, patch) => setPlan((p) => ({
    ...p,
    days: p.days.map((d, idx) => idx === i ? {
      ...d,
      ...patch
    } : d)
  }));
  const updMeal = (di, mi, patch) => setPlan((p) => ({
    ...p,
    days: p.days.map((d, idx) => idx === di ? {
      ...d,
      meals: d.meals.map((m, i) => i === mi ? {
        ...m,
        ...patch
      } : m)
    } : d)
  }));
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl border border-border bg-card p-5", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "font-display text-lg font-bold", children: "Plan-Editor" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("input", { type: "text", value: plan.title ?? "", onChange: (e) => setPlan((p) => ({
      ...p,
      title: e.target.value
    })), placeholder: "Titel des Plans", className: "mt-3 w-full rounded-md border border-input bg-background px-3 py-2 text-sm" }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-4 space-y-4", children: [
      plan.days.map((d, di) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-xl border border-border bg-background/40 p-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("input", { value: d.name, onChange: (e) => updDay(di, {
            name: e.target.value
          }), className: "flex-1 min-w-[140px] rounded-md border border-input bg-background px-3 py-1.5 text-sm font-semibold" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("select", { value: d.type ?? "", onChange: (e) => updDay(di, {
            type: e.target.value || void 0
          }), className: "rounded-md border border-input bg-background px-2 py-1.5 text-sm", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "", children: "— Typ —" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "training", children: "Training" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "rest", children: "Rest" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: () => setPlan((p) => ({
            ...p,
            days: p.days.filter((_, i) => i !== di)
          })), className: "rounded-md border border-destructive/40 p-1.5 text-destructive hover:bg-destructive/10", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "h-4 w-4" }) })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-3 space-y-3", children: [
          d.meals.map((m, mi) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-lg border border-border bg-card p-3", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center gap-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("select", { value: m.slot, onChange: (e) => updMeal(di, mi, {
                slot: e.target.value
              }), className: "rounded-md border border-input bg-background px-2 py-1.5 text-sm", children: Object.keys(SLOT_LABELS).map((k) => /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: k, children: SLOT_LABELS[k] }, k)) }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("input", { value: m.name, onChange: (e) => updMeal(di, mi, {
                name: e.target.value
              }), placeholder: "Mahlzeitname", className: "flex-1 min-w-[160px] rounded-md border border-input bg-background px-2 py-1.5 text-sm" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: () => updDay(di, {
                meals: d.meals.filter((_, i) => i !== mi)
              }), className: "rounded-md p-1.5 text-muted-foreground hover:bg-destructive/10 hover:text-destructive", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "h-4 w-4" }) })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-2 space-y-1.5", children: [
              m.ingredients.map((ing, ii) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid gap-2 sm:grid-cols-[3fr_80px_32px]", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("input", { value: ing.name, onChange: (e) => updMeal(di, mi, {
                  ingredients: m.ingredients.map((x, i) => i === ii ? {
                    ...x,
                    name: e.target.value
                  } : x)
                }), placeholder: "Zutat (z.B. Haferflocken)", className: "rounded-md border border-input bg-background px-2 py-1.5 text-sm" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("input", { type: "number", value: ing.grams ?? "", onChange: (e) => updMeal(di, mi, {
                  ingredients: m.ingredients.map((x, i) => i === ii ? {
                    ...x,
                    grams: e.target.value ? Number(e.target.value) : null
                  } : x)
                }), placeholder: "g", className: "rounded-md border border-input bg-background px-2 py-1.5 text-sm" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: () => updMeal(di, mi, {
                  ingredients: m.ingredients.filter((_, i) => i !== ii)
                }), className: "rounded-md p-1.5 text-muted-foreground hover:bg-destructive/10 hover:text-destructive", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "h-4 w-4" }) })
              ] }, ii)),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { onClick: () => updMeal(di, mi, {
                ingredients: [...m.ingredients, {
                  name: "",
                  grams: 100
                }]
              }), className: "inline-flex items-center gap-1 rounded-md border border-border px-2 py-1 text-xs hover:border-gold/50", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Plus, { className: "h-3 w-3" }),
                " Zutat"
              ] })
            ] })
          ] }, mi)),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { onClick: () => updDay(di, {
            meals: [...d.meals, emptyMeal()]
          }), className: "inline-flex items-center gap-1 rounded-md border border-border px-3 py-1.5 text-xs hover:border-gold/50", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Plus, { className: "h-3 w-3" }),
            " Mahlzeit"
          ] })
        ] })
      ] }, di)),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { onClick: () => setPlan((p) => ({
        ...p,
        days: [...p.days, {
          ...emptyNutritionDay(),
          name: `Tag ${p.days.length + 1}`
        }]
      })), className: "inline-flex items-center gap-1 rounded-md border border-border px-3 py-2 text-sm hover:border-gold/50", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Plus, { className: "h-4 w-4" }),
        " Tag hinzufügen"
      ] })
    ] })
  ] });
}
const SplitComponent = () => /* @__PURE__ */ jsxRuntimeExports.jsx(AppLayout, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(ImportPage, {}) });
export {
  SplitComponent as component
};
