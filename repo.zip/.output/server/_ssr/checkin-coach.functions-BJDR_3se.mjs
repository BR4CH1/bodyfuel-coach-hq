import { c as createServerRpc } from "./createServerRpc--OrbljSy.mjs";
import { c as createServerFn } from "./server-g-lQHb1O.mjs";
import { r as requireSupabaseAuth } from "./auth-middleware-B5YcFrfv.mjs";

import "../_libs/seroval.mjs";
import "../_libs/react.mjs";

import "../_libs/h3-v2.mjs";
import "../_libs/unenv.mjs";


import "../_libs/rou3.mjs";
import "../_libs/srvx.mjs";





import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval-plugins.mjs";

import "../_libs/tanstack__react-router.mjs";
import "../_libs/react-dom.mjs";
import "../_libs/isbot.mjs";
import "../_libs/supabase__supabase-js.mjs";
import "../_libs/supabase__postgrest-js.mjs";
import "../_libs/supabase__realtime-js.mjs";
import "../_libs/supabase__phoenix.mjs";
import "../_libs/supabase__storage-js.mjs";
import "../_libs/iceberg-js.mjs";
import "../_libs/supabase__auth-js.mjs";
import "../_libs/tslib.mjs";
import "../_libs/supabase__functions-js.mjs";
const setCheckinCoachNote_createServerFn_handler = createServerRpc({
  id: "3c201ff78a93edd9cb8b54ceb4005f4cc1fe8a9f3fe363a10401177f6eb6eedc",
  name: "setCheckinCoachNote",
  filename: "src/lib/checkin-coach.functions.ts"
}, (opts) => setCheckinCoachNote.__executeServer(opts));
const setCheckinCoachNote = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => d).handler(setCheckinCoachNote_createServerFn_handler, async ({
  data,
  context
}) => {
  const {
    data: isCoach,
    error: rErr
  } = await context.supabase.rpc("has_role", {
    _user_id: context.userId,
    _role: "coach"
  });
  if (rErr) throw new Error(rErr.message);
  if (!isCoach) throw new Error("Nicht autorisiert");
  const {
    error
  } = await context.supabase.from("weekly_checkins").update({
    coach_notes: data.coach_notes
  }).eq("id", data.checkin_id);
  if (error) throw new Error(error.message);
  return {
    ok: true
  };
});
export {
  setCheckinCoachNote_createServerFn_handler
};
