import { c as createServerRpc } from "./createServerRpc--OrbljSy.mjs";
import { c as createServerFn } from "./server-g-lQHb1O.mjs";
import { r as requireSupabaseAuth } from "./auth-middleware-B5YcFrfv.mjs";

import "../_libs/seroval.mjs";
import "../_libs/react.mjs";

import "../_libs/h3-v2.mjs";
import "../_libs/unenv.mjs";


import "../_libs/rou3.mjs";
import "../_libs/srvx.mjs";





import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval-plugins.mjs";

import "../_libs/tanstack__react-router.mjs";
import "../_libs/react-dom.mjs";
import "../_libs/isbot.mjs";
import "../_libs/supabase__supabase-js.mjs";
import "../_libs/supabase__postgrest-js.mjs";
import "../_libs/supabase__realtime-js.mjs";
import "../_libs/supabase__phoenix.mjs";
import "../_libs/supabase__storage-js.mjs";
import "../_libs/iceberg-js.mjs";
import "../_libs/supabase__auth-js.mjs";
import "../_libs/tslib.mjs";
import "../_libs/supabase__functions-js.mjs";
const deleteOrgAthlete_createServerFn_handler = createServerRpc({
  id: "02921a5dcda5304c866ac9e29f0a6aaf8a331f9844038bb2c3f066c019a54391",
  name: "deleteOrgAthlete",
  filename: "src/lib/organizations/athlete-admin.functions.ts"
}, (opts) => deleteOrgAthlete.__executeServer(opts));
const deleteOrgAthlete = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((data) => data).handler(deleteOrgAthlete_createServerFn_handler, async ({
  data,
  context
}) => {
  const {
    supabase,
    userId
  } = context;
  if (data.user_id === userId) {
    throw new Error("Du kannst dein eigenes Konto nicht hier löschen.");
  }
  const [{
    data: isCoach
  }, {
    data: isAdmin
  }] = await Promise.all([supabase.rpc("has_role", {
    _user_id: userId,
    _role: "coach"
  }), supabase.rpc("is_org_admin", {
    _user: userId,
    _org: data.org_id
  })]);
  if (!isCoach && !isAdmin) {
    throw new Error("Keine Berechtigung, dieses Profil zu löschen.");
  }
  if (!isCoach) {
    const {
      data: mem
    } = await supabase.from("organization_memberships").select("id").eq("organization_id", data.org_id).eq("user_id", data.user_id).maybeSingle();
    if (!mem) throw new Error("Athlet gehört nicht zu diesem Verein.");
  }
  const {
    supabaseAdmin
  } = await import("./client.server-D5ro3rAQ.mjs");
  await supabaseAdmin.from("payment_history").delete().eq("user_id", data.user_id);
  await supabaseAdmin.from("customer_packages").delete().eq("user_id", data.user_id);
  await supabaseAdmin.from("staff_assignments").delete().eq("user_id", data.user_id);
  await supabaseAdmin.from("organization_memberships").delete().eq("user_id", data.user_id);
  await supabaseAdmin.from("user_roles").delete().eq("user_id", data.user_id);
  await supabaseAdmin.from("profiles").delete().eq("id", data.user_id);
  const {
    error
  } = await supabaseAdmin.auth.admin.deleteUser(data.user_id);
  if (error) throw new Error(error.message);
  return {
    ok: true
  };
});
const removeAthleteFromOrg_createServerFn_handler = createServerRpc({
  id: "c7bfb2a0a4f0f1c4975b4e9f6a39e4d4c3dc6a1a0ae4fd7bbea4d8f453103d24",
  name: "removeAthleteFromOrg",
  filename: "src/lib/organizations/athlete-admin.functions.ts"
}, (opts) => removeAthleteFromOrg.__executeServer(opts));
const removeAthleteFromOrg = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((data) => data).handler(removeAthleteFromOrg_createServerFn_handler, async ({
  data,
  context
}) => {
  const {
    supabase,
    userId
  } = context;
  if (data.user_id === userId) {
    throw new Error("Du kannst dich nicht selbst aus dem Team entfernen.");
  }
  const [{
    data: isCoach
  }, {
    data: isAdmin
  }] = await Promise.all([supabase.rpc("has_role", {
    _user_id: userId,
    _role: "coach"
  }), supabase.rpc("is_org_admin", {
    _user: userId,
    _org: data.org_id
  })]);
  if (!isCoach && !isAdmin) {
    throw new Error("Keine Berechtigung, Spieler aus diesem Team zu entfernen.");
  }
  const {
    supabaseAdmin
  } = await import("./client.server-D5ro3rAQ.mjs");
  await supabaseAdmin.from("staff_assignments").delete().eq("organization_id", data.org_id).eq("user_id", data.user_id);
  const {
    error
  } = await supabaseAdmin.from("organization_memberships").delete().eq("organization_id", data.org_id).eq("user_id", data.user_id);
  if (error) throw new Error(error.message);
  return {
    ok: true
  };
});
export {
  deleteOrgAthlete_createServerFn_handler,
  removeAthleteFromOrg_createServerFn_handler
};
