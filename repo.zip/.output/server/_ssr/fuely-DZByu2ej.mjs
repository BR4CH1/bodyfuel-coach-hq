import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import { e as useNavigate, L as Link } from "../_libs/tanstack__react-router.mjs";
import { v as Route$2c, a as useServerFn, F as Fuely, B as Button, D as Dialog, d as DialogContent, e as DialogHeader, f as DialogTitle, i as DialogFooter, I as Input } from "./router-BmNvgrMe.mjs";
import { a as useQueryClient, u as useQuery, b as useMutation } from "../_libs/tanstack__react-query.mjs";
import { s as supabase } from "./client-mgvTz6tP.mjs";
import { T as Textarea } from "./textarea-CAY_SJkd.mjs";
import { F as FuelyTimeline, S as ScrollArea } from "./FuelyTimeline-DRJna4Li.mjs";
import { l as listFuelyMessages, s as sendFuelyMessage, c as clearFuelyChat, S as Sheet, a as SheetTrigger, b as SheetContent, d as SheetHeader, e as SheetTitle, f as listFuelyMemories, u as upsertFuelyMemory, g as deleteFuelyMemory } from "./fuely.functions-CXxUj0hv.mjs";
import { B as Badge } from "./badge-BjIz1fOa.mjs";
import { t as toast } from "../_libs/sonner.mjs";
import "../_libs/idb.mjs";

import "../_libs/seroval.mjs";
import "../_libs/unenv.mjs";

import "../_libs/lovable.dev__mcp-js.mjs";
import "../_libs/modelcontextprotocol__sdk.mjs";
import "../_libs/zod-to-json-schema.mjs";
import "../_libs/ajv-formats.mjs";
import "../_libs/stripe.mjs";
import { aD as ArrowLeft, aN as Brain, o as Trash2, L as LoaderCircle, aO as Send, p as Sparkles } from "../_libs/lucide-react.mjs";
import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval-plugins.mjs";


import "../_libs/react-dom.mjs";
import "../_libs/isbot.mjs";
import "../_libs/tanstack__query-core.mjs";
import "../_libs/radix-ui__react-slot.mjs";
import "../_libs/radix-ui__react-compose-refs.mjs";
import "../_libs/class-variance-authority.mjs";
import "../_libs/clsx.mjs";
import "../_libs/tailwind-merge.mjs";
import "../_libs/radix-ui__react-switch.mjs";
import "../_libs/radix-ui__primitive.mjs";
import "../_libs/radix-ui__react-context.mjs";
import "../_libs/@radix-ui/react-use-controllable-state+[...].mjs";
import "../_libs/@radix-ui/react-use-layout-effect+[...].mjs";
import "../_libs/radix-ui__react-use-previous.mjs";
import "../_libs/radix-ui__react-use-size.mjs";
import "../_libs/radix-ui__react-primitive.mjs";
import "./createSsrRpc-r3tzPO1F.mjs";
import "./server-g-lQHb1O.mjs";
import "../_libs/h3-v2.mjs";
import "../_libs/rou3.mjs";
import "../_libs/srvx.mjs";






import "./auth-middleware-B5YcFrfv.mjs";
import "../_libs/supabase__supabase-js.mjs";
import "../_libs/supabase__postgrest-js.mjs";
import "../_libs/supabase__realtime-js.mjs";
import "../_libs/supabase__phoenix.mjs";
import "../_libs/supabase__storage-js.mjs";
import "../_libs/iceberg-js.mjs";
import "../_libs/supabase__auth-js.mjs";
import "../_libs/tslib.mjs";
import "../_libs/supabase__functions-js.mjs";
import "../_libs/radix-ui__react-label.mjs";
import "../_libs/tanstack__zod-adapter.mjs";
import "../_libs/zod.mjs";
import "../_libs/radix-ui__react-dialog.mjs";
import "../_libs/radix-ui__react-id.mjs";
import "../_libs/@radix-ui/react-dismissable-layer+[...].mjs";
import "../_libs/@radix-ui/react-use-callback-ref+[...].mjs";
import "../_libs/radix-ui__react-focus-scope.mjs";
import "../_libs/radix-ui__react-portal.mjs";
import "../_libs/radix-ui__react-presence.mjs";
import "../_libs/radix-ui__react-focus-guards.mjs";
import "../_libs/react-remove-scroll.mjs";
import "../_libs/react-remove-scroll-bar.mjs";
import "../_libs/react-style-singleton.mjs";
import "../_libs/get-nonce.mjs";
import "../_libs/use-sidecar.mjs";
import "../_libs/use-callback-ref.mjs";
import "../_libs/aria-hidden.mjs";
import "../_libs/radix-ui__react-checkbox.mjs";
import "./coach-analytics.rules-DadTu4Zq.mjs";
import "./football-positions-BJzdkmjv.mjs";
import "./athlete-training-session-pool-CmIQKgmz.mjs";
import "../_libs/lovable.dev__webhooks-js.mjs";
import "./registry-BHGsuy94.mjs";
import "../_libs/react-email__html.mjs";
import "../_libs/react-email__head.mjs";
import "../_libs/react-email__preview.mjs";
import "../_libs/react-email__body.mjs";
import "../_libs/react-email__container.mjs";
import "../_libs/react-email__section.mjs";
import "../_libs/react-email__heading.mjs";
import "../_libs/react-email__text.mjs";
import "../_libs/react-email__button.mjs";
import "../_libs/react-email__hr.mjs";
import "../_libs/react-email__img.mjs";
import "./task-engine.server-BbzZOvQb.mjs";
import "./stripe.server-mcZ3T1eX.mjs";
import "../_libs/lovable.dev__email-js.mjs";
import "../_libs/react-email__render.mjs";
import "../_libs/prettier.mjs";
import "../_libs/html-to-text.mjs";
import "../_libs/selderee__plugin-htmlparser2.mjs";
import "../_libs/selderee.mjs";
import "../_libs/parseley.mjs";
import "../_libs/leac.mjs";
import "../_libs/peberminta.mjs";
import "../_libs/domhandler.mjs";
import "../_libs/domelementtype.mjs";
import "../_libs/htmlparser2.mjs";
import "../_libs/entities.mjs";
import "../_libs/deepmerge.mjs";
import "../_libs/dom-serializer.mjs";
import "../_libs/react-email__link.mjs";
import "../_libs/jose.mjs";
import "../_libs/ajv.mjs";
import "../_libs/fast-deep-equal.mjs";
import "../_libs/json-schema-traverse.mjs";
import "../_libs/fast-uri.mjs";
import "../_libs/radix-ui__react-scroll-area.mjs";
import "../_libs/radix-ui__react-direction.mjs";
import "../_libs/radix-ui__number.mjs";
const QUICK_ACTIONS = [{
  emoji: "🍽",
  label: "Ernährung analysieren",
  prompt: "Analysiere meine heutige Ernährung — bin ich auf Kurs bei Kalorien und Protein?"
}, {
  emoji: "🏋",
  label: "Trainingsplan erklären",
  prompt: "Erkläre mir kurz meinen aktuellen Trainingsplan und was heute wichtig ist."
}, {
  emoji: "📈",
  label: "Fortschritt bewerten",
  prompt: "Wie steht's um meinen Fortschritt der letzten 2 Wochen? Ehrliche Einschätzung bitte."
}, {
  emoji: "🥤",
  label: "Tagesziele",
  prompt: "Was sind heute meine wichtigsten Ziele und was fehlt mir noch?"
}, {
  emoji: "🔥",
  label: "Motivation",
  prompt: "Ich brauch' kurz einen Motivationsschub."
}, {
  emoji: "🎯",
  label: "Challenge finden",
  prompt: "Schlag mir eine passende Challenge oder ein Mini-Ziel für die nächste Woche vor."
}];
function PersonalFuelyPage() {
  const search = Route$2c.useSearch();
  const tab = search.tab;
  const navigate = useNavigate();
  const qc = useQueryClient();
  const setTab = (next) => navigate({
    to: "/fuely",
    search: {
      tab: next
    },
    replace: true
  });
  const [userId, setUserId] = reactExports.useState(null);
  const [firstName, setFirstName] = reactExports.useState("");
  const [input, setInput] = reactExports.useState("");
  const [showMemories, setShowMemories] = reactExports.useState(false);
  const [showClear, setShowClear] = reactExports.useState(false);
  const scrollRef = reactExports.useRef(null);
  const inputRef = reactExports.useRef(null);
  reactExports.useEffect(() => {
    supabase.auth.getUser().then(async ({
      data
    }) => {
      if (!data.user) {
        navigate({
          to: "/auth"
        });
        return;
      }
      setUserId(data.user.id);
      const {
        data: prof
      } = await supabase.from("profiles").select("display_name").eq("id", data.user.id).maybeSingle();
      const dn = prof?.display_name?.trim() ?? "";
      setFirstName(dn ? dn.split(/\s+/)[0] : "");
    });
  }, [navigate]);
  const listFn = useServerFn(listFuelyMessages);
  const sendFn = useServerFn(sendFuelyMessage);
  const clearFn = useServerFn(clearFuelyChat);
  const messagesQ = useQuery({
    queryKey: ["fuely-messages", userId],
    enabled: !!userId,
    queryFn: () => listFn()
  });
  const messages = messagesQ.data?.items ?? [];
  const sendMutation = useMutation({
    mutationFn: (content) => sendFn({
      data: {
        content
      }
    }),
    onMutate: async (content) => {
      qc.setQueryData(["fuely-messages", userId], (prev) => ({
        items: [...prev?.items ?? [], {
          id: `optim-${Date.now()}`,
          role: "user",
          content,
          created_at: (/* @__PURE__ */ new Date()).toISOString()
        }]
      }));
    },
    onSuccess: (res) => {
      if (res?.nav?.path) {
        toast(res.nav.label ?? "Öffnen", {
          action: {
            label: "Los",
            onClick: () => navigate({
              to: res.nav.path
            })
          }
        });
      }
      qc.invalidateQueries({
        queryKey: ["fuely-messages", userId]
      });
    },
    onError: (e) => {
      toast.error(e?.message ?? "Fuely konnte nicht antworten");
      qc.invalidateQueries({
        queryKey: ["fuely-messages", userId]
      });
    }
  });
  const clearMutation = useMutation({
    mutationFn: () => clearFn(),
    onSuccess: () => {
      setShowClear(false);
      qc.invalidateQueries({
        queryKey: ["fuely-messages", userId]
      });
    }
  });
  reactExports.useEffect(() => {
    const el = scrollRef.current;
    if (el) el.scrollTop = el.scrollHeight;
  }, [messages.length, sendMutation.isPending]);
  reactExports.useEffect(() => {
    inputRef.current?.focus();
  }, [messages.length, sendMutation.isPending]);
  function submit(text) {
    const content = (text ?? input).trim();
    if (!content || sendMutation.isPending) return;
    setInput("");
    sendMutation.mutate(content);
  }
  const isEmpty = messages.length === 0 && !messagesQ.isLoading;
  const emotion = sendMutation.isPending ? "thinking" : isEmpty ? "waving" : "happy";
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex min-h-[100dvh] flex-col bg-background text-foreground", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("header", { className: "sticky top-0 z-30 flex items-center gap-3 border-b border-border bg-card/95 px-4 py-3 backdrop-blur", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/dashboard", "aria-label": "Zurück", className: "rounded-full p-1.5 hover:bg-muted", children: /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowLeft, { className: "h-5 w-5" }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Fuely, { emotion, size: "sm", animation: sendMutation.isPending ? "wiggle" : "idle" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-display text-base font-bold leading-tight", children: "Fuely" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[11px] text-muted-foreground", children: "Dein persönlicher BodyFuel Coach" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(Sheet, { open: showMemories, onOpenChange: setShowMemories, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(SheetTrigger, { asChild: true, children: /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { variant: "ghost", size: "icon", "aria-label": "Erinnerungen", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Brain, { className: "h-5 w-5" }) }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(SheetContent, { side: "right", className: "w-full max-w-md sm:max-w-md", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(SheetHeader, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(SheetTitle, { children: "Fuely Memory" }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(FuelyMemoryPanel, { userId })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { variant: "ghost", size: "icon", "aria-label": "Chat leeren", onClick: () => setShowClear(true), children: /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "h-5 w-5" }) })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "border-b border-border bg-card/60 px-4", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mx-auto flex max-w-2xl gap-1 py-2", children: ["chat", "timeline"].map((t) => /* @__PURE__ */ jsxRuntimeExports.jsx("button", { type: "button", onClick: () => setTab(t), className: `rounded-full px-4 py-1.5 text-xs font-semibold uppercase tracking-wider transition ${tab === t ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:bg-muted"}`, children: t === "chat" ? "Chat" : "Timeline" }, t)) }) }),
    tab === "timeline" ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mx-auto w-full max-w-2xl flex-1 px-4 py-4", children: /* @__PURE__ */ jsxRuntimeExports.jsx(FuelyTimeline, {}) }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(ScrollArea, { className: "flex-1", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { ref: scrollRef, className: "mx-auto flex max-w-2xl flex-col gap-3 px-4 py-4", children: [
        isEmpty && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-6 flex flex-col items-center gap-4 text-center", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Fuely, { emotion: "waving", size: "xl", animation: "float" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "font-display text-2xl font-bold", children: [
              "👋 Hallo",
              firstName ? ` ${firstName}` : ""
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-display text-lg font-semibold", children: "Ich bin Fuely." }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "max-w-sm text-sm text-muted-foreground", children: "Dein smarter Begleiter für Training, Ernährung und Gesundheit. Frag mich alles — ich kenne deine Daten und helfe dir, dranzubleiben." })
          ] })
        ] }),
        messages.map((m) => /* @__PURE__ */ jsxRuntimeExports.jsx(MessageBubble, { m }, m.id)),
        sendMutation.isPending && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-end gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Fuely, { emotion: "thinking", size: "xs", animation: "wiggle" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1 rounded-2xl rounded-bl-sm bg-muted px-3 py-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "h-1.5 w-1.5 animate-bounce rounded-full bg-foreground/60 [animation-delay:0ms]" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "h-1.5 w-1.5 animate-bounce rounded-full bg-foreground/60 [animation-delay:120ms]" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "h-1.5 w-1.5 animate-bounce rounded-full bg-foreground/60 [animation-delay:240ms]" })
          ] })
        ] })
      ] }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "border-t border-border bg-card/70 px-3 pt-2", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mx-auto flex max-w-2xl gap-2 overflow-x-auto pb-2 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden", children: QUICK_ACTIONS.map((qa) => /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { type: "button", onClick: () => submit(qa.prompt), disabled: sendMutation.isPending, className: "shrink-0 rounded-full border border-border bg-background px-3 py-1.5 text-xs font-medium transition hover:bg-muted disabled:opacity-50", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "mr-1", children: qa.emoji }),
        qa.label
      ] }, qa.label)) }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "border-t border-border bg-background px-3 py-3", style: {
        paddingBottom: "max(0.75rem, env(safe-area-inset-bottom))"
      }, children: /* @__PURE__ */ jsxRuntimeExports.jsxs("form", { className: "mx-auto flex max-w-2xl items-end gap-2", onSubmit: (e) => {
        e.preventDefault();
        submit();
      }, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Textarea, { ref: inputRef, value: input, onChange: (e) => setInput(e.target.value), onKeyDown: (e) => {
          if (e.key === "Enter" && !e.shiftKey) {
            e.preventDefault();
            submit();
          }
        }, placeholder: "Frag Fuely alles ...", rows: 1, className: "min-h-[44px] max-h-40 resize-none", disabled: sendMutation.isPending }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { type: "submit", size: "icon", className: "h-11 w-11 shrink-0", disabled: !input.trim() || sendMutation.isPending, children: sendMutation.isPending ? /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "h-5 w-5 animate-spin" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Send, { className: "h-5 w-5" }) })
      ] }) })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(Dialog, { open: showClear, onOpenChange: setShowClear, children: /* @__PURE__ */ jsxRuntimeExports.jsxs(DialogContent, { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(DialogHeader, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(DialogTitle, { children: "Chat mit Fuely leeren?" }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-muted-foreground", children: "Der gesamte Chatverlauf wird gelöscht. Deine langfristigen Erinnerungen (Memory) bleiben erhalten." }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(DialogFooter, { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { variant: "ghost", onClick: () => setShowClear(false), children: "Abbrechen" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { variant: "destructive", onClick: () => clearMutation.mutate(), disabled: clearMutation.isPending, children: "Löschen" })
      ] })
    ] }) })
  ] });
}
function MessageBubble({
  m
}) {
  const isUser = m.role === "user";
  if (isUser) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex justify-end", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "max-w-[80%] whitespace-pre-wrap rounded-2xl rounded-br-sm bg-primary px-3.5 py-2 text-sm text-primary-foreground shadow-sm", children: m.content }) });
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-end gap-2", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(Fuely, { emotion: "happy", size: "xs", className: "mb-1" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "max-w-[85%] whitespace-pre-wrap rounded-2xl rounded-bl-sm bg-muted px-3.5 py-2 text-sm", children: m.content })
  ] });
}
function FuelyMemoryPanel({
  userId
}) {
  const qc = useQueryClient();
  const listFn = useServerFn(listFuelyMemories);
  const upsertFn = useServerFn(upsertFuelyMemory);
  const delFn = useServerFn(deleteFuelyMemory);
  const memQ = useQuery({
    queryKey: ["fuely-memories", userId],
    enabled: !!userId,
    queryFn: () => listFn()
  });
  const [newContent, setNewContent] = reactExports.useState("");
  const [newCategory, setNewCategory] = reactExports.useState("general");
  const addMutation = useMutation({
    mutationFn: () => upsertFn({
      data: {
        content: newContent,
        category: newCategory,
        importance: 3
      }
    }),
    onSuccess: () => {
      setNewContent("");
      qc.invalidateQueries({
        queryKey: ["fuely-memories", userId]
      });
    }
  });
  const delMutation = useMutation({
    mutationFn: (id) => delFn({
      data: {
        id
      }
    }),
    onSuccess: () => qc.invalidateQueries({
      queryKey: ["fuely-memories", userId]
    })
  });
  const items = memQ.data?.items ?? [];
  const byCat = reactExports.useMemo(() => {
    const m = /* @__PURE__ */ new Map();
    items.forEach((it) => {
      if (!m.has(it.category)) m.set(it.category, []);
      m.get(it.category).push(it);
    });
    return Array.from(m.entries());
  }, [items]);
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-4 flex h-[calc(100dvh-8rem)] flex-col gap-4", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start gap-3 rounded-lg border border-border bg-muted/40 p-3 text-xs text-muted-foreground", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Sparkles, { className: "mt-0.5 h-4 w-4 shrink-0 text-primary" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: "Das merkt sich Fuely dauerhaft über dich (Ziele, Vorlieben, Verletzungen usw.). Du kannst jederzeit Einträge hinzufügen, ändern oder löschen." })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2 rounded-lg border border-border p-3", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs font-semibold uppercase tracking-wider text-muted-foreground", children: "Neue Erinnerung" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { placeholder: "Kategorie (z.B. goal, allergy, injury)", value: newCategory, onChange: (e) => setNewCategory(e.target.value), className: "max-w-[45%]" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { placeholder: "z.B. Zielgewicht 92 kg", value: newContent, onChange: (e) => setNewContent(e.target.value), onKeyDown: (e) => {
          if (e.key === "Enter" && newContent.trim()) addMutation.mutate();
        } })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { size: "sm", onClick: () => addMutation.mutate(), disabled: !newContent.trim() || addMutation.isPending, children: "Speichern" })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(ScrollArea, { className: "flex-1", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4 pr-2", children: [
      memQ.isLoading && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-sm text-muted-foreground", children: "Lade …" }),
      !memQ.isLoading && items.length === 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "rounded-lg border border-dashed border-border p-4 text-center text-sm text-muted-foreground", children: "Noch keine Erinnerungen. Fuely legt sie automatisch an, während ihr chattet." }),
      byCat.map(([cat, list]) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Badge, { variant: "secondary", className: "uppercase", children: cat }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs text-muted-foreground", children: list.length })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("ul", { className: "space-y-1.5", children: list.map((it) => /* @__PURE__ */ jsxRuntimeExports.jsxs("li", { className: "flex items-start justify-between gap-2 rounded-md border border-border bg-background px-3 py-2 text-sm", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "flex-1", children: it.content }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("button", { type: "button", onClick: () => delMutation.mutate(it.id), className: "shrink-0 text-muted-foreground hover:text-destructive", "aria-label": "Löschen", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "h-4 w-4" }) })
        ] }, it.id)) })
      ] }, cat))
    ] }) })
  ] });
}
export {
  PersonalFuelyPage as component
};
