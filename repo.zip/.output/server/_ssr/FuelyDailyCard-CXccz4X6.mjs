import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import { a as useServerFn, c as cn } from "./router-BmNvgrMe.mjs";
import { e as useNavigate } from "../_libs/tanstack__react-router.mjs";
import { a as useQueryClient, u as useQuery } from "../_libs/tanstack__react-query.mjs";
import { c as createSsrRpc } from "./createSsrRpc-r3tzPO1F.mjs";
import { c as createServerFn } from "./server-g-lQHb1O.mjs";
import { r as requireSupabaseAuth } from "./auth-middleware-B5YcFrfv.mjs";
import { C as Card } from "./card-DtZk7YzY.mjs";
import { ae as Moon, p as Sparkles, L as LoaderCircle, aq as MessageCircle } from "../_libs/lucide-react.mjs";
const getFuelyDailyNote = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((input) => {
  if (input?.kind !== "morning" && input?.kind !== "evening") throw new Error("invalid kind");
  return input;
}).handler(createSsrRpc("51c1ed597b35fd4ae604b62a35cc28d416a419a0dfa2ddfe1230e838ff4199c5"));
const markFuelyDailyRead = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((input) => input).handler(createSsrRpc("87ae78bd959e0c6a2c8490c63cb6e0b26bbfe053197c6f723967af5081784342"));
function FuelyDailyCard({ orgSlug, className }) {
  const hour = (/* @__PURE__ */ new Date()).getHours();
  const kind = hour >= 18 || hour < 4 ? "evening" : "morning";
  const fetchNote = useServerFn(getFuelyDailyNote);
  const markRead = useServerFn(markFuelyDailyRead);
  const navigate = useNavigate();
  const qc = useQueryClient();
  const q = useQuery({
    queryKey: ["fuely-daily", kind],
    queryFn: () => fetchNote({ data: { kind } }),
    staleTime: 60 * 60 * 1e3,
    retry: 0
  });
  const note = q.data;
  const isEvening = kind === "evening";
  const Icon = isEvening ? Moon : Sparkles;
  const markedRef = reactExports.useRef(false);
  reactExports.useEffect(() => {
    if (!note?.id || note.read_at || markedRef.current) return;
    const t = setTimeout(async () => {
      markedRef.current = true;
      try {
        await markRead({ data: { id: note.id } });
        qc.setQueryData(["fuely-daily", kind], { ...note, read_at: (/* @__PURE__ */ new Date()).toISOString() });
      } catch {
      }
    }, 3e3);
    return () => clearTimeout(t);
  }, [note?.id, note?.read_at, kind, markRead, qc]);
  if (note?.read_at) return null;
  const openChat = async () => {
    if (note?.id && !note.read_at) {
      try {
        await markRead({ data: { id: note.id } });
        qc.setQueryData(["fuely-daily", kind], { ...note, read_at: (/* @__PURE__ */ new Date()).toISOString() });
      } catch {
      }
    }
    navigate({ to: "/$orgSlug/fuely", params: { orgSlug } });
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsx(
    Card,
    {
      onClick: openChat,
      className: cn(
        "relative overflow-hidden cursor-pointer transition-all hover:scale-[1.01] active:scale-[0.99]",
        "border-primary/20 bg-gradient-to-br from-primary/10 via-background to-background",
        "p-4 shadow-md",
        className
      ),
      children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start gap-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "div",
          {
            className: cn(
              "flex h-10 w-10 shrink-0 items-center justify-center rounded-full",
              "bg-gradient-to-br from-primary to-primary/60 text-primary-foreground shadow-inner"
            ),
            children: /* @__PURE__ */ jsxRuntimeExports.jsx(Icon, { className: "h-5 w-5" })
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0 flex-1", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 mb-1", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs font-semibold uppercase tracking-wide text-primary", children: isEvening ? "Abend-Rückblick von Fuely" : "Fuely am Morgen" }),
            note && !note.read_at ? /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "h-2 w-2 rounded-full bg-primary animate-pulse" }) : null
          ] }),
          q.isLoading ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 text-sm text-muted-foreground py-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "h-4 w-4 animate-spin" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
              "Fuely bereitet ",
              isEvening ? "deinen Rückblick" : "dein Briefing",
              " vor…"
            ] })
          ] }) : q.isError || !note?.content ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-sm text-muted-foreground", children: "Fuely meldet sich später bei dir. Tipp an, um zu chatten. 💚" }) : /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "whitespace-pre-line text-sm leading-relaxed text-foreground", children: note.content }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-3 flex items-center gap-1 text-xs text-muted-foreground", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(MessageCircle, { className: "h-3.5 w-3.5" }),
            "Antippen, um mit Fuely weiterzureden"
          ] })
        ] })
      ] })
    }
  );
}
export {
  FuelyDailyCard as F
};
