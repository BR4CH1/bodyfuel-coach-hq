import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import { L as Link } from "../_libs/tanstack__react-router.mjs";
import { a as useServerFn, u as useSession, L as Label, I as Input$1, B as Button } from "./router-BmNvgrMe.mjs";
import { c as createSsrRpc } from "./createSsrRpc-r3tzPO1F.mjs";
import { c as createServerFn } from "./server-g-lQHb1O.mjs";
import { r as requireSupabaseAuth } from "./auth-middleware-B5YcFrfv.mjs";
import { s as supabase } from "./client-mgvTz6tP.mjs";
import { T as Textarea } from "./textarea-CAY_SJkd.mjs";
import { t as toast } from "../_libs/sonner.mjs";
import "../_libs/idb.mjs";
import "../_libs/unenv.mjs";

import "../_libs/lovable.dev__mcp-js.mjs";
import "../_libs/modelcontextprotocol__sdk.mjs";
import "../_libs/zod-to-json-schema.mjs";
import "../_libs/ajv-formats.mjs";
import "../_libs/stripe.mjs";

import "../_libs/seroval.mjs";
import { p as Sparkles, ay as Save } from "../_libs/lucide-react.mjs";
import { a as objectType, H as enumType, C as numberType, y as stringType } from "../_libs/zod.mjs";
import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval-plugins.mjs";


import "../_libs/react-dom.mjs";
import "../_libs/isbot.mjs";
import "../_libs/tanstack__query-core.mjs";
import "../_libs/tanstack__react-query.mjs";
import "../_libs/radix-ui__react-slot.mjs";
import "../_libs/radix-ui__react-compose-refs.mjs";
import "../_libs/class-variance-authority.mjs";
import "../_libs/clsx.mjs";
import "../_libs/tailwind-merge.mjs";
import "../_libs/radix-ui__react-switch.mjs";
import "../_libs/radix-ui__primitive.mjs";
import "../_libs/radix-ui__react-context.mjs";
import "../_libs/@radix-ui/react-use-controllable-state+[...].mjs";
import "../_libs/@radix-ui/react-use-layout-effect+[...].mjs";
import "../_libs/radix-ui__react-use-previous.mjs";
import "../_libs/radix-ui__react-use-size.mjs";
import "../_libs/radix-ui__react-primitive.mjs";
import "../_libs/radix-ui__react-label.mjs";
import "../_libs/tanstack__zod-adapter.mjs";
import "../_libs/supabase__supabase-js.mjs";
import "../_libs/supabase__postgrest-js.mjs";
import "../_libs/supabase__realtime-js.mjs";
import "../_libs/supabase__phoenix.mjs";
import "../_libs/supabase__storage-js.mjs";

import "../_libs/iceberg-js.mjs";
import "../_libs/supabase__auth-js.mjs";
import "../_libs/tslib.mjs";
import "../_libs/supabase__functions-js.mjs";

import "../_libs/radix-ui__react-dialog.mjs";
import "../_libs/radix-ui__react-id.mjs";
import "../_libs/@radix-ui/react-dismissable-layer+[...].mjs";
import "../_libs/@radix-ui/react-use-callback-ref+[...].mjs";
import "../_libs/radix-ui__react-focus-scope.mjs";
import "../_libs/radix-ui__react-portal.mjs";
import "../_libs/radix-ui__react-presence.mjs";
import "../_libs/radix-ui__react-focus-guards.mjs";
import "../_libs/react-remove-scroll.mjs";
import "../_libs/react-remove-scroll-bar.mjs";
import "../_libs/react-style-singleton.mjs";
import "../_libs/get-nonce.mjs";
import "../_libs/use-sidecar.mjs";
import "../_libs/use-callback-ref.mjs";
import "../_libs/aria-hidden.mjs";
import "../_libs/radix-ui__react-checkbox.mjs";
import "./coach-analytics.rules-DadTu4Zq.mjs";
import "./football-positions-BJzdkmjv.mjs";
import "./athlete-training-session-pool-CmIQKgmz.mjs";
import "../_libs/lovable.dev__webhooks-js.mjs";
import "./registry-BHGsuy94.mjs";
import "../_libs/react-email__html.mjs";
import "../_libs/react-email__head.mjs";
import "../_libs/react-email__preview.mjs";
import "../_libs/react-email__body.mjs";
import "../_libs/react-email__container.mjs";
import "../_libs/react-email__section.mjs";
import "../_libs/react-email__heading.mjs";
import "../_libs/react-email__text.mjs";
import "../_libs/react-email__button.mjs";
import "../_libs/react-email__hr.mjs";
import "../_libs/react-email__img.mjs";
import "./task-engine.server-BbzZOvQb.mjs";
import "./stripe.server-mcZ3T1eX.mjs";
import "../_libs/lovable.dev__email-js.mjs";
import "../_libs/react-email__render.mjs";
import "../_libs/prettier.mjs";
import "../_libs/html-to-text.mjs";
import "../_libs/selderee__plugin-htmlparser2.mjs";
import "../_libs/selderee.mjs";
import "../_libs/parseley.mjs";
import "../_libs/leac.mjs";
import "../_libs/peberminta.mjs";
import "../_libs/domhandler.mjs";
import "../_libs/domelementtype.mjs";
import "../_libs/htmlparser2.mjs";
import "../_libs/entities.mjs";
import "../_libs/deepmerge.mjs";
import "../_libs/dom-serializer.mjs";
import "../_libs/react-email__link.mjs";
import "../_libs/h3-v2.mjs";
import "../_libs/rou3.mjs";
import "../_libs/srvx.mjs";




import "../_libs/jose.mjs";
import "../_libs/ajv.mjs";
import "../_libs/fast-deep-equal.mjs";
import "../_libs/json-schema-traverse.mjs";
import "../_libs/fast-uri.mjs";
const Input = objectType({
  target_group: stringType().min(1).max(200),
  goal: stringType().min(1).max(200),
  equipment: stringType().max(300).optional().default(""),
  duration_minutes: numberType().int().min(10).max(120).default(45),
  intensity: enumType(["easy", "medium", "hard"]).default("medium")
});
const generateCourse = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => Input.parse(d)).handler(createSsrRpc("2f0888119aa08fee5398805b4998514da47370f0b650f91723763498e6da5d25"));
const PHASE_LABEL = {
  warmup: "Warm-up",
  main: "Hauptteil",
  finisher: "Finisher",
  cooldown: "Cool-down"
};
function AiGeneratorPage() {
  const gen = useServerFn(generateCourse);
  const {
    supabaseUser
  } = useSession();
  const [targetGroup, setTargetGroup] = reactExports.useState("Erwachsene, gemischt, Anfänger bis Fortgeschritten");
  const [goal, setGoal] = reactExports.useState("Ganzkörper-Fatburn");
  const [equipment, setEquipment] = reactExports.useState("Matte, Kurzhanteln");
  const [duration, setDuration] = reactExports.useState(45);
  const [intensity, setIntensity] = reactExports.useState("medium");
  const [loading, setLoading] = reactExports.useState(false);
  const [result, setResult] = reactExports.useState(null);
  const run = async () => {
    setLoading(true);
    try {
      const r = await gen({
        data: {
          target_group: targetGroup,
          goal,
          equipment,
          duration_minutes: duration,
          intensity
        }
      });
      setResult(r);
    } catch (e) {
      toast.error(e?.message ?? "Fehler beim Generieren");
    } finally {
      setLoading(false);
    }
  };
  const saveAsTemplate = async () => {
    if (!result || !supabaseUser) return;
    const {
      error
    } = await supabase.from("course_templates").insert({
      owner_id: supabaseUser.id,
      name: result.name,
      description: result.summary,
      duration_minutes: duration,
      target_group: targetGroup,
      equipment: equipment.split(",").map((s) => s.trim()).filter(Boolean),
      blocks: result.blocks
    });
    if (error) return toast.error(error.message);
    toast.success("Als Vorlage gespeichert");
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-6", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("header", { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs uppercase tracking-widest text-gold", children: "Coach Tools" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "font-display text-2xl font-bold", children: "KI-Kursgenerator" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-muted-foreground", children: "Beschreibe Zielgruppe & Ziel — die KI baut Warm-up, Hauptteil, Finisher und Cool-down." })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid gap-4 rounded-2xl border border-border bg-card/60 p-5 backdrop-blur md:grid-cols-2", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { children: "Zielgruppe" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Textarea, { value: targetGroup, onChange: (e) => setTargetGroup(e.target.value), rows: 2 })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { children: "Trainingsziel" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Textarea, { value: goal, onChange: (e) => setGoal(e.target.value), rows: 2 })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { children: "Equipment" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Input$1, { value: equipment, onChange: (e) => setEquipment(e.target.value) })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-2 gap-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { children: "Dauer (Min)" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Input$1, { type: "number", value: duration, onChange: (e) => setDuration(Number(e.target.value) || 45) })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { children: "Intensität" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("select", { value: intensity, onChange: (e) => setIntensity(e.target.value), className: "mt-1 w-full rounded-md border border-border bg-background p-2 text-sm", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "easy", children: "Leicht" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "medium", children: "Mittel" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "hard", children: "Hart" })
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "md:col-span-2", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { onClick: run, disabled: loading, className: "bg-gradient-gold", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Sparkles, { className: "mr-2 h-4 w-4" }),
        " ",
        loading ? "Generiere…" : "Kurs generieren"
      ] }) })
    ] }),
    result && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "rounded-2xl border border-gold/40 bg-card/60 p-5 backdrop-blur", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-start justify-between gap-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-display text-2xl font-bold", children: result.name }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-1 text-sm text-muted-foreground", children: result.summary })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { onClick: saveAsTemplate, variant: "outline", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Save, { className: "mr-2 h-4 w-4" }),
            " Als Vorlage speichern"
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/coach-tools/live", className: "inline-flex items-center rounded-md bg-gradient-gold px-4 py-2 text-sm font-medium text-primary-foreground", children: "Live starten" })
        ] })
      ] }) }),
      result.blocks.map((b, i) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl border border-border bg-card/40 p-5", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-2 flex items-center justify-between", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[10px] uppercase tracking-widest text-gold", children: PHASE_LABEL[b.phase] ?? b.phase }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-display text-lg font-bold", children: b.title })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-xs text-muted-foreground", children: [
            Math.round(b.duration_seconds / 60),
            " min · ",
            b.timer_type
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("ul", { className: "space-y-1 text-sm", children: b.exercises.map((e, j) => /* @__PURE__ */ jsxRuntimeExports.jsxs("li", { className: "flex justify-between gap-2 border-b border-border/40 py-1.5 last:border-0", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
            e.name,
            e.cue ? /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "ml-2 text-xs italic text-muted-foreground", children: [
              "– ",
              e.cue
            ] }) : null
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs text-muted-foreground", children: e.work_sec ? `${e.work_sec}s${e.rest_sec ? ` / ${e.rest_sec}s` : ""}` : e.reps ?? "" })
        ] }, j)) }),
        b.notes && /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "mt-2 text-xs italic text-muted-foreground", children: [
          "💡 ",
          b.notes
        ] })
      ] }, i))
    ] })
  ] });
}
export {
  AiGeneratorPage as component
};
