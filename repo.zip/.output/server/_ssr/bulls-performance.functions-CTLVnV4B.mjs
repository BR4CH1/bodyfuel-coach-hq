import { c as createServerRpc } from "./createServerRpc--OrbljSy.mjs";
import { c as createServerFn } from "./server-g-lQHb1O.mjs";
import { r as requireSupabaseAuth } from "./auth-middleware-B5YcFrfv.mjs";

import "../_libs/seroval.mjs";
import "../_libs/react.mjs";
import { a as objectType, y as stringType, H as enumType, C as numberType } from "../_libs/zod.mjs";

import "../_libs/h3-v2.mjs";
import "../_libs/unenv.mjs";


import "../_libs/rou3.mjs";
import "../_libs/srvx.mjs";





import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval-plugins.mjs";

import "../_libs/tanstack__react-router.mjs";
import "../_libs/react-dom.mjs";
import "../_libs/isbot.mjs";
import "../_libs/supabase__supabase-js.mjs";
import "../_libs/supabase__postgrest-js.mjs";
import "../_libs/supabase__realtime-js.mjs";
import "../_libs/supabase__phoenix.mjs";
import "../_libs/supabase__storage-js.mjs";
import "../_libs/iceberg-js.mjs";
import "../_libs/supabase__auth-js.mjs";
import "../_libs/tslib.mjs";
import "../_libs/supabase__functions-js.mjs";
const BUCKET = "bulls-performance-videos";
async function assertBulls(supabase, userId) {
  const {
    data,
    error
  } = await supabase.rpc("has_group", {
    _user_id: userId,
    _group: "bulls"
  });
  if (error) throw new Error(error.message);
  if (!data) throw new Error("Kein Bulls-Zugang");
}
async function isCoachOrStaff(supabase, userId) {
  const [{
    data: coachRow
  }, {
    data: staffRows
  }] = await Promise.all([supabase.rpc("has_role", {
    _user_id: userId,
    _role: "coach"
  }), supabase.from("staff_assignments").select("role, organization:organizations!inner(slug, status)").eq("user_id", userId).in("role", ["organization_admin", "coach"]).eq("organization.slug", "bulls").eq("organization.status", "active").limit(1)]);
  return !!coachRow || Array.isArray(staffRows) && staffRows.length > 0;
}
const getMyPerformanceAccess_createServerFn_handler = createServerRpc({
  id: "5d10f7c06d2cf684bed2ad6334fc27c30cae2cf300ea2924d365bfab5da49641",
  name: "getMyPerformanceAccess",
  filename: "src/lib/bulls-performance.functions.ts"
}, (opts) => getMyPerformanceAccess.__executeServer(opts));
const getMyPerformanceAccess = createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).handler(getMyPerformanceAccess_createServerFn_handler, async ({
  context
}) => {
  const canCoach = await isCoachOrStaff(context.supabase, context.userId);
  return {
    canCoach
  };
});
const listMyPerformanceTests_createServerFn_handler = createServerRpc({
  id: "206117e8e4381055e8fb17351049faf430893544d8dd9c8d404cca724299d117",
  name: "listMyPerformanceTests",
  filename: "src/lib/bulls-performance.functions.ts"
}, (opts) => listMyPerformanceTests.__executeServer(opts));
const listMyPerformanceTests = createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).handler(listMyPerformanceTests_createServerFn_handler, async ({
  context
}) => {
  await assertBulls(context.supabase, context.userId);
  const {
    data,
    error
  } = await context.supabase.from("bulls_performance_tests").select("*").eq("user_id", context.userId).order("performed_at", {
    ascending: false
  });
  if (error) throw new Error(error.message);
  return data ?? [];
});
const submitSchema = objectType({
  module_id: stringType().min(1),
  test_id: stringType().min(1),
  variant: stringType().optional().nullable(),
  result_value: numberType().finite(),
  result_unit: enumType(["s", "cm", "kg"]),
  reps: numberType().int().positive().optional().nullable(),
  rir: numberType().min(0).max(10).optional().nullable(),
  bodyweight_kg: numberType().positive().optional().nullable(),
  measurement_method: enumType(["hand", "video", "timing_gates"]).optional().nullable(),
  surface: enumType(["grass", "turf", "indoor", "track", "other"]).optional().nullable(),
  footwear: enumType(["cleats", "turfs", "runners", "indoor", "other"]).optional().nullable(),
  video_path: stringType().optional().nullable(),
  performed_at: stringType().optional().nullable()
});
const submitPerformanceTest_createServerFn_handler = createServerRpc({
  id: "d55c5e060513c629618cae330d699756f52460fa527d73bfadd33df2364eb34a",
  name: "submitPerformanceTest",
  filename: "src/lib/bulls-performance.functions.ts"
}, (opts) => submitPerformanceTest.__executeServer(opts));
const submitPerformanceTest = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((raw) => submitSchema.parse(raw)).handler(submitPerformanceTest_createServerFn_handler, async ({
  data,
  context
}) => {
  await assertBulls(context.supabase, context.userId);
  const {
    data: prof
  } = await context.supabase.from("bulls_profiles").select("position").eq("user_id", context.userId).maybeSingle();
  const payload = {
    user_id: context.userId,
    performance_profile: "football_bulls",
    module_id: data.module_id,
    test_id: data.test_id,
    variant: data.variant ?? null,
    position_snapshot: prof?.position ?? null,
    result_value: data.result_value,
    result_unit: data.result_unit,
    reps: data.reps ?? null,
    rir: data.rir ?? null,
    bodyweight_kg: data.bodyweight_kg ?? null,
    measurement_method: data.measurement_method ?? null,
    surface: data.surface ?? null,
    footwear: data.footwear ?? null,
    video_path: data.video_path ?? null,
    video_uploaded_at: data.video_path ? (/* @__PURE__ */ new Date()).toISOString() : null,
    verification_status: "submitted",
    performed_at: data.performed_at ?? (/* @__PURE__ */ new Date()).toISOString()
  };
  const {
    data: row,
    error
  } = await context.supabase.from("bulls_performance_tests").insert(payload).select("*").single();
  if (error) throw new Error(error.message);
  return row;
});
const createVideoUploadUrl_createServerFn_handler = createServerRpc({
  id: "634db22450e1605406f52b05fab5cde72abfd9d6344397d825c7f0b87d2cf983",
  name: "createVideoUploadUrl",
  filename: "src/lib/bulls-performance.functions.ts"
}, (opts) => createVideoUploadUrl.__executeServer(opts));
const createVideoUploadUrl = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => d).handler(createVideoUploadUrl_createServerFn_handler, async ({
  data,
  context
}) => {
  await assertBulls(context.supabase, context.userId);
  const ext = (data.ext || "mp4").replace(/[^a-z0-9]/gi, "").toLowerCase().slice(0, 5) || "mp4";
  const rand = crypto.randomUUID();
  const path = `${context.userId}/${data.test_id}/${rand}.${ext}`;
  const {
    data: signed,
    error
  } = await context.supabase.storage.from(BUCKET).createSignedUploadUrl(path);
  if (error) throw new Error(error.message);
  return {
    path,
    token: signed.token,
    signedUrl: signed.signedUrl
  };
});
const getVideoSignedUrl_createServerFn_handler = createServerRpc({
  id: "d17d05b3b8f96b7f7bae65d52a28dc428dba8bf5ca13e64b34abcd1dd78d3d92",
  name: "getVideoSignedUrl",
  filename: "src/lib/bulls-performance.functions.ts"
}, (opts) => getVideoSignedUrl.__executeServer(opts));
const getVideoSignedUrl = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => d).handler(getVideoSignedUrl_createServerFn_handler, async ({
  data,
  context
}) => {
  const {
    data: signed,
    error
  } = await context.supabase.storage.from(BUCKET).createSignedUrl(data.path, 3600);
  if (error) throw new Error(error.message);
  return {
    url: signed.signedUrl
  };
});
const listPendingPerformanceTests_createServerFn_handler = createServerRpc({
  id: "76cf973880af2a4ecf8b01dd0c546b11eab3b799489e9c7209d02c48668265d7",
  name: "listPendingPerformanceTests",
  filename: "src/lib/bulls-performance.functions.ts"
}, (opts) => listPendingPerformanceTests.__executeServer(opts));
const listPendingPerformanceTests = createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).handler(listPendingPerformanceTests_createServerFn_handler, async ({
  context
}) => {
  if (!await isCoachOrStaff(context.supabase, context.userId)) {
    throw new Error("Nicht berechtigt");
  }
  const {
    data,
    error
  } = await context.supabase.from("bulls_performance_tests").select("*").eq("verification_status", "submitted").order("performed_at", {
    ascending: true
  });
  if (error) throw new Error(error.message);
  const ids = Array.from(new Set((data ?? []).map((r) => r.user_id)));
  let profiles = {};
  if (ids.length > 0) {
    const {
      data: profs
    } = await context.supabase.from("bulls_profiles").select("user_id, first_name, last_name, position").in("user_id", ids);
    for (const p of profs ?? []) {
      profiles[p.user_id] = {
        name: [p.first_name, p.last_name].filter(Boolean).join(" ") || "Spieler",
        position: p.position ?? null
      };
    }
  }
  return (data ?? []).map((r) => ({
    ...r,
    player_name: profiles[r.user_id]?.name ?? "Spieler",
    player_position: profiles[r.user_id]?.position ?? null
  }));
});
const listPerformanceCheckStats_createServerFn_handler = createServerRpc({
  id: "d132dbdfc75b1ce936850cc0c956d8bbf7d42b588e70d11945acfa8bd89f0bc7",
  name: "listPerformanceCheckStats",
  filename: "src/lib/bulls-performance.functions.ts"
}, (opts) => listPerformanceCheckStats.__executeServer(opts));
const listPerformanceCheckStats = createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).handler(listPerformanceCheckStats_createServerFn_handler, async ({
  context
}) => {
  if (!await isCoachOrStaff(context.supabase, context.userId)) {
    throw new Error("Nicht berechtigt");
  }
  const [{
    count: pendingCount
  }, {
    count: verifiedCount
  }, {
    data: playersTested
  }] = await Promise.all([context.supabase.from("bulls_performance_tests").select("id", {
    count: "exact",
    head: true
  }).eq("verification_status", "submitted"), context.supabase.from("bulls_performance_tests").select("id", {
    count: "exact",
    head: true
  }).in("verification_status", ["verified", "corrected"]), context.supabase.from("bulls_performance_tests").select("user_id").in("verification_status", ["verified", "corrected"])]);
  const uniquePlayers = new Set((playersTested ?? []).map((r) => r.user_id)).size;
  return {
    pending: pendingCount ?? 0,
    verifiedResults: verifiedCount ?? 0,
    playersTested: uniquePlayers
  };
});
const verifySchema = objectType({
  id: stringType().uuid(),
  action: enumType(["verify", "correct", "reject"]),
  coach_corrected_value: numberType().finite().optional().nullable(),
  coach_note: stringType().max(500).optional().nullable(),
  rejection_reason: stringType().max(500).optional().nullable()
});
const decidePerformanceTest_createServerFn_handler = createServerRpc({
  id: "aad87384d5e6f4022ddeaddef5ca91c12194b31bdf4b07afbf57cf2187b9aa15",
  name: "decidePerformanceTest",
  filename: "src/lib/bulls-performance.functions.ts"
}, (opts) => decidePerformanceTest.__executeServer(opts));
const decidePerformanceTest = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((raw) => verifySchema.parse(raw)).handler(decidePerformanceTest_createServerFn_handler, async ({
  data,
  context
}) => {
  if (!await isCoachOrStaff(context.supabase, context.userId)) {
    throw new Error("Nicht berechtigt");
  }
  const base = {
    verified_by: context.userId,
    verified_at: (/* @__PURE__ */ new Date()).toISOString(),
    coach_note: data.coach_note ?? null
  };
  let update;
  if (data.action === "verify") {
    update = {
      ...base,
      verification_status: "verified",
      rejection_reason: null
    };
  } else if (data.action === "correct") {
    if (data.coach_corrected_value == null) throw new Error("Korrigierter Wert fehlt");
    update = {
      ...base,
      verification_status: "corrected",
      coach_corrected_value: data.coach_corrected_value,
      rejection_reason: null
    };
  } else {
    if (!data.rejection_reason) throw new Error("Ablehnungsgrund fehlt");
    update = {
      ...base,
      verification_status: "rejected",
      rejection_reason: data.rejection_reason
    };
  }
  const {
    error
  } = await context.supabase.from("bulls_performance_tests").update(update).eq("id", data.id);
  if (error) throw new Error(error.message);
  return {
    ok: true
  };
});
const listAthletePerformanceTests_createServerFn_handler = createServerRpc({
  id: "378434dfdd8128e747b92ae9011219710fc2784fa0c75fff2e55d0402461646b",
  name: "listAthletePerformanceTests",
  filename: "src/lib/bulls-performance.functions.ts"
}, (opts) => listAthletePerformanceTests.__executeServer(opts));
const listAthletePerformanceTests = createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).inputValidator((raw) => objectType({
  userId: stringType().uuid()
}).parse(raw)).handler(listAthletePerformanceTests_createServerFn_handler, async ({
  data,
  context
}) => {
  if (!await isCoachOrStaff(context.supabase, context.userId)) {
    throw new Error("Nicht berechtigt");
  }
  const {
    data: rows,
    error
  } = await context.supabase.from("bulls_performance_tests").select("*").eq("user_id", data.userId).order("performed_at", {
    ascending: false
  });
  if (error) throw new Error(error.message);
  return rows ?? [];
});
export {
  createVideoUploadUrl_createServerFn_handler,
  decidePerformanceTest_createServerFn_handler,
  getMyPerformanceAccess_createServerFn_handler,
  getVideoSignedUrl_createServerFn_handler,
  listAthletePerformanceTests_createServerFn_handler,
  listMyPerformanceTests_createServerFn_handler,
  listPendingPerformanceTests_createServerFn_handler,
  listPerformanceCheckStats_createServerFn_handler,
  submitPerformanceTest_createServerFn_handler
};
