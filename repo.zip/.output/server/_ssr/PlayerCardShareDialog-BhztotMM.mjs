import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import { t as toast } from "../_libs/sonner.mjs";
import { P as PlayerCard } from "./PlayerCard-_iT8IKPa.mjs";
import { X, L as LoaderCircle, aZ as Download, bC as Share2, I as Check, bD as Link } from "../_libs/lucide-react.mjs";
async function cardToPngBlob(node, opts = {}) {
  throw new Error("PNG-Export ist nur im Browser verfügbar");
}
function downloadBlob(blob, filename) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 5e3);
}
function slugify(input) {
  return input.normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-zA-Z0-9]+/g, "-").replace(/^-+|-+$/g, "").toLowerCase() || "player-card";
}
function PlayerCardShareDialog({ data, open, onClose, shareUrl }) {
  const exportRef = reactExports.useRef(null);
  const [busy, setBusy] = reactExports.useState(null);
  const [copied, setCopied] = reactExports.useState(false);
  reactExports.useEffect(() => {
    if (!open) return;
    const onKey = (e) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onClose]);
  if (!open) return null;
  const last = data.bullsProfile?.last_name || data.profile?.display_name?.split(" ").slice(-1)[0] || "player";
  const filename = `bfr-${slugify(last)}-${data.card.bfr ?? 0}.png`;
  const buildBlob = async () => {
    const node = exportRef.current;
    if (!node) throw new Error("Karte nicht bereit");
    return await cardToPngBlob(node, {});
  };
  const handleDownload = async () => {
    try {
      setBusy("download");
      const blob = await buildBlob();
      downloadBlob(blob, filename);
      toast.success("Karte heruntergeladen");
    } catch (e) {
      toast.error(e?.message ?? "Download fehlgeschlagen");
    } finally {
      setBusy(null);
    }
  };
  const handleShare = async () => {
    try {
      setBusy("share");
      const blob = await buildBlob();
      const file = new File([blob], filename, { type: "image/png" });
      const nav = navigator;
      if (nav.canShare?.({ files: [file] })) {
        await nav.share({
          files: [file],
          title: `${last} — BFR ${data.card.bfr ?? "—"}`,
          text: `Meine BodyFuel Player Card — BFR ${data.card.bfr ?? "—"}`
        });
      } else {
        downloadBlob(blob, filename);
        toast.success("Kein Share verfügbar — Karte gespeichert");
      }
    } catch (e) {
      if (e?.name !== "AbortError") toast.error(e?.message ?? "Teilen fehlgeschlagen");
    } finally {
      setBusy(null);
    }
  };
  const handleCopyLink = async () => {
    try {
      const url = shareUrl ?? window.location.href;
      await navigator.clipboard.writeText(url);
      setCopied(true);
      setTimeout(() => setCopied(false), 2e3);
    } catch {
      toast.error("Konnte Link nicht kopieren");
    }
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "fixed inset-0 z-[80] flex items-center justify-center bg-black/80 p-4 backdrop-blur-md", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      "button",
      {
        type: "button",
        onClick: onClose,
        "aria-label": "Schließen",
        className: "absolute right-4 top-4 grid h-9 w-9 place-items-center rounded-full border border-white/20 bg-black/60 text-white/80 hover:text-white",
        children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "h-4 w-4" })
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex w-full max-w-md flex-col items-center gap-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-full", style: { maxWidth: 380 }, children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { style: { aspectRatio: "2 / 3" }, children: /* @__PURE__ */ jsxRuntimeExports.jsx(PlayerCard, { data }) }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex w-full gap-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            type: "button",
            disabled: busy !== null,
            onClick: handleDownload,
            className: "flex flex-1 items-center justify-center gap-1.5 rounded-full bg-white px-4 py-2.5 text-xs font-bold uppercase tracking-wider text-black hover:opacity-90 disabled:opacity-50",
            children: [
              busy === "download" ? /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "h-3.5 w-3.5 animate-spin" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Download, { className: "h-3.5 w-3.5" }),
              "PNG"
            ]
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            type: "button",
            disabled: busy !== null,
            onClick: handleShare,
            className: "flex flex-1 items-center justify-center gap-1.5 rounded-full border border-white/30 bg-white/10 px-4 py-2.5 text-xs font-bold uppercase tracking-wider text-white hover:bg-white/20 disabled:opacity-50",
            children: [
              busy === "share" ? /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "h-3.5 w-3.5 animate-spin" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Share2, { className: "h-3.5 w-3.5" }),
              "Teilen"
            ]
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            type: "button",
            onClick: handleCopyLink,
            className: "flex flex-1 items-center justify-center gap-1.5 rounded-full border border-white/30 bg-white/10 px-4 py-2.5 text-xs font-bold uppercase tracking-wider text-white hover:bg-white/20",
            children: [
              copied ? /* @__PURE__ */ jsxRuntimeExports.jsx(Check, { className: "h-3.5 w-3.5" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { className: "h-3.5 w-3.5" }),
              copied ? "Kopiert" : "Link"
            ]
          }
        )
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-center text-[10px] uppercase tracking-widest text-white/40", children: "Tap außerhalb zum Schließen" })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      "div",
      {
        style: {
          position: "fixed",
          left: "-99999px",
          top: 0,
          width: 600,
          height: 900,
          pointerEvents: "none"
        },
        "aria-hidden": true,
        children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { ref: exportRef, style: { width: 600, height: 900 }, children: /* @__PURE__ */ jsxRuntimeExports.jsx(PlayerCard, { data }) })
      }
    )
  ] });
}
export {
  PlayerCardShareDialog as P
};
