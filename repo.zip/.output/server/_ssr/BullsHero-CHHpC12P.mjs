import { j as jsxRuntimeExports } from "../_libs/react.mjs";
import { a7 as logo$1 } from "./router-BmNvgrMe.mjs";
import { S as Shield } from "../_libs/lucide-react.mjs";
function BullsHero({
  eyebrow = "Bulls Performance Hub",
  title,
  subtitle,
  children,
  showLogo = false
}) {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "overflow-hidden rounded-3xl border border-bulls-red/40 bg-gradient-to-br from-black via-[oklch(0.12_0.005_250)] to-background p-6 sm:p-8 shadow-bulls", children: [
    showLogo && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "-mx-2 mb-4 sm:-mx-4 sm:mb-6", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
      "img",
      {
        src: logo$1.url,
        alt: "BodyFuel Coaching x Coesfeld Bulls",
        className: "mx-auto block w-full max-w-md"
      }
    ) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 text-xs uppercase tracking-[0.25em] text-bulls-red", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Shield, { className: "h-4 w-4" }),
      " ",
      eyebrow
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "mt-2 font-display text-3xl font-bold text-white sm:text-4xl", children: title }),
    subtitle && /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-2 text-sm text-muted-foreground sm:text-base", children: subtitle }),
    children && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-4", children })
  ] });
}
export {
  BullsHero as B
};
