import { j as jsxRuntimeExports, r as reactExports } from "../_libs/react.mjs";
import { e as useNavigate, L as Link } from "../_libs/tanstack__react-router.mjs";
import { u as useQuery } from "../_libs/tanstack__react-query.mjs";
import { u as useSession, a as useServerFn } from "./router-BmNvgrMe.mjs";
import "../_libs/sonner.mjs";
import { A as AppLayout } from "./AppLayout-lnbnJZfJ.mjs";
import { e as listCoachPlayerCards } from "./player-cards.functions-BJp35kAH.mjs";
import { D as DEFAULT_LAYOUT, l as loadLayout, P as PlayerCard } from "./PlayerCard-_iT8IKPa.mjs";
import { P as PlayerCardShareDialog } from "./PlayerCardShareDialog-BhztotMM.mjs";
import "../_libs/idb.mjs";

import "../_libs/seroval.mjs";
import "../_libs/unenv.mjs";

import "../_libs/lovable.dev__mcp-js.mjs";
import "../_libs/modelcontextprotocol__sdk.mjs";
import "../_libs/zod-to-json-schema.mjs";
import "../_libs/ajv-formats.mjs";
import "../_libs/stripe.mjs";
import { a6 as Trophy, bA as Funnel, bB as ArrowUpDown, i as Users, L as LoaderCircle, aZ as Download, bC as Share2 } from "../_libs/lucide-react.mjs";
import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval-plugins.mjs";


import "../_libs/react-dom.mjs";
import "../_libs/isbot.mjs";
import "../_libs/tanstack__query-core.mjs";
import "./client-mgvTz6tP.mjs";
import "../_libs/supabase__supabase-js.mjs";
import "../_libs/supabase__postgrest-js.mjs";
import "../_libs/supabase__realtime-js.mjs";
import "../_libs/supabase__phoenix.mjs";
import "../_libs/supabase__storage-js.mjs";

import "../_libs/iceberg-js.mjs";
import "../_libs/supabase__auth-js.mjs";
import "../_libs/tslib.mjs";
import "../_libs/supabase__functions-js.mjs";

import "../_libs/radix-ui__react-slot.mjs";
import "../_libs/radix-ui__react-compose-refs.mjs";
import "../_libs/class-variance-authority.mjs";
import "../_libs/clsx.mjs";
import "../_libs/tailwind-merge.mjs";
import "../_libs/radix-ui__react-switch.mjs";
import "../_libs/radix-ui__primitive.mjs";
import "../_libs/radix-ui__react-context.mjs";
import "../_libs/@radix-ui/react-use-controllable-state+[...].mjs";
import "../_libs/@radix-ui/react-use-layout-effect+[...].mjs";
import "../_libs/radix-ui__react-use-previous.mjs";
import "../_libs/radix-ui__react-use-size.mjs";
import "../_libs/radix-ui__react-primitive.mjs";
import "./createSsrRpc-r3tzPO1F.mjs";
import "./server-g-lQHb1O.mjs";
import "../_libs/h3-v2.mjs";
import "../_libs/rou3.mjs";
import "../_libs/srvx.mjs";




import "./auth-middleware-B5YcFrfv.mjs";
import "../_libs/radix-ui__react-label.mjs";
import "../_libs/tanstack__zod-adapter.mjs";
import "../_libs/zod.mjs";
import "../_libs/radix-ui__react-dialog.mjs";
import "../_libs/radix-ui__react-id.mjs";
import "../_libs/@radix-ui/react-dismissable-layer+[...].mjs";
import "../_libs/@radix-ui/react-use-callback-ref+[...].mjs";
import "../_libs/radix-ui__react-focus-scope.mjs";
import "../_libs/radix-ui__react-portal.mjs";
import "../_libs/radix-ui__react-presence.mjs";
import "../_libs/radix-ui__react-focus-guards.mjs";
import "../_libs/react-remove-scroll.mjs";
import "../_libs/react-remove-scroll-bar.mjs";
import "../_libs/react-style-singleton.mjs";
import "../_libs/get-nonce.mjs";
import "../_libs/use-sidecar.mjs";
import "../_libs/use-callback-ref.mjs";
import "../_libs/aria-hidden.mjs";
import "../_libs/radix-ui__react-checkbox.mjs";
import "./coach-analytics.rules-DadTu4Zq.mjs";
import "./football-positions-BJzdkmjv.mjs";
import "./athlete-training-session-pool-CmIQKgmz.mjs";
import "../_libs/lovable.dev__webhooks-js.mjs";
import "./registry-BHGsuy94.mjs";
import "../_libs/react-email__html.mjs";
import "../_libs/react-email__head.mjs";
import "../_libs/react-email__preview.mjs";
import "../_libs/react-email__body.mjs";
import "../_libs/react-email__container.mjs";
import "../_libs/react-email__section.mjs";
import "../_libs/react-email__heading.mjs";
import "../_libs/react-email__text.mjs";
import "../_libs/react-email__button.mjs";
import "../_libs/react-email__hr.mjs";
import "../_libs/react-email__img.mjs";
import "./task-engine.server-BbzZOvQb.mjs";
import "./stripe.server-mcZ3T1eX.mjs";
import "../_libs/lovable.dev__email-js.mjs";
import "../_libs/react-email__render.mjs";
import "../_libs/prettier.mjs";
import "../_libs/html-to-text.mjs";
import "../_libs/selderee__plugin-htmlparser2.mjs";
import "../_libs/selderee.mjs";
import "../_libs/parseley.mjs";
import "../_libs/leac.mjs";
import "../_libs/peberminta.mjs";
import "../_libs/domhandler.mjs";
import "../_libs/domelementtype.mjs";
import "../_libs/htmlparser2.mjs";
import "../_libs/entities.mjs";
import "../_libs/deepmerge.mjs";
import "../_libs/dom-serializer.mjs";
import "../_libs/react-email__link.mjs";
import "../_libs/jose.mjs";
import "../_libs/ajv.mjs";
import "../_libs/fast-deep-equal.mjs";
import "../_libs/json-schema-traverse.mjs";
import "../_libs/fast-uri.mjs";
import "./Logo-B675pmm_.mjs";
import "./textarea-CAY_SJkd.mjs";
import "./autopilot-jobs.functions-DxvdXJgH.mjs";
import "./OrganizationContextSwitcher-DxSxAmgQ.mjs";
import "./course-instructor.functions-BA-q0LmI.mjs";
function computeAge(bd) {
  if (!bd) return null;
  const d = new Date(bd);
  if (Number.isNaN(d.getTime())) return null;
  const now = /* @__PURE__ */ new Date();
  let a = now.getFullYear() - d.getFullYear();
  const m = now.getMonth() - d.getMonth();
  if (m < 0 || m === 0 && now.getDate() < d.getDate()) a--;
  return a;
}
function CoachPlayerCardsPage() {
  const navigate = useNavigate();
  const {
    supabaseUser,
    loading: sessionLoading
  } = useSession();
  const listFn = useServerFn(listCoachPlayerCards);
  reactExports.useEffect(() => {
    if (!sessionLoading && !supabaseUser) navigate({
      to: "/auth",
      search: {
        next: void 0
      }
    });
  }, [sessionLoading, supabaseUser, navigate]);
  const q = useQuery({
    queryKey: ["coach-player-cards"],
    queryFn: () => listFn(),
    enabled: !!supabaseUser
  });
  const [orgFilter, setOrgFilter] = reactExports.useState("all");
  const [posFilter, setPosFilter] = reactExports.useState("all");
  const [teamFilter, setTeamFilter] = reactExports.useState("all");
  const [ageBucket, setAgeBucket] = reactExports.useState("all");
  const [sortKey, setSortKey] = reactExports.useState("bfr_desc");
  const [selected, setSelected] = reactExports.useState(/* @__PURE__ */ new Set());
  const [shareData, setShareData] = reactExports.useState(null);
  const [bulkBusy, setBulkBusy] = reactExports.useState(false);
  const [savedLayout, setSavedLayout] = reactExports.useState(DEFAULT_LAYOUT);
  reactExports.useEffect(() => {
    setSavedLayout(loadLayout());
  }, []);
  const cards = reactExports.useMemo(() => q.data?.cards ?? [], [q.data?.cards]);
  const filterOptions = reactExports.useMemo(() => {
    const positions = /* @__PURE__ */ new Set();
    const teams = /* @__PURE__ */ new Map();
    const orgs = /* @__PURE__ */ new Map();
    for (const c of cards) {
      const pos = c.card.position_key ?? c.bullsProfile?.position ?? null;
      if (pos) positions.add(pos);
      if (c.teamId && c.teamName) teams.set(c.teamId, c.teamName);
      if (c.organization?.id) orgs.set(c.organization.id, c.organization.name);
    }
    return {
      positions: Array.from(positions).sort(),
      teams: Array.from(teams.entries()),
      orgs: Array.from(orgs.entries())
    };
  }, [cards]);
  const filtered = reactExports.useMemo(() => {
    const out = cards.filter((c) => {
      if (orgFilter !== "all" && c.organization?.id !== orgFilter) return false;
      const pos = c.card.position_key ?? c.bullsProfile?.position ?? null;
      if (posFilter !== "all" && pos !== posFilter) return false;
      if (teamFilter !== "all" && c.teamId !== teamFilter) return false;
      if (ageBucket !== "all") {
        const age = computeAge(c.profile?.birthdate);
        if (age == null) return false;
        if (ageBucket === "u18" && age >= 18) return false;
        if (ageBucket === "u23" && (age < 18 || age >= 23)) return false;
        if (ageBucket === "senior" && age < 23) return false;
      }
      return true;
    });
    out.sort((a, b) => {
      if (sortKey === "bfr_desc") return (b.card.bfr ?? -1) - (a.card.bfr ?? -1);
      if (sortKey === "bfr_asc") return (a.card.bfr ?? 999) - (b.card.bfr ?? 999);
      if (sortKey === "updated") return new Date(b.card.computed_at).getTime() - new Date(a.card.computed_at).getTime();
      const an = a.bullsProfile?.last_name ?? a.profile?.display_name ?? "";
      const bn = b.bullsProfile?.last_name ?? b.profile?.display_name ?? "";
      return an.localeCompare(bn);
    });
    return out;
  }, [cards, orgFilter, posFilter, teamFilter, ageBucket, sortKey]);
  const toggle = (id) => {
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };
  const selectAll = () => setSelected(new Set(filtered.map((c) => c.card.id)));
  const clearSelection = () => setSelected(/* @__PURE__ */ new Set());
  const bulkExportRef = reactExports.useRef(null);
  const [bulkQueue, setBulkQueue] = reactExports.useState([]);
  const startBulkExport = async () => {
    if (selected.size === 0 || true) return;
  };
  if (!supabaseUser) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mx-auto max-w-4xl p-6 text-sm text-muted-foreground", children: "Zugriff wird geprüft…" });
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mx-auto max-w-7xl space-y-4 p-4 sm:p-6", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/coach", className: "text-xs text-muted-foreground hover:text-bulls-red", children: "← Coach-Cockpit" }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("header", { className: "flex flex-col gap-2 sm:flex-row sm:items-end sm:justify-between", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col gap-1", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[10px] font-bold uppercase tracking-[0.25em] text-bulls-red", children: "Coach" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "font-display text-3xl font-bold", children: "Player Cards" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-muted-foreground", children: "Alle Karten aus deinen Vereinen. Filtern, sortieren, einzeln teilen oder mehrere als ZIP herunterladen." })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex flex-wrap items-center gap-2 self-start sm:self-end", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Link, { to: "/coach/player-cards/ranking", className: "inline-flex items-center gap-1.5 rounded-full bg-bulls-red px-4 py-2 text-xs font-bold uppercase tracking-wider text-white transition hover:opacity-90", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Trophy, { className: "h-3.5 w-3.5" }),
        "Rangliste & Player of the Month"
      ] }) })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("section", { className: "rounded-2xl border border-border bg-card/60 p-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mb-3 flex items-end justify-between gap-2", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[10px] font-bold uppercase tracking-[0.25em] text-bulls-red", children: "Vorlagen" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "font-display text-lg font-bold", children: "Karten-Design pro Verein" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-muted-foreground", children: "Jeder Verein bekommt seine eigene Karten-Vorlage. Weitere Vereine können jederzeit ergänzt werden." })
      ] }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid gap-3 sm:grid-cols-2 xl:grid-cols-3", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Link, { to: "/coach/player-cards/layout/$orgSlug", params: {
        orgSlug: "bulls"
      }, className: "group flex items-center justify-between rounded-xl border border-border bg-background/40 p-4 hover:border-bulls-red", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[10px] font-semibold uppercase tracking-wider text-muted-foreground", children: "Coesfeld Bulls" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-0.5 font-display text-base font-bold", children: 'Vorlage „Elite"' }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[11px] text-muted-foreground", children: "Bearbeiten & freigeben" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs text-muted-foreground group-hover:text-bulls-red", children: "→" })
      ] }) })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-2 gap-2 sm:grid-cols-6", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(FilterSelect, { icon: /* @__PURE__ */ jsxRuntimeExports.jsx(Funnel, { className: "h-3.5 w-3.5" }), label: "Verein", value: orgFilter, onChange: setOrgFilter, options: [["all", "Alle Vereine"], ...filterOptions.orgs] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(FilterSelect, { label: "Team", value: teamFilter, onChange: setTeamFilter, options: [["all", "Alle Teams"], ...filterOptions.teams] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(FilterSelect, { label: "Position", value: posFilter, onChange: setPosFilter, options: [["all", "Alle Positionen"], ...filterOptions.positions.map((p) => [p, p])] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(FilterSelect, { label: "Altersklasse", value: ageBucket, onChange: setAgeBucket, options: [["all", "Alle Altersklassen"], ["u18", "U18"], ["u23", "U19–U23"], ["senior", "Senior (23+)"]] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(FilterSelect, { icon: /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowUpDown, { className: "h-3.5 w-3.5" }), label: "Sortierung", value: sortKey, onChange: (v) => setSortKey(v), options: [["bfr_desc", "BFR: Hoch → Niedrig"], ["bfr_asc", "BFR: Niedrig → Hoch"], ["updated", "Zuletzt aktualisiert"], ["name", "Nachname"]] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-end", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "w-full rounded-full border border-border bg-card px-3 py-2 text-center text-xs text-muted-foreground", children: [
        filtered.length,
        " Karten"
      ] }) })
    ] }),
    selected.size > 0 && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "sticky top-2 z-10 flex items-center justify-between gap-2 rounded-xl border border-bulls-red/40 bg-black/80 px-3 py-2 text-xs text-white backdrop-blur", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Users, { className: "h-4 w-4 text-bulls-red" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "font-semibold", children: [
          selected.size,
          " ausgewählt"
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: selectAll, className: "text-white/70 underline-offset-2 hover:underline", children: "Alle sichtbaren" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: clearSelection, className: "text-white/70 underline-offset-2 hover:underline", children: "Auswahl leeren" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { type: "button", onClick: startBulkExport, disabled: bulkBusy, className: "inline-flex items-center gap-1.5 rounded-full bg-bulls-red px-4 py-1.5 text-[11px] font-bold uppercase tracking-wider text-white hover:opacity-90 disabled:opacity-50", children: [
        bulkBusy ? /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "h-3.5 w-3.5 animate-spin" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Download, { className: "h-3.5 w-3.5" }),
        bulkBusy ? "Rendere…" : "Als ZIP exportieren"
      ] })
    ] }),
    q.isLoading ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid place-items-center rounded-2xl border border-border bg-card p-12", children: /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "h-6 w-6 animate-spin text-muted-foreground" }) }) : filtered.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "rounded-2xl border border-dashed border-border bg-card p-10 text-center text-sm text-muted-foreground", children: "Keine Karten für die aktuelle Filter-Kombination." }) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5", children: filtered.map((c) => {
      const data = {
        card: c.card,
        profile: c.profile,
        bullsProfile: c.bullsProfile,
        organization: c.organization,
        teamLabel: c.teamName,
        jerseyNumber: c.jerseyNumber
      };
      const isSelected = selected.has(c.card.id);
      return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "group relative", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { style: {
          aspectRatio: "2 / 3"
        }, children: /* @__PURE__ */ jsxRuntimeExports.jsx(PlayerCard, { data, layout: savedLayout }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "absolute inset-x-1 top-1 flex items-center justify-between", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "flex cursor-pointer items-center gap-1 rounded-full bg-black/70 px-2 py-1 text-[10px] font-semibold text-white backdrop-blur", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("input", { type: "checkbox", className: "h-3 w-3 accent-red-500", checked: isSelected, onChange: () => toggle(c.card.id) }),
            isSelected ? "Ausgewählt" : "Wählen"
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("button", { type: "button", onClick: () => setShareData(data), className: "grid h-7 w-7 place-items-center rounded-full bg-black/70 text-white backdrop-blur hover:text-bulls-red", "aria-label": "Teilen", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Share2, { className: "h-3.5 w-3.5" }) })
        ] })
      ] }, c.card.id);
    }) }),
    shareData && /* @__PURE__ */ jsxRuntimeExports.jsx(PlayerCardShareDialog, { data: shareData, open: true, onClose: () => setShareData(null) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { "aria-hidden": true, style: {
      position: "fixed",
      left: "-99999px",
      top: 0,
      width: 600,
      height: 900,
      pointerEvents: "none"
    }, children: bulkQueue[0] && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { ref: bulkExportRef, style: {
      width: 600,
      height: 900
    }, children: /* @__PURE__ */ jsxRuntimeExports.jsx(PlayerCard, { data: bulkQueue[0], layout: savedLayout }) }) })
  ] });
}
function FilterSelect({
  label,
  value,
  onChange,
  options,
  icon
}) {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "flex flex-col gap-1", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "flex items-center gap-1 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground", children: [
      icon,
      label
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("select", { value, onChange: (e) => onChange(e.target.value), className: "rounded-full border border-border bg-card px-3 py-2 text-xs text-foreground focus:border-bulls-red focus:outline-none", children: options.map(([v, l]) => /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: v, children: l }, v)) })
  ] });
}
const SplitComponent = () => /* @__PURE__ */ jsxRuntimeExports.jsx(AppLayout, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(CoachPlayerCardsPage, {}) });
export {
  SplitComponent as component
};
