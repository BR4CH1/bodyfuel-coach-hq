import { c as createServerRpc } from "./createServerRpc--OrbljSy.mjs";
import { c as createServerFn } from "./server-g-lQHb1O.mjs";
import { r as requireSupabaseAuth } from "./auth-middleware-B5YcFrfv.mjs";

import "../_libs/seroval.mjs";
import "../_libs/react.mjs";

import "../_libs/h3-v2.mjs";
import "../_libs/unenv.mjs";


import "../_libs/rou3.mjs";
import "../_libs/srvx.mjs";





import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval-plugins.mjs";

import "../_libs/tanstack__react-router.mjs";
import "../_libs/react-dom.mjs";
import "../_libs/isbot.mjs";
import "../_libs/supabase__supabase-js.mjs";
import "../_libs/supabase__postgrest-js.mjs";
import "../_libs/supabase__realtime-js.mjs";
import "../_libs/supabase__phoenix.mjs";
import "../_libs/supabase__storage-js.mjs";
import "../_libs/iceberg-js.mjs";
import "../_libs/supabase__auth-js.mjs";
import "../_libs/tslib.mjs";
import "../_libs/supabase__functions-js.mjs";
async function assertCoach(ctx) {
  const {
    data: isCoach
  } = await ctx.supabase.rpc("has_role", {
    _user_id: ctx.userId,
    _role: "coach"
  });
  if (!isCoach) throw new Error("Nur für Coaches.");
}
const SELECT_COLS = "id,title,status,source,generated_by,scheduled_start_date,scheduled_end_date,weeks_count,created_at";
function bucketPlans(rows) {
  const today = (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
  const current = [];
  const upcoming = [];
  const past = [];
  const drafts = [];
  for (const p of rows) {
    if (p.status === "draft") {
      drafts.push(p);
      continue;
    }
    if (p.status === "archived") {
      past.push(p);
      continue;
    }
    const s = p.scheduled_start_date;
    const e = p.scheduled_end_date;
    if (s && e && s <= today && e >= today) current.push(p);
    else if (s && s > today) upcoming.push(p);
    else past.push(p);
  }
  return {
    current,
    upcoming,
    past,
    drafts,
    all: rows
  };
}
const listCustomerNutritionPlans_createServerFn_handler = createServerRpc({
  id: "98b83b8414f0a83eedfd71f5472143b3a1d9bda47c292e41ba7eb653f4f87e4d",
  name: "listCustomerNutritionPlans",
  filename: "src/lib/coach-plan-history.functions.ts"
}, (opts) => listCustomerNutritionPlans.__executeServer(opts));
const listCustomerNutritionPlans = createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).inputValidator((d) => d).handler(listCustomerNutritionPlans_createServerFn_handler, async ({
  data,
  context
}) => {
  await assertCoach(context);
  const {
    supabase
  } = context;
  const {
    data: rows,
    error
  } = await supabase.from("nutrition_plans").select(SELECT_COLS).eq("client_id", data.client_id).eq("plan_type", "nutrition").order("scheduled_start_date", {
    ascending: false,
    nullsFirst: false
  }).order("created_at", {
    ascending: false
  });
  if (error) throw new Error(error.message);
  return bucketPlans(rows ?? []);
});
const checkNutritionPlanConflict_createServerFn_handler = createServerRpc({
  id: "d39ba2a4aea51a0dd4f09191bacd571517ed8bbfe5899aec9f5926eaecc6347a",
  name: "checkNutritionPlanConflict",
  filename: "src/lib/coach-plan-history.functions.ts"
}, (opts) => checkNutritionPlanConflict.__executeServer(opts));
const checkNutritionPlanConflict = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => d).handler(checkNutritionPlanConflict_createServerFn_handler, async ({
  data,
  context
}) => {
  await assertCoach(context);
  const {
    supabase
  } = context;
  let q = supabase.from("nutrition_plans").select(SELECT_COLS).eq("client_id", data.client_id).eq("plan_type", "nutrition").neq("status", "archived").lte("scheduled_start_date", data.end_date).gte("scheduled_end_date", data.start_date);
  if (data.exclude_plan_id) q = q.neq("id", data.exclude_plan_id);
  const {
    data: rows,
    error
  } = await q;
  if (error) throw new Error(error.message);
  return {
    conflicts: rows ?? []
  };
});
const setNutritionPlanStatus_createServerFn_handler = createServerRpc({
  id: "2fd96ee67bf9ebf716af40cfdc18057693e5c57dff92809d2829c5b0046d9b83",
  name: "setNutritionPlanStatus",
  filename: "src/lib/coach-plan-history.functions.ts"
}, (opts) => setNutritionPlanStatus.__executeServer(opts));
const setNutritionPlanStatus = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => d).handler(setNutritionPlanStatus_createServerFn_handler, async ({
  data,
  context
}) => {
  await assertCoach(context);
  const {
    supabaseAdmin
  } = await import("./client.server-D5ro3rAQ.mjs");
  const patch = {
    status: data.status
  };
  if (data.status === "archived") patch.archived_at = (/* @__PURE__ */ new Date()).toISOString();
  if (data.status === "active" || data.status === "published") {
    patch.activated_at = (/* @__PURE__ */ new Date()).toISOString();
  }
  const {
    error
  } = await supabaseAdmin.from("nutrition_plans").update(patch).eq("id", data.plan_id);
  if (error) throw new Error(error.message);
  return {
    ok: true
  };
});
const listMyPublishedNutritionPlans_createServerFn_handler = createServerRpc({
  id: "cefc0ba364f9414664cf0014eec625f02ab078894e7567dd4f948283ccd03f42",
  name: "listMyPublishedNutritionPlans",
  filename: "src/lib/coach-plan-history.functions.ts"
}, (opts) => listMyPublishedNutritionPlans.__executeServer(opts));
const listMyPublishedNutritionPlans = createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).handler(listMyPublishedNutritionPlans_createServerFn_handler, async ({
  context
}) => {
  const {
    supabase,
    userId
  } = context;
  const {
    data,
    error
  } = await supabase.from("nutrition_plans").select(SELECT_COLS).eq("client_id", userId).eq("plan_type", "nutrition").in("status", ["active", "published"]).order("scheduled_start_date", {
    ascending: false,
    nullsFirst: false
  });
  if (error) throw new Error(error.message);
  return data ?? [];
});
export {
  checkNutritionPlanConflict_createServerFn_handler,
  listCustomerNutritionPlans_createServerFn_handler,
  listMyPublishedNutritionPlans_createServerFn_handler,
  setNutritionPlanStatus_createServerFn_handler
};
