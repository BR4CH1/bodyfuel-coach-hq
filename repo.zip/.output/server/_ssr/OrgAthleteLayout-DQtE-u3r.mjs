import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import { f as useLocation, L as Link } from "../_libs/tanstack__react-router.mjs";
import { p as orgTerminology, u as useSession, a as useServerFn } from "./router-BmNvgrMe.mjs";
import { u as useQuery } from "../_libs/tanstack__react-query.mjs";
import { l as listMyCourseInstructorOrgs } from "./course-instructor.functions-BA-q0LmI.mjs";
import { s as setActiveContext } from "./OrganizationContextSwitcher-DxSxAmgQ.mjs";
import { ar as Rocket, as as House, D as Dumbbell, ac as Apple, i as Users, U as User } from "../_libs/lucide-react.mjs";
function buildNav(terminologyLabels) {
  return [
    { key: "home", label: "Home", to: "/$orgSlug/home", icon: House, feature: "home" },
    {
      key: "training",
      label: terminologyLabels.training,
      to: "/$orgSlug/training",
      icon: Dumbbell,
      feature: "athletic_training",
      featureAliases: ["training", "smart_training"]
    },
    {
      key: "nutrition",
      label: terminologyLabels.nutrition,
      to: "/$orgSlug/nutrition",
      icon: Apple,
      feature: "nutrition",
      featureAliases: ["smart_nutrition"]
    },
    { key: "community", label: terminologyLabels.community, to: "/$orgSlug/community", icon: Users, feature: "community" },
    { key: "profil", label: "Profil", to: "/$orgSlug/profil", icon: User, feature: null }
  ];
}
function OrgAthleteLayout({
  slug,
  features,
  primaryColor,
  organizationType,
  terminologyOverrides,
  children
}) {
  const enabledSet = new Set(features.filter((f) => f.enabled).map((f) => f.feature));
  const term = orgTerminology(organizationType ?? "sports_club", terminologyOverrides ?? void 0);
  const { supabaseUser } = useSession();
  const listCourseInstructorOrgsFn = useServerFn(listMyCourseInstructorOrgs);
  const { data: courseInstructorOrgSlugs = [] } = useQuery({
    queryKey: ["coach-tools-instructor-org-slugs", supabaseUser?.id ?? "anon"],
    enabled: !!supabaseUser?.id,
    staleTime: 6e4,
    queryFn: async () => {
      const result = await listCourseInstructorOrgsFn();
      return result.orgSlugs ?? [];
    }
  });
  reactExports.useEffect(() => {
    setActiveContext(slug);
  }, [slug]);
  const hasCourseToolsInThisOrg = courseInstructorOrgSlugs.includes(slug);
  const nav = [
    ...buildNav({ training: "Training", nutrition: "Ernährung", community: term.isCompany ? "Feed" : "Community" }),
    ...hasCourseToolsInThisOrg ? [{ key: "coach-tools", label: "Coach Tools", to: "/coach-tools", icon: Rocket, feature: null }] : []
  ];
  const isFeatureOn = (item) => {
    if (item.feature === null) return true;
    if (enabledSet.has(item.feature)) return true;
    return (item.featureAliases ?? []).some((a) => enabledSet.has(a));
  };
  const visible = nav.filter(isFeatureOn);
  const loc = useLocation();
  const themeClass = /bulls/i.test(slug) ? "bulls-theme" : "";
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `min-h-screen bg-background pb-20 text-foreground ${themeClass}`.trim(), children: [
    children,
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      "nav",
      {
        className: "fixed inset-x-0 bottom-0 z-40 border-t border-border bg-card/95 backdrop-blur",
        style: { paddingBottom: "env(safe-area-inset-bottom)" },
        children: /* @__PURE__ */ jsxRuntimeExports.jsx(
          "div",
          {
            className: "mx-auto grid max-w-md",
            style: { gridTemplateColumns: `repeat(${visible.length}, 1fr)` },
            children: visible.map((item) => {
              const Icon = item.icon;
              const path = item.to.replace("$orgSlug", slug);
              const active = loc.pathname === path || loc.pathname.startsWith(path + "/");
              return /* @__PURE__ */ jsxRuntimeExports.jsxs(
                Link,
                {
                  to: item.to,
                  params: { orgSlug: slug },
                  className: "flex flex-col items-center gap-1 py-2 text-[10px] uppercase tracking-wider transition-colors",
                  style: { color: active ? primaryColor ?? "#e11d48" : void 0 },
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(Icon, { className: "h-5 w-5", strokeWidth: active ? 2.4 : 1.8 }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: active ? "font-bold" : "text-muted-foreground", children: item.label })
                  ]
                },
                item.key
              );
            })
          }
        )
      }
    )
  ] });
}
export {
  OrgAthleteLayout as O
};
