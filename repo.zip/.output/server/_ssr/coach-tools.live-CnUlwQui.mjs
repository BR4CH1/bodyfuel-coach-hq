import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import { L as Link } from "../_libs/tanstack__react-router.mjs";
import { B as Button } from "./router-BmNvgrMe.mjs";
import "../_libs/sonner.mjs";
import "../_libs/idb.mjs";

import "../_libs/seroval.mjs";
import "../_libs/unenv.mjs";

import "../_libs/lovable.dev__mcp-js.mjs";
import "../_libs/modelcontextprotocol__sdk.mjs";
import "../_libs/zod-to-json-schema.mjs";
import "../_libs/ajv-formats.mjs";
import "../_libs/stripe.mjs";
import { X, bi as Pause, bf as Play, b9 as RotateCcw, bj as SkipForward } from "../_libs/lucide-react.mjs";
import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval-plugins.mjs";


import "../_libs/react-dom.mjs";
import "../_libs/isbot.mjs";
import "../_libs/tanstack__query-core.mjs";
import "../_libs/tanstack__react-query.mjs";
import "./client-mgvTz6tP.mjs";
import "../_libs/supabase__supabase-js.mjs";
import "../_libs/supabase__postgrest-js.mjs";
import "../_libs/supabase__realtime-js.mjs";
import "../_libs/supabase__phoenix.mjs";
import "../_libs/supabase__storage-js.mjs";

import "../_libs/iceberg-js.mjs";
import "../_libs/supabase__auth-js.mjs";
import "../_libs/tslib.mjs";
import "../_libs/supabase__functions-js.mjs";

import "../_libs/radix-ui__react-slot.mjs";
import "../_libs/radix-ui__react-compose-refs.mjs";
import "../_libs/class-variance-authority.mjs";
import "../_libs/clsx.mjs";
import "../_libs/tailwind-merge.mjs";
import "../_libs/radix-ui__react-switch.mjs";
import "../_libs/radix-ui__primitive.mjs";
import "../_libs/radix-ui__react-context.mjs";
import "../_libs/@radix-ui/react-use-controllable-state+[...].mjs";
import "../_libs/@radix-ui/react-use-layout-effect+[...].mjs";
import "../_libs/radix-ui__react-use-previous.mjs";
import "../_libs/radix-ui__react-use-size.mjs";
import "../_libs/radix-ui__react-primitive.mjs";
import "./createSsrRpc-r3tzPO1F.mjs";
import "./server-g-lQHb1O.mjs";
import "../_libs/h3-v2.mjs";
import "../_libs/rou3.mjs";
import "../_libs/srvx.mjs";




import "./auth-middleware-B5YcFrfv.mjs";
import "../_libs/radix-ui__react-label.mjs";
import "../_libs/tanstack__zod-adapter.mjs";
import "../_libs/zod.mjs";
import "../_libs/radix-ui__react-dialog.mjs";
import "../_libs/radix-ui__react-id.mjs";
import "../_libs/@radix-ui/react-dismissable-layer+[...].mjs";
import "../_libs/@radix-ui/react-use-callback-ref+[...].mjs";
import "../_libs/radix-ui__react-focus-scope.mjs";
import "../_libs/radix-ui__react-portal.mjs";
import "../_libs/radix-ui__react-presence.mjs";
import "../_libs/radix-ui__react-focus-guards.mjs";
import "../_libs/react-remove-scroll.mjs";
import "../_libs/react-remove-scroll-bar.mjs";
import "../_libs/react-style-singleton.mjs";
import "../_libs/get-nonce.mjs";
import "../_libs/use-sidecar.mjs";
import "../_libs/use-callback-ref.mjs";
import "../_libs/aria-hidden.mjs";
import "../_libs/radix-ui__react-checkbox.mjs";
import "./coach-analytics.rules-DadTu4Zq.mjs";
import "./football-positions-BJzdkmjv.mjs";
import "./athlete-training-session-pool-CmIQKgmz.mjs";
import "../_libs/lovable.dev__webhooks-js.mjs";
import "./registry-BHGsuy94.mjs";
import "../_libs/react-email__html.mjs";
import "../_libs/react-email__head.mjs";
import "../_libs/react-email__preview.mjs";
import "../_libs/react-email__body.mjs";
import "../_libs/react-email__container.mjs";
import "../_libs/react-email__section.mjs";
import "../_libs/react-email__heading.mjs";
import "../_libs/react-email__text.mjs";
import "../_libs/react-email__button.mjs";
import "../_libs/react-email__hr.mjs";
import "../_libs/react-email__img.mjs";
import "./task-engine.server-BbzZOvQb.mjs";
import "./stripe.server-mcZ3T1eX.mjs";
import "../_libs/lovable.dev__email-js.mjs";
import "../_libs/react-email__render.mjs";
import "../_libs/prettier.mjs";
import "../_libs/html-to-text.mjs";
import "../_libs/selderee__plugin-htmlparser2.mjs";
import "../_libs/selderee.mjs";
import "../_libs/parseley.mjs";
import "../_libs/leac.mjs";
import "../_libs/peberminta.mjs";
import "../_libs/domhandler.mjs";
import "../_libs/domelementtype.mjs";
import "../_libs/htmlparser2.mjs";
import "../_libs/entities.mjs";
import "../_libs/deepmerge.mjs";
import "../_libs/dom-serializer.mjs";
import "../_libs/react-email__link.mjs";
import "../_libs/jose.mjs";
import "../_libs/ajv.mjs";
import "../_libs/fast-deep-equal.mjs";
import "../_libs/json-schema-traverse.mjs";
import "../_libs/fast-uri.mjs";
function LivePage() {
  const [template, setTemplate] = reactExports.useState(null);
  const [idx, setIdx] = reactExports.useState(0);
  const [elapsed, setElapsed] = reactExports.useState(0);
  const [running, setRunning] = reactExports.useState(false);
  reactExports.useEffect(() => {
    try {
      const raw = sessionStorage.getItem("coach-tools:live-template");
      if (raw) setTemplate(JSON.parse(raw));
    } catch {
    }
  }, []);
  reactExports.useEffect(() => {
    if (!running) return;
    const id = setInterval(() => setElapsed((e) => e + 1), 1e3);
    return () => clearInterval(id);
  }, [running]);
  const blocks = template?.blocks ?? [];
  const cur = blocks[idx];
  const remaining = cur ? Math.max(0, cur.duration_seconds - elapsed) : 0;
  reactExports.useEffect(() => {
    if (cur && running && elapsed >= cur.duration_seconds) {
      if (idx < blocks.length - 1) {
        setIdx((i) => i + 1);
        setElapsed(0);
      } else {
        setRunning(false);
      }
    }
  }, [elapsed, cur, running, idx, blocks.length]);
  if (!template) {
    return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("header", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs uppercase tracking-widest text-gold", children: "Coach Tools" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "font-display text-2xl font-bold", children: "Live-Kursmodus" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl border border-dashed border-border p-10 text-center text-sm text-muted-foreground", children: [
        "Wähle in den ",
        /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/coach-tools/templates", className: "text-gold underline", children: "Kursvorlagen" }),
        " eine Vorlage und starte sie live — oder nutze den ",
        /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/coach-tools/timer", className: "text-gold underline", children: "Timer" }),
        " direkt."
      ] })
    ] });
  }
  const fmt = (s) => `${Math.floor(s / 60)}:${(s % 60).toString().padStart(2, "0")}`;
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "fixed inset-0 z-50 flex flex-col bg-background p-6", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-[10px] uppercase tracking-widest text-gold", children: [
          "Block ",
          idx + 1,
          "/",
          blocks.length
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-display text-xl font-bold", children: template.name })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/coach-tools/templates", className: "rounded-md p-2 hover:bg-secondary", "aria-label": "Schließen", children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "h-5 w-5" }) })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-1 flex-col items-center justify-center gap-6 text-center", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[11px] uppercase tracking-widest text-muted-foreground", children: cur?.phase }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-display text-3xl font-bold sm:text-5xl", children: cur?.title }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-display text-[24vw] font-bold leading-none tabular-nums text-gold sm:text-[18vw]", children: fmt(remaining) }),
      cur?.exercises && cur.exercises.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "max-w-2xl space-y-1 text-sm", children: cur.exercises.map((e, i) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex justify-between gap-4 border-b border-border/40 py-1", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: e.name }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-muted-foreground", children: e.work_sec ? `${e.work_sec}s${e.rest_sec ? ` / ${e.rest_sec}s` : ""}` : e.reps ?? "" })
      ] }, i)) })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center justify-center gap-3", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { size: "lg", onClick: () => setRunning((r) => !r), className: running ? "bg-amber-500 hover:bg-amber-600" : "bg-gradient-gold", children: running ? /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Pause, { className: "mr-2 h-4 w-4" }),
        " Pause"
      ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Play, { className: "mr-2 h-4 w-4" }),
        " Start"
      ] }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { size: "lg", variant: "outline", onClick: () => {
        setElapsed(0);
      }, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(RotateCcw, { className: "mr-2 h-4 w-4" }),
        " Reset"
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { size: "lg", variant: "outline", onClick: () => {
        setElapsed(0);
        setIdx((i) => Math.min(i + 1, blocks.length - 1));
      }, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(SkipForward, { className: "mr-2 h-4 w-4" }),
        " Weiter"
      ] })
    ] })
  ] });
}
export {
  LivePage as component
};
