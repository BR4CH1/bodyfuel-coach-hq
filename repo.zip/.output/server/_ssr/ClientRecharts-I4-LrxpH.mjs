import { r as reactExports } from "../_libs/react.mjs";
const importRecharts = () => {
  throw new Error("createClientOnlyFn() functions can only be called on the client!");
};
let cachedModule = null;
let pendingModule = null;
function loadRecharts() {
  if (cachedModule) return Promise.resolve(cachedModule);
  pendingModule ??= importRecharts().then((module) => {
    cachedModule = module;
    return module;
  });
  return pendingModule;
}
function ClientRecharts({
  children,
  fallback = null,
  errorFallback = null
}) {
  const [recharts, setRecharts] = reactExports.useState(() => cachedModule);
  const [failed, setFailed] = reactExports.useState(false);
  reactExports.useEffect(() => {
    if (recharts || failed) return;
    let active = true;
    void loadRecharts().then((module) => {
      if (active) setRecharts(module);
    }).catch(() => {
      pendingModule = null;
      if (active) setFailed(true);
    });
    return () => {
      active = false;
    };
  }, [failed, recharts]);
  if (failed) return errorFallback;
  if (!recharts) return fallback;
  return children(recharts);
}
export {
  ClientRecharts as C
};
