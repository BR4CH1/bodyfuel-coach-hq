function dateOnlyIso(d) {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}
function combineDateTime(dateStr, timeStr) {
  const time = timeStr ?? "09:00:00";
  const [h, m, s] = time.split(":").map((x) => parseInt(x, 10) || 0);
  const d = /* @__PURE__ */ new Date(`${dateStr}T00:00:00`);
  d.setHours(h, m, s || 0, 0);
  return d.toISOString();
}
async function runOrgTaskEngineWithClient(supabase, orgId, horizonDays = 14) {
  const started_at = (/* @__PURE__ */ new Date()).toISOString();
  const errors = [];
  let created = 0;
  let considered = 0;
  let removed = 0;
  try {
    let resolvePlanTargets = function(planId) {
      const planAssignments = assignments.filter((a) => a.plan_id === planId);
      if (!planAssignments.length) return [];
      const athleteScoped = planAssignments.filter((a) => a.scope_type === "athlete" && a.athlete_user_id);
      const positionScoped = planAssignments.filter((a) => a.scope_type === "position" && a.position && a.team_id);
      const teamScoped = planAssignments.filter((a) => a.scope_type === "team" && a.team_id);
      const orgScoped = planAssignments.filter((a) => a.scope_type === "organization");
      const targets = /* @__PURE__ */ new Map();
      for (const a of athleteScoped) if (memberIds.has(a.athlete_user_id))
        targets.set(a.athlete_user_id, { user_id: a.athlete_user_id, team_id: a.team_id ?? null });
      for (const a of positionScoped) {
        const tms = teamMemberships.filter(
          (tm) => tm.team_id === a.team_id && (tm.position || "").toLowerCase() === (a.position || "").toLowerCase()
        );
        for (const tm of tms) if (!targets.has(tm.user_id)) targets.set(tm.user_id, { user_id: tm.user_id, team_id: a.team_id });
      }
      for (const a of teamScoped) {
        const tms = teamMemberships.filter((tm) => tm.team_id === a.team_id);
        for (const tm of tms) if (!targets.has(tm.user_id)) targets.set(tm.user_id, { user_id: tm.user_id, team_id: a.team_id });
      }
      for (const a of orgScoped) {
        for (const uid of memberIds) if (!targets.has(uid)) targets.set(uid, { user_id: uid, team_id: null });
      }
      return Array.from(targets.values());
    };
    const orgSlugRes = await supabase.from("organizations").select("slug").eq("id", orgId).maybeSingle();
    const orgSlug = orgSlugRes.data?.slug ?? orgId;
    const [teamsRes, membershipsRes, teamMembershipsRes, featuresRes, schedulesRes, plansRes, plansSessionsRes, assignmentsRes, challengesRes, weekWeeksRes, weekSessionsRes] = await Promise.all([
      supabase.from("organization_teams").select("id").eq("organization_id", orgId),
      supabase.from("organization_memberships").select("user_id, status").eq("organization_id", orgId).eq("status", "active"),
      supabase.from("team_memberships").select("user_id, team_id, position, status"),
      supabase.from("organization_features").select("feature, enabled, config").eq("organization_id", orgId),
      supabase.from("organization_team_training_schedule").select("id, team_id, weekday, start_time, title, active"),
      supabase.from("organization_athletic_plans").select("id, user_id, team_id, name, payload, status, start_date, end_date, organization_id").eq("organization_id", orgId).eq("status", "active"),
      supabase.from("organization_athletic_plan_sessions").select("id, plan_id, session_name, estimated_duration_minutes, scheduled_weekdays, focus_areas"),
      supabase.from("organization_athletic_plan_assignments").select("id, plan_id, organization_id, scope_type, team_id, position, athlete_user_id, active").eq("organization_id", orgId).eq("active", true),
      supabase.from("organization_challenges").select("id, name, config, starts_at, ends_at, status, team_id").eq("organization_id", orgId).eq("status", "active"),
      supabase.from("org_team_training_week").select("id, team_id, week_start, status").eq("organization_id", orgId).eq("status", "published"),
      supabase.from("org_team_training_week_session").select("id, week_id, session_date, title, start_time, active").eq("active", true)
    ]);
    const teamIds = new Set((teamsRes.data ?? []).map((t) => t.id));
    const memberIds = new Set((membershipsRes.data ?? []).map((m) => m.user_id));
    const teamMemberships = (teamMembershipsRes.data ?? []).filter(
      (tm) => teamIds.has(tm.team_id) && memberIds.has(tm.user_id) && tm.status !== "inactive"
    );
    const featureMap = /* @__PURE__ */ new Map();
    for (const f of featuresRes.data ?? []) {
      featureMap.set(f.feature, { enabled: !!f.enabled, config: f.config ?? {} });
    }
    const plans = plansRes.data ?? [];
    const planSessions = (plansSessionsRes.data ?? []).filter(
      (s) => plans.some((p) => p.id === s.plan_id)
    );
    const assignments = assignmentsRes.data ?? [];
    const publishedWeeks = (weekWeeksRes.data ?? []).filter((w) => teamIds.has(w.team_id));
    const weekIdToTeam = /* @__PURE__ */ new Map();
    const weekIdToStart = /* @__PURE__ */ new Map();
    for (const w of publishedWeeks) {
      weekIdToTeam.set(w.id, w.team_id);
      weekIdToStart.set(w.id, w.week_start);
    }
    const coveredTeamDate = /* @__PURE__ */ new Set();
    const weeklySessionsByDate = /* @__PURE__ */ new Map();
    for (const s of weekSessionsRes.data ?? []) {
      const teamId = weekIdToTeam.get(s.week_id);
      if (!teamId) continue;
      const start = weekIdToStart.get(s.week_id);
      const endDate = /* @__PURE__ */ new Date(start + "T00:00:00Z");
      endDate.setUTCDate(endDate.getUTCDate() + 6);
      const endIso = dateOnlyIso(endDate);
      let cur = /* @__PURE__ */ new Date(start + "T00:00:00Z");
      const stop = /* @__PURE__ */ new Date(endIso + "T00:00:00Z");
      while (cur <= stop) {
        coveredTeamDate.add(`${teamId}::${dateOnlyIso(cur)}`);
        cur.setUTCDate(cur.getUTCDate() + 1);
      }
      const key = `${teamId}::${s.session_date}`;
      if (!weeklySessionsByDate.has(key)) weeklySessionsByDate.set(key, []);
      weeklySessionsByDate.get(key).push(s);
    }
    const rows = [];
    const today = /* @__PURE__ */ new Date();
    today.setHours(0, 0, 0, 0);
    for (let offset = 0; offset < horizonDays; offset++) {
      const date = new Date(today);
      date.setDate(today.getDate() + offset);
      const dateIso = dateOnlyIso(date);
      const weekday = date.getDay();
      const checkins = featureMap.get("checkins");
      if (checkins?.enabled) {
        const cfg = checkins.config || {};
        const enabled = cfg.daily_checkin_enabled !== false;
        const days = Array.isArray(cfg.checkin_days) ? cfg.checkin_days : [0, 1, 2, 3, 4, 5, 6];
        if (enabled && days.includes(weekday)) {
          for (const uid of memberIds) {
            rows.push({
              organization_id: orgId,
              user_id: uid,
              task_type: "daily_checkin",
              title: "Daily Check-in",
              subtitle: "Wie geht's dir heute?",
              scheduled_for: combineDateTime(dateIso, cfg.checkin_available_from ?? "08:00"),
              scheduled_date: dateIso,
              status: "open",
              source_type: "daily_checkin_config",
              source_id: orgId,
              link_target: `/daily-checklist?org=${orgSlug}`,
              payload: { due_time: cfg.checkin_due_time ?? null }
            });
          }
        }
      }
      for (const ch of challengesRes.data ?? []) {
        const cfg = ch.config ?? {};
        if (cfg.daily !== true) continue;
        if (ch.starts_at && new Date(ch.starts_at) > date) continue;
        if (ch.ends_at && new Date(ch.ends_at) < date) continue;
        for (const uid of memberIds) {
          rows.push({
            organization_id: orgId,
            user_id: uid,
            task_type: "challenge",
            title: ch.name || "Challenge Aufgabe",
            subtitle: cfg.subtitle ?? null,
            scheduled_for: combineDateTime(dateIso, cfg.time ?? "12:00"),
            scheduled_date: dateIso,
            status: "open",
            source_type: "challenge",
            source_id: ch.id,
            payload: { challenge_id: ch.id },
            points: typeof cfg.points === "number" ? cfg.points : null
          });
        }
      }
    }
    considered = rows.length;
    const todayIso = dateOnlyIso(today);
    const { data: futureTraining, error: futureErr } = await supabase.from("organization_tasks").select("id").eq("organization_id", orgId).in("task_type", ["team_training", "athletic_training"]).in("status", ["open", "pending"]).gte("scheduled_date", todayIso);
    if (futureErr) errors.push(`training-task cleanup select: ${futureErr.message}`);
    const staleIds = (futureTraining ?? []).map((r) => r.id);
    if (staleIds.length) {
      const { error: delErr } = await supabase.from("organization_tasks").delete().in("id", staleIds);
      if (delErr) errors.push(`training-task cleanup: ${delErr.message}`);
      else removed = staleIds.length;
    }
    if (rows.length) {
      const { error, count } = await supabase.from("organization_tasks").upsert(rows, {
        onConflict: "organization_id,user_id,task_type,source_type,source_id,scheduled_date",
        ignoreDuplicates: true,
        count: "exact"
      });
      if (error) errors.push(`upsert: ${error.message}`);
      else created = count ?? 0;
    }
  } catch (e) {
    errors.push(e?.message || String(e));
  }
  const completed_at = (/* @__PURE__ */ new Date()).toISOString();
  const skipped_duplicate_count = Math.max(0, considered - created);
  try {
    await supabase.from("organization_activity_log").insert({
      organization_id: orgId,
      event_type: "task_engine_run",
      payload: {
        started_at,
        completed_at,
        created_task_count: created,
        skipped_duplicate_count,
        removed_stale_count: removed,
        error_count: errors.length,
        error_details: errors,
        horizon_days: horizonDays
      }
    });
  } catch {
  }
  return {
    organization_id: orgId,
    started_at,
    completed_at,
    created_task_count: created,
    skipped_duplicate_count,
    removed_stale_count: removed,
    error_count: errors.length,
    error_details: errors
  };
}
export {
  runOrgTaskEngineWithClient as r
};
