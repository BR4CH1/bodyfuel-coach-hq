import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import { L as Link } from "../_libs/tanstack__react-router.mjs";
import { u as useQuery } from "../_libs/tanstack__react-query.mjs";
import { u as useSession, a as useServerFn } from "./router-BmNvgrMe.mjs";
import { A as AppLayout } from "./AppLayout-lnbnJZfJ.mjs";
import { P as PlansView } from "./PlansView-CWG8Ubes.mjs";
import { M as MacroTargetsCard } from "./MacroTargetsCard-CgcXH4NZ.mjs";
import { e as TrialNutritionPlan, P as PlanContentView } from "./TrialPlanView-DR4QuuIf.mjs";
import { W as WeekScheduleCard, P as PlateauWarning, D as DietPreferencesCard, C as CustomMealsCard } from "./DietPreferencesCard-DZNOXhfr.mjs";
import { u as useTrial } from "./use-trial-Bz4g3KMx.mjs";
import { g as getMySmartProfile } from "./autopilot-jobs.functions-DxvdXJgH.mjs";
import { M as MealWishesCard } from "./MealWishesCard-BGNE9vYU.mjs";
import "../_libs/sonner.mjs";
import "../_libs/idb.mjs";

import "../_libs/seroval.mjs";
import "../_libs/unenv.mjs";

import "../_libs/lovable.dev__mcp-js.mjs";
import "../_libs/modelcontextprotocol__sdk.mjs";
import "../_libs/zod-to-json-schema.mjs";
import "../_libs/ajv-formats.mjs";
import "../_libs/stripe.mjs";
import { p as Sparkles, F as ChevronRight, aJ as Utensils, H as Heart, c as ShoppingCart, bF as Carrot } from "../_libs/lucide-react.mjs";
import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval-plugins.mjs";


import "../_libs/react-dom.mjs";
import "../_libs/isbot.mjs";
import "../_libs/tanstack__query-core.mjs";
import "./client-mgvTz6tP.mjs";
import "../_libs/supabase__supabase-js.mjs";
import "../_libs/supabase__postgrest-js.mjs";
import "../_libs/supabase__realtime-js.mjs";
import "../_libs/supabase__phoenix.mjs";
import "../_libs/supabase__storage-js.mjs";

import "../_libs/iceberg-js.mjs";
import "../_libs/supabase__auth-js.mjs";
import "../_libs/tslib.mjs";
import "../_libs/supabase__functions-js.mjs";

import "../_libs/radix-ui__react-slot.mjs";
import "../_libs/radix-ui__react-compose-refs.mjs";
import "../_libs/class-variance-authority.mjs";
import "../_libs/clsx.mjs";
import "../_libs/tailwind-merge.mjs";
import "../_libs/radix-ui__react-switch.mjs";
import "../_libs/radix-ui__primitive.mjs";
import "../_libs/radix-ui__react-context.mjs";
import "../_libs/@radix-ui/react-use-controllable-state+[...].mjs";
import "../_libs/@radix-ui/react-use-layout-effect+[...].mjs";
import "../_libs/radix-ui__react-use-previous.mjs";
import "../_libs/radix-ui__react-use-size.mjs";
import "../_libs/radix-ui__react-primitive.mjs";
import "./createSsrRpc-r3tzPO1F.mjs";
import "./server-g-lQHb1O.mjs";
import "../_libs/h3-v2.mjs";
import "../_libs/rou3.mjs";
import "../_libs/srvx.mjs";




import "./auth-middleware-B5YcFrfv.mjs";
import "../_libs/radix-ui__react-label.mjs";
import "../_libs/tanstack__zod-adapter.mjs";
import "../_libs/zod.mjs";
import "../_libs/radix-ui__react-dialog.mjs";
import "../_libs/radix-ui__react-id.mjs";
import "../_libs/@radix-ui/react-dismissable-layer+[...].mjs";
import "../_libs/@radix-ui/react-use-callback-ref+[...].mjs";
import "../_libs/radix-ui__react-focus-scope.mjs";
import "../_libs/radix-ui__react-portal.mjs";
import "../_libs/radix-ui__react-presence.mjs";
import "../_libs/radix-ui__react-focus-guards.mjs";
import "../_libs/react-remove-scroll.mjs";
import "../_libs/react-remove-scroll-bar.mjs";
import "../_libs/react-style-singleton.mjs";
import "../_libs/get-nonce.mjs";
import "../_libs/use-sidecar.mjs";
import "../_libs/use-callback-ref.mjs";
import "../_libs/aria-hidden.mjs";
import "../_libs/radix-ui__react-checkbox.mjs";
import "./coach-analytics.rules-DadTu4Zq.mjs";
import "./football-positions-BJzdkmjv.mjs";
import "./athlete-training-session-pool-CmIQKgmz.mjs";
import "../_libs/lovable.dev__webhooks-js.mjs";
import "./registry-BHGsuy94.mjs";
import "../_libs/react-email__html.mjs";
import "../_libs/react-email__head.mjs";
import "../_libs/react-email__preview.mjs";
import "../_libs/react-email__body.mjs";
import "../_libs/react-email__container.mjs";
import "../_libs/react-email__section.mjs";
import "../_libs/react-email__heading.mjs";
import "../_libs/react-email__text.mjs";
import "../_libs/react-email__button.mjs";
import "../_libs/react-email__hr.mjs";
import "../_libs/react-email__img.mjs";
import "./task-engine.server-BbzZOvQb.mjs";
import "./stripe.server-mcZ3T1eX.mjs";
import "../_libs/lovable.dev__email-js.mjs";
import "../_libs/react-email__render.mjs";
import "../_libs/prettier.mjs";
import "../_libs/html-to-text.mjs";
import "../_libs/selderee__plugin-htmlparser2.mjs";
import "../_libs/selderee.mjs";
import "../_libs/parseley.mjs";
import "../_libs/leac.mjs";
import "../_libs/peberminta.mjs";
import "../_libs/domhandler.mjs";
import "../_libs/domelementtype.mjs";
import "../_libs/htmlparser2.mjs";
import "../_libs/entities.mjs";
import "../_libs/deepmerge.mjs";
import "../_libs/dom-serializer.mjs";
import "../_libs/react-email__link.mjs";
import "../_libs/jose.mjs";
import "../_libs/ajv.mjs";
import "../_libs/fast-deep-equal.mjs";
import "../_libs/json-schema-traverse.mjs";
import "../_libs/fast-uri.mjs";
import "./Logo-B675pmm_.mjs";
import "./textarea-CAY_SJkd.mjs";
import "./OrganizationContextSwitcher-DxSxAmgQ.mjs";
import "./course-instructor.functions-BA-q0LmI.mjs";
import "./nutrition.functions-BVD9gwX2.mjs";
import "./bulls-nutrition.functions-wjyzwTVV.mjs";
import "./meal-skips.functions-2659tu9a.mjs";
import "./DayPlanView-D2AHUXcq.mjs";
import "./trialPlans-V1Tkje_M.mjs";
import "./trial.functions-D9fN4_x8.mjs";
import "./custom-meals.functions-TkxNY1B_.mjs";
function NutritionIndex() {
  const {
    isCoach,
    supabaseUser
  } = useSession();
  const {
    isTrial,
    isExpired
  } = useTrial();
  const [coachClientId, setCoachClientId] = reactExports.useState("");
  const viewClientId = isCoach ? coachClientId : supabaseUser?.id ?? "";
  const getProfile = useServerFn(getMySmartProfile);
  const {
    data: profile
  } = useQuery({
    queryKey: ["smart-profile-me"],
    queryFn: () => getProfile(),
    enabled: !isCoach && !!supabaseUser?.id
  });
  const needsOnboarding = !isCoach && profile !== void 0 && !profile?.completed_at;
  const needsTrainingDays = !isCoach && !!profile?.completed_at && !profile?.training_weekdays?.length;
  return /* @__PURE__ */ jsxRuntimeExports.jsx(AppLayout, { children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-5", children: [
    !isCoach && /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
      needsOnboarding && /* @__PURE__ */ jsxRuntimeExports.jsxs(Link, { to: "/onboarding/smart-nutrition", className: "flex items-center justify-between gap-3 rounded-2xl border border-gold bg-gradient-to-br from-gold/20 to-card p-4 transition hover:from-gold/30", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid h-11 w-11 place-items-center rounded-xl bg-gradient-gold text-primary-foreground", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Sparkles, { className: "h-5 w-5" }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-sm font-bold", children: "Smart Nutrition aktivieren ✨" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs text-muted-foreground", children: "60 Sek. — danach passt sich dein Plan automatisch an deine Vorlieben an" })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronRight, { className: "h-5 w-5 text-gold" })
      ] }),
      needsTrainingDays && /* @__PURE__ */ jsxRuntimeExports.jsxs(Link, { to: "/onboarding/smart-nutrition", className: "flex items-center justify-between gap-3 rounded-2xl border border-amber-500/60 bg-gradient-to-br from-amber-500/15 to-card p-4 transition hover:border-amber-500", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid h-11 w-11 place-items-center rounded-xl bg-amber-500/20 text-amber-500", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Sparkles, { className: "h-5 w-5" }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-sm font-bold", children: "Trainingstage festlegen 💪" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs text-muted-foreground", children: "Damit dein Plan zwischen Trainings- und Restdays unterscheiden kann" })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronRight, { className: "h-5 w-5 text-amber-500" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(Link, { to: "/nutrition/tracking", className: "flex items-center justify-between gap-3 rounded-2xl border border-gold/50 bg-gradient-to-br from-accent/40 to-card p-4 transition hover:border-gold", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid h-11 w-11 place-items-center rounded-xl bg-gradient-gold text-primary-foreground", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Utensils, { className: "h-5 w-5" }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-sm font-bold", children: "Essen tracken" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs text-muted-foreground", children: "Kalorien, Makros & Wasser — mit Barcode-Scanner" })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronRight, { className: "h-5 w-5 text-gold" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(Link, { to: "/nutrition/favorites", className: "flex items-center justify-between gap-3 rounded-2xl border border-border bg-card p-4 transition hover:border-rose-500/50", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid h-11 w-11 place-items-center rounded-xl bg-rose-500/15 text-rose-500", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Heart, { className: "h-5 w-5" }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-sm font-bold", children: "Meine Favoriten" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs text-muted-foreground", children: "Gespeicherte Rezepte & Bewertungen" })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronRight, { className: "h-5 w-5 text-muted-foreground" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(Link, { to: "/nutrition/shopping", className: "flex items-center justify-between gap-3 rounded-2xl border border-border bg-card p-4 transition hover:border-gold/50", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid h-11 w-11 place-items-center rounded-xl bg-gold/15 text-gold", children: /* @__PURE__ */ jsxRuntimeExports.jsx(ShoppingCart, { className: "h-5 w-5" }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-sm font-bold", children: "Einkaufsliste" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs text-muted-foreground", children: "Automatisch aus deinem Plan erstellt" })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronRight, { className: "h-5 w-5 text-muted-foreground" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(Link, { to: "/nutrition/recipe-from-ingredients", className: "flex items-center justify-between gap-3 rounded-2xl border border-border bg-card p-4 transition hover:border-emerald-500/50", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid h-11 w-11 place-items-center rounded-xl bg-emerald-500/15 text-emerald-500", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Carrot, { className: "h-5 w-5" }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-sm font-bold", children: "Rezept aus Zutaten" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs text-muted-foreground", children: "Sag was du hast — wir bauen dir ein Rezept" })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronRight, { className: "h-5 w-5 text-muted-foreground" })
      ] }),
      supabaseUser?.id && profile?.completed_at && /* @__PURE__ */ jsxRuntimeExports.jsx(WeekScheduleCard, { userId: supabaseUser.id }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(MacroTargetsCard, { userId: supabaseUser?.id }),
      supabaseUser?.id && /* @__PURE__ */ jsxRuntimeExports.jsx(PlateauWarning, { userId: supabaseUser.id }),
      supabaseUser?.id && profile?.completed_at && /* @__PURE__ */ jsxRuntimeExports.jsx(DietPreferencesCard, {}),
      supabaseUser?.id && /* @__PURE__ */ jsxRuntimeExports.jsx(MealWishesCard, { userId: supabaseUser.id, mode: "client" }),
      supabaseUser?.id && /* @__PURE__ */ jsxRuntimeExports.jsx(CustomMealsCard, { userId: supabaseUser.id })
    ] }),
    isCoach && /* @__PURE__ */ jsxRuntimeExports.jsx(PlansView, { planType: "nutrition", onClientChange: setCoachClientId }),
    !isCoach && (isTrial || isExpired) ? /* @__PURE__ */ jsxRuntimeExports.jsx(TrialNutritionPlan, {}) : viewClientId && /* @__PURE__ */ jsxRuntimeExports.jsx(PlanContentView, { clientId: viewClientId, planType: "nutrition" })
  ] }) });
}
export {
  NutritionIndex as component
};
