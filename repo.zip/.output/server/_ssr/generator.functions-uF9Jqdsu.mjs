import process from "node:process";
import { c as createServerRpc } from "./createServerRpc--OrbljSy.mjs";
import { c as createServerFn } from "./server-g-lQHb1O.mjs";
import { r as requireSupabaseAuth } from "./auth-middleware-B5YcFrfv.mjs";

import "../_libs/seroval.mjs";
import "../_libs/react.mjs";
import { a as objectType, H as enumType, C as numberType, y as stringType } from "../_libs/zod.mjs";
import "../_libs/h3-v2.mjs";
import "../_libs/unenv.mjs";


import "../_libs/rou3.mjs";
import "../_libs/srvx.mjs";





import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval-plugins.mjs";

import "../_libs/tanstack__react-router.mjs";
import "../_libs/react-dom.mjs";
import "../_libs/isbot.mjs";
import "../_libs/supabase__supabase-js.mjs";
import "../_libs/supabase__postgrest-js.mjs";
import "../_libs/supabase__realtime-js.mjs";
import "../_libs/supabase__phoenix.mjs";
import "../_libs/supabase__storage-js.mjs";
import "../_libs/iceberg-js.mjs";
import "../_libs/supabase__auth-js.mjs";
import "../_libs/tslib.mjs";
import "../_libs/supabase__functions-js.mjs";
const Input = objectType({
  target_group: stringType().min(1).max(200),
  goal: stringType().min(1).max(200),
  equipment: stringType().max(300).optional().default(""),
  duration_minutes: numberType().int().min(10).max(120).default(45),
  intensity: enumType(["easy", "medium", "hard"]).default("medium")
});
const generateCourse_createServerFn_handler = createServerRpc({
  id: "2f0888119aa08fee5398805b4998514da47370f0b650f91723763498e6da5d25",
  name: "generateCourse",
  filename: "src/lib/course-tools/generator.functions.ts"
}, (opts) => generateCourse.__executeServer(opts));
const generateCourse = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => Input.parse(d)).handler(generateCourse_createServerFn_handler, async ({
  data
}) => {
  const apiKey = process.env.LOVABLE_API_KEY;
  if (!apiKey) throw new Error("LOVABLE_API_KEY fehlt");
  const system = `Du bist erfahrener Group-Fitness-Trainer. Antworte AUSSCHLIESSLICH mit gültigem JSON in genau diesem Schema:
{
  "name": "string",
  "summary": "string",
  "blocks": [
    {
      "phase": "warmup" | "main" | "finisher" | "cooldown",
      "title": "string",
      "duration_seconds": number,
      "timer_type": "countdown" | "interval" | "tabata" | "emom" | "amrap" | "stopwatch",
      "exercises": [{ "name": "string", "cue": "string?", "reps": "string?", "work_sec": number?, "rest_sec": number? }],
      "notes": "string?"
    }
  ]
}
Immer 4 Blöcke in Reihenfolge: warmup, main, finisher, cooldown. Passe timer_type & Dauer sinnvoll an.`;
  const prompt = `Zielgruppe: ${data.target_group}
Ziel: ${data.goal}
Equipment: ${data.equipment || "Bodyweight"}
Gesamtdauer: ${data.duration_minutes} Minuten
Intensität: ${data.intensity}
Erstelle einen deutschsprachigen Kursplan.`;
  const res = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Lovable-API-Key": apiKey
    },
    body: JSON.stringify({
      model: "google/gemini-3-flash-preview",
      response_format: {
        type: "json_object"
      },
      messages: [{
        role: "system",
        content: system
      }, {
        role: "user",
        content: prompt
      }]
    })
  });
  if (res.status === 429) throw new Error("Rate-Limit erreicht — bitte gleich nochmal versuchen.");
  if (res.status === 402) throw new Error("Guthaben aufgebraucht — bitte aufladen.");
  if (!res.ok) throw new Error(`AI-Fehler [${res.status}]`);
  const json = await res.json();
  const raw = json?.choices?.[0]?.message?.content ?? "{}";
  const parsed = typeof raw === "string" ? JSON.parse(raw) : raw;
  return parsed;
});
export {
  generateCourse_createServerFn_handler
};
