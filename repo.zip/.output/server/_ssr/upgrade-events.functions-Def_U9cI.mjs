import { c as createServerRpc } from "./createServerRpc--OrbljSy.mjs";
import { c as createServerFn } from "./server-g-lQHb1O.mjs";
import { r as requireSupabaseAuth } from "./auth-middleware-B5YcFrfv.mjs";

import "../_libs/seroval.mjs";
import "../_libs/react.mjs";

import "../_libs/h3-v2.mjs";
import "../_libs/unenv.mjs";


import "../_libs/rou3.mjs";
import "../_libs/srvx.mjs";





import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval-plugins.mjs";

import "../_libs/tanstack__react-router.mjs";
import "../_libs/react-dom.mjs";
import "../_libs/isbot.mjs";
import "../_libs/supabase__supabase-js.mjs";
import "../_libs/supabase__postgrest-js.mjs";
import "../_libs/supabase__realtime-js.mjs";
import "../_libs/supabase__phoenix.mjs";
import "../_libs/supabase__storage-js.mjs";
import "../_libs/iceberg-js.mjs";
import "../_libs/supabase__auth-js.mjs";
import "../_libs/tslib.mjs";
import "../_libs/supabase__functions-js.mjs";
const trackUpgradeEvent_createServerFn_handler = createServerRpc({
  id: "3cc68ac38ce2eb97af677497431efe31bb8b5bbf714b8f915880ca2af19e57f0",
  name: "trackUpgradeEvent",
  filename: "src/lib/upgrade-events.functions.ts"
}, (opts) => trackUpgradeEvent.__executeServer(opts));
const trackUpgradeEvent = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => d).handler(trackUpgradeEvent_createServerFn_handler, async ({
  data,
  context
}) => {
  const {
    error
  } = await context.supabase.from("upgrade_events").insert({
    user_id: context.userId,
    to_tier: data.to_tier,
    from_tier: data.from_tier ?? null,
    event: data.event ?? "click",
    source: data.source ?? null
  });
  if (error) throw new Error(error.message);
  return {
    ok: true
  };
});
const getTierMetrics_createServerFn_handler = createServerRpc({
  id: "b7b4408248285dcce3fd7fe45df3fea58460242a05d726ff11e99d9395c6c665",
  name: "getTierMetrics",
  filename: "src/lib/upgrade-events.functions.ts"
}, (opts) => getTierMetrics.__executeServer(opts));
const getTierMetrics = createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).handler(getTierMetrics_createServerFn_handler, async ({
  context
}) => {
  const {
    data: isCoach,
    error: rErr
  } = await context.supabase.rpc("has_role", {
    _user_id: context.userId,
    _role: "coach"
  });
  if (rErr) throw new Error(rErr.message);
  if (!isCoach) throw new Error("Nicht autorisiert");
  const {
    data: pkgs
  } = await context.supabase.from("customer_packages").select("package, user_id").eq("is_active", true);
  const smartUsers = /* @__PURE__ */ new Set();
  const coachingUsers = /* @__PURE__ */ new Set();
  for (const p of pkgs ?? []) {
    if (p.package === "smart") smartUsers.add(p.user_id);
    else coachingUsers.add(p.user_id);
  }
  const {
    count: freeCount
  } = await context.supabase.from("user_roles").select("user_id", {
    count: "exact",
    head: true
  }).eq("role", "free");
  const free = freeCount ?? 0;
  const {
    count: trialCount
  } = await context.supabase.from("profiles").select("id", {
    count: "exact",
    head: true
  }).eq("trial_status", "trial");
  const trial = trialCount ?? 0;
  const now = Date.now();
  const d7 = new Date(now - 7 * 864e5).toISOString();
  const d30 = new Date(now - 30 * 864e5).toISOString();
  const {
    count: clicks7
  } = await context.supabase.from("upgrade_events").select("id", {
    count: "exact",
    head: true
  }).eq("event", "click").gte("created_at", d7);
  const {
    count: clicks30
  } = await context.supabase.from("upgrade_events").select("id", {
    count: "exact",
    head: true
  }).eq("event", "click").gte("created_at", d30);
  async function convCount(from, to) {
    const {
      count
    } = await context.supabase.from("upgrade_events").select("id", {
      count: "exact",
      head: true
    }).eq("event", "completed").eq("from_tier", from).eq("to_tier", to).gte("created_at", d30);
    return count ?? 0;
  }
  const [t2s, t2c, f2s, f2c, s2c] = await Promise.all([convCount("trial", "smart"), convCount("trial", "coaching"), convCount("free", "smart"), convCount("free", "coaching"), convCount("smart", "coaching")]);
  return {
    active: {
      free,
      trial,
      smart: smartUsers.size,
      coaching: coachingUsers.size
    },
    clicks: {
      last7: clicks7 ?? 0,
      last30: clicks30 ?? 0
    },
    conversions: {
      trial_to_smart: t2s,
      trial_to_coaching: t2c,
      free_to_smart: f2s,
      free_to_coaching: f2c,
      smart_to_coaching: s2c
    }
  };
});
export {
  getTierMetrics_createServerFn_handler,
  trackUpgradeEvent_createServerFn_handler
};
