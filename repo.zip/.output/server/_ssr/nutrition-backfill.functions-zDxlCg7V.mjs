import { c as createServerRpc } from "./createServerRpc--OrbljSy.mjs";
import { c as createServerFn } from "./server-g-lQHb1O.mjs";
import { r as requireSupabaseAuth } from "./auth-middleware-B5YcFrfv.mjs";

import "../_libs/seroval.mjs";
import "../_libs/react.mjs";

import "../_libs/h3-v2.mjs";
import "../_libs/unenv.mjs";


import "../_libs/rou3.mjs";
import "../_libs/srvx.mjs";





import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval-plugins.mjs";

import "../_libs/tanstack__react-router.mjs";
import "../_libs/react-dom.mjs";
import "../_libs/isbot.mjs";
import "../_libs/supabase__supabase-js.mjs";
import "../_libs/supabase__postgrest-js.mjs";
import "../_libs/supabase__realtime-js.mjs";
import "../_libs/supabase__phoenix.mjs";
import "../_libs/supabase__storage-js.mjs";
import "../_libs/iceberg-js.mjs";
import "../_libs/supabase__auth-js.mjs";
import "../_libs/tslib.mjs";
import "../_libs/supabase__functions-js.mjs";
const recomputeAllPlanMacros_createServerFn_handler = createServerRpc({
  id: "34659c1fd7f88bb359894b2c26bc8420754f8c007bdaa5442a9271529c7d901e",
  name: "recomputeAllPlanMacros",
  filename: "src/lib/nutrition-backfill.functions.ts"
}, (opts) => recomputeAllPlanMacros.__executeServer(opts));
const recomputeAllPlanMacros = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).handler(recomputeAllPlanMacros_createServerFn_handler, async ({
  context
}) => {
  const {
    supabase,
    userId
  } = context;
  const {
    data: isCoach
  } = await supabase.rpc("has_role", {
    _user_id: userId,
    _role: "coach"
  });
  if (!isCoach) throw new Error("Nur für Coaches");
  const [{
    computeMealFromIngredients,
    computeMealFromDescription,
    coerceIngredients,
    isUsableEngineResult
  }, {
    enforceKcalConsistency
  }, {
    supabaseAdmin
  }] = await Promise.all([import("./nutrition-engine.server-D4Un9J9I.mjs"), import("./nutrition-verify.server-Bx5rlCva.mjs"), import("./client.server-D5ro3rAQ.mjs")]);
  const {
    data: meals,
    error
  } = await supabaseAdmin.from("nutrition_plan_meals").select("id, description, ingredients_json, kcal, protein_g, carbs_g, fat_g, data_source, verified_ratio, nutrition_plan_days!inner(plan_id, nutrition_plans!inner(status))").in("nutrition_plan_days.nutrition_plans.status", ["active", "draft", "scheduled"]);
  if (error) throw new Error(error.message);
  let updated = 0;
  let viaEngine = 0;
  let viaParser = 0;
  let kcalFixed = 0;
  for (const m of meals ?? []) {
    let kcal = m.kcal;
    let p = m.protein_g;
    let c = m.carbs_g;
    let f = m.fat_g;
    let data_source = m.data_source;
    let verified_ratio = m.verified_ratio;
    let warnings = [];
    const structured = coerceIngredients(m.ingredients_json ?? null);
    if (structured.length) {
      const r = await computeMealFromIngredients(supabaseAdmin, structured);
      if (isUsableEngineResult(r)) {
        kcal = r.kcal;
        p = r.protein_g;
        c = r.carbs_g;
        f = r.fat_g;
        data_source = r.data_source;
        verified_ratio = r.coverage;
        warnings = r.warnings;
        viaEngine += 1;
      }
    } else {
      const rc = await computeMealFromDescription(supabaseAdmin, m.description);
      if (isUsableEngineResult(rc)) {
        kcal = rc.kcal;
        p = rc.protein_g;
        c = rc.carbs_g;
        f = rc.fat_g;
        data_source = rc.data_source;
        verified_ratio = rc.coverage;
        warnings = rc.warnings;
        viaParser += 1;
      } else {
        const fixed = enforceKcalConsistency({
          kcal,
          protein_g: p,
          carbs_g: c,
          fat_g: f
        });
        if (fixed.kcal !== m.kcal) kcalFixed += 1;
        kcal = fixed.kcal;
      }
    }
    const changed = kcal !== m.kcal || p !== m.protein_g || c !== m.carbs_g || f !== m.fat_g || data_source !== m.data_source;
    if (changed || warnings.length) {
      await supabaseAdmin.from("nutrition_plan_meals").update({
        kcal,
        protein_g: p,
        carbs_g: c,
        fat_g: f,
        data_source,
        verified_ratio,
        compute_warnings: warnings
      }).eq("id", m.id);
      if (changed) updated += 1;
    }
  }
  return {
    ok: true,
    scanned: meals?.length ?? 0,
    updated,
    via_engine: viaEngine,
    via_parser: viaParser,
    kcal_fixed: kcalFixed
  };
});
const runNutritionEngineTests_createServerFn_handler = createServerRpc({
  id: "f4f406c02fd6c1701045aba07ef4c64d1d0ae2a998167258642b580be06a24a6",
  name: "runNutritionEngineTests",
  filename: "src/lib/nutrition-backfill.functions.ts"
}, (opts) => runNutritionEngineTests.__executeServer(opts));
const runNutritionEngineTests = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).handler(runNutritionEngineTests_createServerFn_handler, async ({
  context
}) => {
  const {
    supabase,
    userId
  } = context;
  const {
    data: isCoach
  } = await supabase.rpc("has_role", {
    _user_id: userId,
    _role: "coach"
  });
  if (!isCoach) throw new Error("Nur für Coaches");
  const {
    runEngineSelfTests
  } = await import("./nutrition-engine.server-D4Un9J9I.mjs");
  const {
    supabaseAdmin
  } = await import("./client.server-D5ro3rAQ.mjs");
  return runEngineSelfTests(supabaseAdmin);
});
export {
  recomputeAllPlanMacros_createServerFn_handler,
  runNutritionEngineTests_createServerFn_handler
};
