import { c as createSsrRpc } from "./createSsrRpc-r3tzPO1F.mjs";
import { c as createServerFn } from "./server-g-lQHb1O.mjs";
import { r as requireSupabaseAuth } from "./auth-middleware-B5YcFrfv.mjs";
import { a as objectType, y as stringType, A as booleanType, B as unionType, C as numberType, D as nullType, z as arrayType } from "../_libs/zod.mjs";
const recomputePlayerCard = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator(objectType({
  user_id: stringType().uuid().optional()
}).parse).handler(createSsrRpc("6543b6e06156e1f43d236087fb731f436baf32294ab2eafa2782d41e500168ce"));
const getMyPlayerCard = createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).handler(createSsrRpc("a577f2da260f90f0302ebd37c085be469b237d46efbc3af6aa0f5d769ac09036"));
const getPlayerCardForAthlete = createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).inputValidator(objectType({
  user_id: stringType().uuid()
}).parse).handler(createSsrRpc("07fd6a658e6b25f6aaf8fd3edc837191101ce0172ad1a5f6cf56ab119eb805ae"));
createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator(objectType({
  badge_keys: arrayType(stringType()).optional()
}).parse).handler(createSsrRpc("3b0b4fa4692ddf13dc95c2ffee508ce8af8b4831a6966a4f86f059d2fb6ea978"));
const listCoachPlayerCards = createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).handler(createSsrRpc("961a685e4e2712ffc2845f6fd26e96839741d7452da2174683e2c03ff92e2c53"));
const getPlayerCardRanking = createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).inputValidator((d) => ({
  organization_id: String(d.organization_id),
  team_id: d.team_id ? String(d.team_id) : null,
  limit: Math.min(Math.max(Number(d.limit ?? 100), 1), 500)
})).handler(createSsrRpc("87b221b45a63d527fa4567e6280dab26969448d4293fd7990d8657e01700a485"));
function currentYearMonth() {
  const d = /* @__PURE__ */ new Date();
  return {
    year: d.getUTCFullYear(),
    month: d.getUTCMonth() + 1
  };
}
const getPlayerOfTheMonthCandidates = createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).inputValidator((d) => {
  const fb = currentYearMonth();
  return {
    organization_id: String(d.organization_id),
    year: Number.isFinite(d.year) ? Number(d.year) : fb.year,
    month: Number.isFinite(d.month) ? Number(d.month) : fb.month
  };
}).handler(createSsrRpc("734f58a760aaa91a80faee36643a951e2bda9df0e222a6f516ec2b806533e3e1"));
const getTeamOfTheMonthCandidates = createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).inputValidator((d) => {
  const fb = currentYearMonth();
  return {
    organization_id: String(d.organization_id),
    year: Number.isFinite(d.year) ? Number(d.year) : fb.year,
    month: Number.isFinite(d.month) ? Number(d.month) : fb.month
  };
}).handler(createSsrRpc("4693b7dc61318d4deaef2121349971b4b99e5ec40233d8e05c4e86fdd323d826"));
const finalizePlayerOfTheMonth = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => ({
  organization_id: String(d.organization_id),
  year: Number(d.year),
  month: Number(d.month),
  user_id: String(d.user_id),
  award_kind: d.award_kind ?? "top_bfr",
  team_id: d.team_id ? String(d.team_id) : null,
  bfr_at_award: Math.round(Number(d.bfr_at_award)),
  bfr_delta: Math.round(Number(d.bfr_delta))
})).handler(createSsrRpc("635510b8479c05f7c2ed0d9543761a2da9c62d0a1235c9206cd8aff8f01cdcb4"));
const getPlayerCardHallOfFame = createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).inputValidator((d) => ({
  organization_id: String(d.organization_id),
  limit: Math.min(Math.max(Number(d.limit ?? 24), 1), 120)
})).handler(createSsrRpc("02797a5433c7690cdebe8ed3d07ff08578931bce4b691126c29590e231b047df"));
const listPlayerCardPositionWeights = createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).inputValidator((d) => ({
  sport: d?.sport ?? null
})).handler(createSsrRpc("36b3cb948b0c26c01d27f6d945aaf4b1e2a1b80165d450af8c67d0dd7836d598"));
const listPlayerCardBenchmarks = createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).inputValidator((d) => ({
  sport: d?.sport ?? null
})).handler(createSsrRpc("866a984aed89ba8d303925ffcb342663e20a2f21871c11ca173ccea50ae22acb"));
const upsertPlayerCardPositionWeight = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => ({
  id: d.id ?? null,
  sport: String(d.sport).trim(),
  position_key: String(d.position_key).trim().toUpperCase(),
  label: String(d.label).trim(),
  w_spd: Number(d.w_spd),
  w_acc: Number(d.w_acc),
  w_agi: Number(d.w_agi),
  w_pow: Number(d.w_pow),
  w_str: Number(d.w_str),
  w_end: Number(d.w_end)
})).handler(createSsrRpc("c66bb08aa15d8f7a64a14857c71abbf24a480b8736c42397b34d449e20aed68c"));
const deletePlayerCardPositionWeight = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => ({
  id: String(d.id)
})).handler(createSsrRpc("f15c7684fa8af11b4720693017d946cc4cff3d2c915216195284b9e55e06a61c"));
const upsertPlayerCardBenchmark = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => ({
  id: d.id ?? null,
  sport: String(d.sport).trim(),
  attribute_key: String(d.attribute_key).trim().toUpperCase(),
  metric_key: String(d.metric_key).trim(),
  direction: d.direction === "lower_is_better" ? "lower_is_better" : "higher_is_better",
  weight: Number(d.weight),
  anchors: Array.isArray(d.anchors) ? d.anchors.map((a) => ({
    value: Number(a.value),
    score: Number(a.score)
  })) : []
})).handler(createSsrRpc("7cde1962d10ec6801cf3098005e5179614bc135012ecefe77e4d269af53af827"));
const deletePlayerCardBenchmark = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => ({
  id: String(d.id)
})).handler(createSsrRpc("df0a2d459a55ebedc9e29b2653275d5aee6119b331a877de26f6b708106ca560"));
const ensurePlayerCardCutout = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator(objectType({
  user_id: stringType().uuid().optional(),
  force: booleanType().optional()
}).parse).handler(createSsrRpc("7b316308777751cf66f8a8ef622868a8e339f04cf630a016f79519643d357064"));
const OverrideNumber = unionType([numberType().int().min(0).max(99), nullType()]).optional();
const savePlayerCardManualOverrides = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator(objectType({
  user_id: stringType().uuid(),
  overrides: objectType({
    BFR: OverrideNumber,
    SPD: OverrideNumber,
    ACC: OverrideNumber,
    AGI: OverrideNumber,
    POW: OverrideNumber,
    STR: OverrideNumber,
    END: OverrideNumber
  }).partial(),
  is_published: booleanType().optional()
}).parse).handler(createSsrRpc("0cfc0f1ecd78c2a901ffc594dd1bc8c53f874cc151ac4766c400377621667f93"));
const saveCustomPlayerCardImage = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator(objectType({
  user_id: stringType().uuid(),
  storage_path: stringType().nullable()
}).parse).handler(createSsrRpc("4f3c76726a4ec8387cef57e90a0e02a78a78833dc13ea2406a7a45a5cf9cc48f"));
export {
  listPlayerCardBenchmarks as a,
  upsertPlayerCardBenchmark as b,
  deletePlayerCardBenchmark as c,
  deletePlayerCardPositionWeight as d,
  listCoachPlayerCards as e,
  getPlayerCardRanking as f,
  getMyPlayerCard as g,
  getPlayerOfTheMonthCandidates as h,
  finalizePlayerOfTheMonth as i,
  getTeamOfTheMonthCandidates as j,
  getPlayerCardHallOfFame as k,
  listPlayerCardPositionWeights as l,
  getPlayerCardForAthlete as m,
  ensurePlayerCardCutout as n,
  savePlayerCardManualOverrides as o,
  recomputePlayerCard as r,
  saveCustomPlayerCardImage as s,
  upsertPlayerCardPositionWeight as u
};
