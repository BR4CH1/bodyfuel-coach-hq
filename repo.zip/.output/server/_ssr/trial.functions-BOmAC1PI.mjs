import { c as createServerRpc } from "./createServerRpc--OrbljSy.mjs";
import { c as createServerFn } from "./server-g-lQHb1O.mjs";
import { r as requireSupabaseAuth } from "./auth-middleware-B5YcFrfv.mjs";

import "../_libs/seroval.mjs";
import "../_libs/react.mjs";

import "../_libs/h3-v2.mjs";
import "../_libs/unenv.mjs";


import "../_libs/rou3.mjs";
import "../_libs/srvx.mjs";





import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval-plugins.mjs";

import "../_libs/tanstack__react-router.mjs";
import "../_libs/react-dom.mjs";
import "../_libs/isbot.mjs";
import "../_libs/supabase__supabase-js.mjs";
import "../_libs/supabase__postgrest-js.mjs";
import "../_libs/supabase__realtime-js.mjs";
import "../_libs/supabase__phoenix.mjs";
import "../_libs/supabase__storage-js.mjs";
import "../_libs/iceberg-js.mjs";
import "../_libs/supabase__auth-js.mjs";
import "../_libs/tslib.mjs";
import "../_libs/supabase__functions-js.mjs";
const TRIAL_DAYS_DEFAULT = 7;
function todayIso() {
  return (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
}
function addDaysIso(base, days) {
  const d = base ? new Date(base) : /* @__PURE__ */ new Date();
  d.setUTCDate(d.getUTCDate() + days);
  return d.toISOString().slice(0, 10);
}
async function assertCoach(supabase, userId) {
  const {
    data,
    error
  } = await supabase.rpc("has_role", {
    _user_id: userId,
    _role: "coach"
  });
  if (error) throw new Error(error.message);
  if (!data) throw new Error("Forbidden");
}
const TRIAL_TRAINING_PLAN_TITLE = "Trial Starterplan";
async function seedTrialTrainingPlanFor(userId) {
  const {
    supabaseAdmin
  } = await import("./client.server-D5ro3rAQ.mjs");
  const {
    TRIAL_TRAINING
  } = await import("./trialPlans-V1Tkje_M.mjs");
  const {
    data: existingPlan
  } = await supabaseAdmin.from("nutrition_plans").select("id").eq("client_id", userId).eq("plan_type", "training").eq("title", TRIAL_TRAINING_PLAN_TITLE).maybeSingle();
  if (existingPlan?.id) return {
    ok: true,
    plan_id: existingPlan.id,
    created: false
  };
  const {
    data: anyActive
  } = await supabaseAdmin.from("nutrition_plans").select("id").eq("client_id", userId).eq("plan_type", "training").eq("is_active", true).maybeSingle();
  if (anyActive?.id) return {
    ok: true,
    plan_id: anyActive.id,
    created: false
  };
  const {
    data: plan,
    error: planErr
  } = await supabaseAdmin.from("nutrition_plans").insert({
    client_id: userId,
    title: TRIAL_TRAINING_PLAN_TITLE,
    plan_type: "training",
    is_active: true,
    file_path: "trial://starter-training",
    file_name: "trial-starter.json"
  }).select("id").single();
  if (planErr) throw new Error(planErr.message);
  for (let i = 0; i < TRIAL_TRAINING.length; i++) {
    const td = TRIAL_TRAINING[i];
    const {
      data: dayRow,
      error: dayErr
    } = await supabaseAdmin.from("training_days").insert({
      plan_id: plan.id,
      name: `${td.name} — ${td.focus}`,
      sort_order: i
    }).select("id").single();
    if (dayErr) throw new Error(dayErr.message);
    if (td.exercises.length) {
      const exRows = td.exercises.map((ex, idx) => ({
        day_id: dayRow.id,
        name: ex.name,
        target_sets: ex.sets,
        target_reps: ex.reps,
        notes: ex.notes ?? null,
        sort_order: idx
      }));
      const {
        error: exErr
      } = await supabaseAdmin.from("training_exercises").insert(exRows);
      if (exErr) throw new Error(exErr.message);
    }
  }
  return {
    ok: true,
    plan_id: plan.id,
    created: true
  };
}
async function seedTrialNutritionTargetsFor(userId) {
  const {
    supabaseAdmin
  } = await import("./client.server-D5ro3rAQ.mjs");
  const {
    data: existing
  } = await supabaseAdmin.from("nutrition_targets").select("user_id, kcal_rest").eq("user_id", userId).maybeSingle();
  if (existing && existing.kcal_rest != null) return {
    ok: true,
    created: false
  };
  const payload = {
    user_id: userId,
    kcal: 2400,
    protein_g: 191,
    carbs_g: 258,
    fat_g: 55,
    kcal_rest: 2e3,
    protein_g_rest: 165,
    carbs_g_rest: 44,
    fat_g_rest: 106
  };
  const {
    error
  } = await supabaseAdmin.from("nutrition_targets").upsert(payload, {
    onConflict: "user_id"
  });
  if (error) throw new Error(error.message);
  return {
    ok: true,
    created: true
  };
}
const ensureTrialTrainingPlan_createServerFn_handler = createServerRpc({
  id: "31cbb2907e32f9831bd9558b66f2c0891e4b43edae1867ec607bf1fcd57f5a25",
  name: "ensureTrialTrainingPlan",
  filename: "src/lib/trial.functions.ts"
}, (opts) => ensureTrialTrainingPlan.__executeServer(opts));
const ensureTrialTrainingPlan = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).handler(ensureTrialTrainingPlan_createServerFn_handler, async ({
  context
}) => {
  const r = await seedTrialTrainingPlanFor(context.userId);
  try {
    await seedTrialNutritionTargetsFor(context.userId);
  } catch (e) {
    console.error(e);
  }
  return r;
});
const startMyTrial_createServerFn_handler = createServerRpc({
  id: "949c2a05cd503f4116f6e3117fea3f6cf7c36f8aef19d8df4de47da7e033e07c",
  name: "startMyTrial",
  filename: "src/lib/trial.functions.ts"
}, (opts) => startMyTrial.__executeServer(opts));
const startMyTrial = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).handler(startMyTrial_createServerFn_handler, async ({
  context
}) => {
  const {
    supabaseAdmin
  } = await import("./client.server-D5ro3rAQ.mjs");
  const {
    data: existing
  } = await supabaseAdmin.from("profiles").select("trial_status, trial_start, trial_end").eq("id", context.userId).maybeSingle();
  if (existing && existing.trial_status !== "none") {
    return {
      ok: true,
      trial_status: existing.trial_status,
      trial_start: existing.trial_start,
      trial_end: existing.trial_end
    };
  }
  const start = todayIso();
  const end = addDaysIso(start, TRIAL_DAYS_DEFAULT);
  const {
    error
  } = await supabaseAdmin.from("profiles").update({
    trial_status: "trial",
    trial_start: start,
    trial_end: end
  }).eq("id", context.userId);
  if (error) throw new Error(error.message);
  return {
    ok: true,
    trial_status: "trial",
    trial_start: start,
    trial_end: end
  };
});
const coachExtendTrial_createServerFn_handler = createServerRpc({
  id: "a33eed62c068f8cb9efd4ae1b2d9ad24865569066e4ee1c10db071e80d24a72a",
  name: "coachExtendTrial",
  filename: "src/lib/trial.functions.ts"
}, (opts) => coachExtendTrial.__executeServer(opts));
const coachExtendTrial = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((data) => data).handler(coachExtendTrial_createServerFn_handler, async ({
  data,
  context
}) => {
  await assertCoach(context.supabase, context.userId);
  if (!Number.isFinite(data.days) || data.days < 1 || data.days > 365) {
    throw new Error("Ungültige Tageszahl (1–365)");
  }
  const {
    supabaseAdmin
  } = await import("./client.server-D5ro3rAQ.mjs");
  const {
    data: prof
  } = await supabaseAdmin.from("profiles").select("trial_status, trial_start, trial_end").eq("id", data.user_id).maybeSingle();
  const today = todayIso();
  const base = prof?.trial_end && prof.trial_end > today ? prof.trial_end : today;
  const newEnd = addDaysIso(base, data.days);
  const newStart = prof?.trial_start ?? today;
  const {
    error
  } = await supabaseAdmin.from("profiles").update({
    trial_status: "trial",
    trial_start: newStart,
    trial_end: newEnd
  }).eq("id", data.user_id);
  if (error) throw new Error(error.message);
  return {
    ok: true,
    trial_end: newEnd
  };
});
const coachStartTrial_createServerFn_handler = createServerRpc({
  id: "4af1844c82398e302a70acefca705c318ea90d12c5b0dda9721288d17b1a0511",
  name: "coachStartTrial",
  filename: "src/lib/trial.functions.ts"
}, (opts) => coachStartTrial.__executeServer(opts));
const coachStartTrial = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((data) => data).handler(coachStartTrial_createServerFn_handler, async ({
  data,
  context
}) => {
  await assertCoach(context.supabase, context.userId);
  if (!Number.isFinite(data.days) || data.days < 1 || data.days > 365) {
    throw new Error("Ungültige Tageszahl (1–365)");
  }
  const {
    supabaseAdmin
  } = await import("./client.server-D5ro3rAQ.mjs");
  const start = todayIso();
  const end = addDaysIso(start, data.days);
  const {
    error
  } = await supabaseAdmin.from("profiles").update({
    trial_status: "trial",
    trial_start: start,
    trial_end: end
  }).eq("id", data.user_id);
  if (error) throw new Error(error.message);
  return {
    ok: true,
    trial_start: start,
    trial_end: end
  };
});
const coachEndTrial_createServerFn_handler = createServerRpc({
  id: "de9d4f14d41bedee6111e6bfb8ce0be1fe6a3cf53cec46a67cf0885b6ffacf84",
  name: "coachEndTrial",
  filename: "src/lib/trial.functions.ts"
}, (opts) => coachEndTrial.__executeServer(opts));
const coachEndTrial = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((data) => data).handler(coachEndTrial_createServerFn_handler, async ({
  data,
  context
}) => {
  await assertCoach(context.supabase, context.userId);
  const {
    supabaseAdmin
  } = await import("./client.server-D5ro3rAQ.mjs");
  const {
    error
  } = await supabaseAdmin.from("profiles").update({
    trial_status: "trial_expired",
    trial_end: todayIso()
  }).eq("id", data.user_id);
  if (error) throw new Error(error.message);
  return {
    ok: true
  };
});
const coachActivateMember_createServerFn_handler = createServerRpc({
  id: "3d506a6bee8145dc417c764a5a865de2fbe9de59146c7bd40bce2510b9782623",
  name: "coachActivateMember",
  filename: "src/lib/trial.functions.ts"
}, (opts) => coachActivateMember.__executeServer(opts));
const coachActivateMember = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((data) => data).handler(coachActivateMember_createServerFn_handler, async ({
  data,
  context
}) => {
  await assertCoach(context.supabase, context.userId);
  const {
    supabaseAdmin
  } = await import("./client.server-D5ro3rAQ.mjs");
  const {
    error
  } = await supabaseAdmin.from("profiles").update({
    trial_status: "active"
  }).eq("id", data.user_id);
  if (error) throw new Error(error.message);
  return {
    ok: true
  };
});
const listTrialUsers_createServerFn_handler = createServerRpc({
  id: "c385c5d3ef35e012c0b5f0b7e361781950124b6be9d1afd140de13633d2bf1ac",
  name: "listTrialUsers",
  filename: "src/lib/trial.functions.ts"
}, (opts) => listTrialUsers.__executeServer(opts));
const listTrialUsers = createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).handler(listTrialUsers_createServerFn_handler, async ({
  context
}) => {
  await assertCoach(context.supabase, context.userId);
  const {
    supabaseAdmin
  } = await import("./client.server-D5ro3rAQ.mjs");
  const {
    data,
    error
  } = await supabaseAdmin.from("profiles").select("id, display_name, nickname, trial_status, trial_start, trial_end, created_at").in("trial_status", ["trial", "trial_expired"]).order("trial_end", {
    ascending: true
  });
  if (error) throw new Error(error.message);
  const rows = data ?? [];
  const ids = rows.map((r) => r.id);
  if (ids.length === 0) return rows;
  const [usersRes, groupsRes] = await Promise.all([supabaseAdmin.auth.admin.listUsers({
    page: 1,
    perPage: 1e3
  }), supabaseAdmin.from("user_groups").select("user_id, group_name").in("user_id", ids)]);
  const emailMap = new Map(usersRes.data.users.map((u) => [u.id, u.email]));
  const groupsByUser = /* @__PURE__ */ new Map();
  for (const g of groupsRes.data ?? []) {
    const a = groupsByUser.get(g.user_id) ?? [];
    a.push(g.group_name);
    groupsByUser.set(g.user_id, a);
  }
  const emailList = [...emailMap.values()].filter(Boolean);
  const {
    data: suppressed
  } = emailList.length ? await supabaseAdmin.from("suppressed_emails").select("email").in("email", emailList.map((e) => e.toLowerCase())) : {
    data: []
  };
  const suppressedSet = new Set((suppressed ?? []).map((s) => s.email.toLowerCase()));
  return rows.map((r) => {
    const email = emailMap.get(r.id) ?? null;
    return {
      ...r,
      email,
      email_subscribed: email ? !suppressedSet.has(email.toLowerCase()) : true,
      groups: groupsByUser.get(r.id) ?? []
    };
  });
});
export {
  coachActivateMember_createServerFn_handler,
  coachEndTrial_createServerFn_handler,
  coachExtendTrial_createServerFn_handler,
  coachStartTrial_createServerFn_handler,
  ensureTrialTrainingPlan_createServerFn_handler,
  listTrialUsers_createServerFn_handler,
  startMyTrial_createServerFn_handler
};
