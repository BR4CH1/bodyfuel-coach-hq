import process from "node:process";
import { c as createServerRpc } from "./createServerRpc--OrbljSy.mjs";
import { c as createServerFn } from "./server-g-lQHb1O.mjs";
import { createClient } from "../_libs/supabase__supabase-js.mjs";
import { r as requireSupabaseAuth } from "./auth-middleware-B5YcFrfv.mjs";

import "../_libs/seroval.mjs";
import "../_libs/react.mjs";
import "../_libs/h3-v2.mjs";
import "../_libs/unenv.mjs";


import "../_libs/rou3.mjs";
import "../_libs/srvx.mjs";





import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval-plugins.mjs";

import "../_libs/tanstack__react-router.mjs";
import "../_libs/react-dom.mjs";
import "../_libs/isbot.mjs";
import "../_libs/supabase__postgrest-js.mjs";
import "../_libs/supabase__realtime-js.mjs";
import "../_libs/supabase__phoenix.mjs";
import "../_libs/supabase__storage-js.mjs";
import "../_libs/iceberg-js.mjs";
import "../_libs/supabase__auth-js.mjs";
import "../_libs/tslib.mjs";
import "../_libs/supabase__functions-js.mjs";
const SAFE_ORG_COLUMNS = "id, name, slug, organization_type, logo_url, primary_color, secondary_color";
function serverPublicClient() {
  return createClient(process.env.SUPABASE_URL, process.env.SUPABASE_PUBLISHABLE_KEY, {
    auth: {
      storage: void 0,
      persistSession: false,
      autoRefreshToken: false
    }
  });
}
const getOrganizationBySlug_createServerFn_handler = createServerRpc({
  id: "2166c588be6aedace7d772c32085e28571aa0ec2c111fd0fc69cbf8130c5dcf6",
  name: "getOrganizationBySlug",
  filename: "src/lib/organizations/organizations.functions.ts"
}, (opts) => getOrganizationBySlug.__executeServer(opts));
const getOrganizationBySlug = createServerFn({
  method: "GET"
}).inputValidator((d) => ({
  slug: String(d.slug).toLowerCase().trim()
})).handler(getOrganizationBySlug_createServerFn_handler, async ({
  data
}) => {
  const sb = serverPublicClient();
  const {
    data: row,
    error
  } = await sb.from("organizations").select(SAFE_ORG_COLUMNS).eq("slug", data.slug).eq("status", "active").maybeSingle();
  if (error) return null;
  return row ?? null;
});
const getMyOrganizations_createServerFn_handler = createServerRpc({
  id: "a13130029ee5bfa965f60bceeb61b9a82e3e604c37b7e3a6d2b0e164bd504cba",
  name: "getMyOrganizations",
  filename: "src/lib/organizations/organizations.functions.ts"
}, (opts) => getMyOrganizations.__executeServer(opts));
const getMyOrganizations = createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).handler(getMyOrganizations_createServerFn_handler, async ({
  context
}) => {
  const {
    data,
    error
  } = await context.supabase.from("organization_memberships").select(`organization_id, role, status, onboarding_completed,
         organization:organizations!inner(${SAFE_ORG_COLUMNS})`).eq("user_id", context.userId).eq("status", "active");
  if (error) throw new Error(error.message);
  return data ?? [];
});
const getMyOrgContexts_createServerFn_handler = createServerRpc({
  id: "f18936c08d7352e95c21c64dae20b63b441674f3cffd299779767e55093143c0",
  name: "getMyOrgContexts",
  filename: "src/lib/organizations/organizations.functions.ts"
}, (opts) => getMyOrgContexts.__executeServer(opts));
const getMyOrgContexts = createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).handler(getMyOrgContexts_createServerFn_handler, async ({
  context
}) => {
  const {
    supabase,
    userId
  } = context;
  const [memRes, staffRes] = await Promise.all([supabase.from("organization_memberships").select(`organization_id, role, onboarding_completed,
           organization:organizations!inner(${SAFE_ORG_COLUMNS})`).eq("user_id", userId).eq("status", "active"), supabase.from("staff_assignments").select(`organization_id, role, permissions, team_id,
           organization:organizations!inner(${SAFE_ORG_COLUMNS})`).eq("user_id", userId)]);
  if (memRes.error) throw new Error(memRes.error.message);
  if (staffRes.error) throw new Error(staffRes.error.message);
  const byId = /* @__PURE__ */ new Map();
  for (const m of memRes.data ?? []) {
    const org = m.organization;
    if (!org) continue;
    byId.set(org.id, {
      organization: org,
      athlete: {
        role: m.role,
        onboarding_completed: !!m.onboarding_completed
      },
      staff: null
    });
  }
  for (const s of staffRes.data ?? []) {
    const org = s.organization;
    if (!org) continue;
    const existing = byId.get(org.id) ?? {
      organization: org,
      athlete: null,
      staff: null
    };
    existing.staff = {
      role: s.role,
      permissions: s.permissions ?? [],
      team_id: s.team_id ?? null
    };
    byId.set(org.id, existing);
  }
  return Array.from(byId.values());
});
const getOrganizationContext_createServerFn_handler = createServerRpc({
  id: "9ff1bd8b122131a9a64f5e9716a1a49a414437640dbd0e4659f8691da30b898e",
  name: "getOrganizationContext",
  filename: "src/lib/organizations/organizations.functions.ts"
}, (opts) => getOrganizationContext.__executeServer(opts));
const getOrganizationContext = createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).inputValidator((d) => ({
  slug: String(d.slug).toLowerCase().trim()
})).handler(getOrganizationContext_createServerFn_handler, async ({
  data,
  context
}) => {
  const {
    supabase,
    userId
  } = context;
  const {
    data: org,
    error: orgErr
  } = await supabase.from("organizations").select(SAFE_ORG_COLUMNS).eq("slug", data.slug).eq("status", "active").maybeSingle();
  if (orgErr) throw new Error(orgErr.message);
  if (!org) return null;
  const orgId = org.id;
  const [membershipRes, staffRes, featuresRes, teamsRes, teamMembershipRes, superAdminRes, profileRes] = await Promise.all([supabase.from("organization_memberships").select("organization_id, role, status, onboarding_completed").eq("user_id", userId).eq("organization_id", orgId).maybeSingle(), supabase.from("staff_assignments").select("role, permissions, team_id, function_label, onboarding_completed_at").eq("user_id", userId).eq("organization_id", orgId).maybeSingle(), supabase.from("organization_features").select("feature, enabled").eq("organization_id", orgId), supabase.from("organization_teams").select("id, name, slug, sport, age_group").eq("organization_id", orgId).eq("status", "active"), supabase.from("team_memberships").select("team_id, position, secondary_position, jersey_number, gym_access, available_training_days, limitations, personal_goal, team:organization_teams!inner(organization_id)").eq("user_id", userId), supabase.rpc("has_role", {
    _user_id: userId,
    _role: "coach"
  }), supabase.from("profiles").select("display_name, nickname, birthdate, height_cm").eq("id", userId).maybeSingle()]);
  const teamMembership = (teamMembershipRes.data ?? []).find((t) => t.team?.organization_id === orgId) ?? null;
  return {
    organization: org,
    membership: membershipRes.data ? {
      organization_id: orgId,
      role: membershipRes.data.role,
      status: membershipRes.data.status,
      onboarding_completed: !!membershipRes.data.onboarding_completed,
      organization: org
    } : null,
    staff: staffRes.data ? {
      role: staffRes.data.role,
      permissions: staffRes.data.permissions ?? [],
      team_id: staffRes.data.team_id ?? null,
      function_label: staffRes.data.function_label ?? null,
      onboarding_completed_at: staffRes.data.onboarding_completed_at ?? null
    } : null,
    features: featuresRes.data ?? [],
    teams: teamsRes.data ?? [],
    team_membership: teamMembership ? {
      team_id: teamMembership.team_id,
      position: teamMembership.position ?? null,
      secondary_position: teamMembership.secondary_position ?? null,
      jersey_number: teamMembership.jersey_number ?? null,
      gym_access: teamMembership.gym_access ?? null,
      available_training_days: teamMembership.available_training_days ?? null,
      limitations: teamMembership.limitations ?? null,
      personal_goal: teamMembership.personal_goal ?? null
    } : null,
    is_super_admin: !!superAdminRes.data,
    profile: profileRes.data ? {
      display_name: profileRes.data.display_name ?? null,
      nickname: profileRes.data.nickname ?? null,
      birthdate: profileRes.data.birthdate ?? null,
      height_cm: profileRes.data.height_cm ?? null
    } : null
  };
});
const completeOrganizationOnboarding_createServerFn_handler = createServerRpc({
  id: "1bbfd188ae221da2b12464ec359d094cfef5dfa4f261d5c1b9c5b725f4f62ed4",
  name: "completeOrganizationOnboarding",
  filename: "src/lib/organizations/organizations.functions.ts"
}, (opts) => completeOrganizationOnboarding.__executeServer(opts));
const completeOrganizationOnboarding = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => d).handler(completeOrganizationOnboarding_createServerFn_handler, async ({
  data,
  context
}) => {
  const {
    supabase,
    userId
  } = context;
  if (data.team_id) {
    const {
      error: tmErr
    } = await supabase.from("team_memberships").upsert({
      user_id: userId,
      team_id: data.team_id,
      position: data.position ?? null,
      secondary_position: data.secondary_position ?? null,
      jersey_number: data.jersey_number ?? null,
      status: "active"
    }, {
      onConflict: "user_id,team_id"
    });
    if (tmErr) throw new Error(tmErr.message);
  }
  const {
    error
  } = await supabase.from("organization_memberships").update({
    onboarding_completed: true
  }).eq("user_id", userId).eq("organization_id", data.organization_id);
  if (error) throw new Error(error.message);
  return {
    ok: true
  };
});
const getInvitePreview_createServerFn_handler = createServerRpc({
  id: "51a738fbb0bb5c8ce64a99544548b42554d5e16e844e598349042027f0ec3e64",
  name: "getInvitePreview",
  filename: "src/lib/organizations/organizations.functions.ts"
}, (opts) => getInvitePreview.__executeServer(opts));
const getInvitePreview = createServerFn({
  method: "GET"
}).inputValidator((d) => ({
  token: String(d.token).trim()
})).handler(getInvitePreview_createServerFn_handler, async ({
  data
}) => {
  const {
    supabaseAdmin
  } = await import("./client.server-D5ro3rAQ.mjs");
  const {
    data: invite
  } = await supabaseAdmin.from("organization_invites").select("email, assigned_role, status, expires_at, organization_id, team_id").eq("invite_token", data.token).maybeSingle();
  if (!invite) return {
    ok: false,
    reason: "not_found"
  };
  const expired = !!invite.expires_at && new Date(invite.expires_at) < /* @__PURE__ */ new Date();
  const effectiveStatus = expired ? "expired" : String(invite.status);
  const {
    data: org
  } = await supabaseAdmin.from("organizations").select("name, slug, logo_url").eq("id", invite.organization_id).maybeSingle();
  let teamName = null;
  if (invite.team_id) {
    const {
      data: t
    } = await supabaseAdmin.from("organization_teams").select("name").eq("id", invite.team_id).maybeSingle();
    teamName = t?.name ?? null;
  }
  return {
    ok: true,
    email: invite.email,
    role: invite.assigned_role,
    status: effectiveStatus,
    organization: {
      name: org?.name ?? "",
      slug: org?.slug ?? "",
      logo_url: org?.logo_url ?? null
    },
    team_name: teamName
  };
});
const acceptOrganizationInvite_createServerFn_handler = createServerRpc({
  id: "7733e3a501e1bff770ec67bef2d0faff1dc3fd314bb7a0b39ed60135036bbd60",
  name: "acceptOrganizationInvite",
  filename: "src/lib/organizations/organizations.functions.ts"
}, (opts) => acceptOrganizationInvite.__executeServer(opts));
const acceptOrganizationInvite = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => ({
  token: String(d.token).trim()
})).handler(acceptOrganizationInvite_createServerFn_handler, async ({
  data,
  context
}) => {
  const {
    supabase,
    userId,
    claims
  } = context;
  const {
    supabaseAdmin
  } = await import("./client.server-D5ro3rAQ.mjs");
  const {
    data: invite,
    error: invErr
  } = await supabaseAdmin.from("organization_invites").select("*").eq("invite_token", data.token).maybeSingle();
  if (invErr) throw new Error(invErr.message);
  if (!invite) throw new Error("Einladung nicht gefunden.");
  const callerEmail = String(claims?.email ?? "").trim().toLowerCase();
  const inviteEmail = String(invite.email ?? "").trim().toLowerCase();
  if (inviteEmail && callerEmail && inviteEmail !== callerEmail) {
    throw new Error("Diese Einladung ist für eine andere E-Mail-Adresse ausgestellt. Bitte melde dich mit der eingeladenen Adresse an.");
  }
  if (invite.status !== "pending") throw new Error("Einladung nicht mehr gültig.");
  if (invite.expires_at && new Date(invite.expires_at) < /* @__PURE__ */ new Date()) {
    await supabaseAdmin.from("organization_invites").update({
      status: "expired"
    }).eq("id", invite.id);
    throw new Error("Einladung abgelaufen.");
  }
  const assignedRole = invite.assigned_role;
  const isAthleteInvite = assignedRole === "athlete";
  if (isAthleteInvite) {
    const {
      error: memErr
    } = await supabaseAdmin.from("organization_memberships").upsert({
      user_id: userId,
      organization_id: invite.organization_id,
      role: "athlete",
      status: "active"
    }, {
      onConflict: "user_id,organization_id"
    });
    if (memErr) throw new Error(memErr.message);
    if (invite.team_id) {
      const {
        data: existingTm
      } = await supabaseAdmin.from("team_memberships").select("position, secondary_position, jersey_number").eq("user_id", userId).eq("team_id", invite.team_id).maybeSingle();
      const invAny = invite;
      const tmPayload = {
        user_id: userId,
        team_id: invite.team_id,
        status: "active"
      };
      if (!existingTm?.position && invAny.athlete_primary_position) {
        tmPayload.position = invAny.athlete_primary_position;
      }
      if (!existingTm?.secondary_position && invAny.athlete_secondary_position) {
        tmPayload.secondary_position = invAny.athlete_secondary_position;
      }
      if (existingTm?.jersey_number == null && invAny.athlete_jersey_number != null) {
        tmPayload.jersey_number = invAny.athlete_jersey_number;
      }
      const {
        error: tmErr
      } = await supabaseAdmin.from("team_memberships").upsert(tmPayload, {
        onConflict: "user_id,team_id"
      });
      if (tmErr) throw new Error(tmErr.message);
    }
  } else {
    const {
      error: memErr
    } = await supabaseAdmin.from("organization_memberships").upsert({
      user_id: userId,
      organization_id: invite.organization_id,
      role: "member",
      status: "active"
    }, {
      onConflict: "user_id,organization_id"
    });
    if (memErr) throw new Error(memErr.message);
    const {
      error: staffErr
    } = await supabaseAdmin.from("staff_assignments").upsert({
      user_id: userId,
      organization_id: invite.organization_id,
      team_id: invite.team_id ?? null,
      role: assignedRole,
      permissions: invite.permissions ?? []
    }, {
      onConflict: "user_id,organization_id,team_id"
    });
    if (staffErr) throw new Error(staffErr.message);
  }
  await supabaseAdmin.from("organization_invites").update({
    status: "accepted",
    accepted_by: userId,
    accepted_at: (/* @__PURE__ */ new Date()).toISOString()
  }).eq("id", invite.id);
  const {
    data: org
  } = await supabase.from("organizations").select("slug").eq("id", invite.organization_id).maybeSingle();
  return {
    ok: true,
    slug: org?.slug ?? null
  };
});
const listOrganizationsForStaff_createServerFn_handler = createServerRpc({
  id: "75190fc94042d2f30ca56c8162f0aae3aa559f6a2ac1fe105c3e7892b6253c1b",
  name: "listOrganizationsForStaff",
  filename: "src/lib/organizations/organizations.functions.ts"
}, (opts) => listOrganizationsForStaff.__executeServer(opts));
const listOrganizationsForStaff = createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).handler(listOrganizationsForStaff_createServerFn_handler, async ({
  context
}) => {
  const {
    supabase,
    userId
  } = context;
  const {
    data: isCoach
  } = await supabase.rpc("has_role", {
    _user_id: userId,
    _role: "coach"
  });
  if (isCoach) {
    const {
      data: data2,
      error: error2
    } = await supabase.from("organizations").select(SAFE_ORG_COLUMNS).order("name");
    if (error2) throw new Error(error2.message);
    return data2 ?? [];
  }
  const {
    data,
    error
  } = await supabase.from("staff_assignments").select(`organization:organizations!inner(${SAFE_ORG_COLUMNS})`).eq("user_id", userId);
  if (error) throw new Error(error.message);
  const seen = /* @__PURE__ */ new Set();
  const out = [];
  for (const row of data ?? []) {
    const o = row.organization;
    if (o && !seen.has(o.id)) {
      seen.add(o.id);
      out.push(o);
    }
  }
  return out;
});
async function assertPlatformOwner(supabase, userId) {
  const {
    data,
    error
  } = await supabase.rpc("has_role", {
    _user_id: userId,
    _role: "platform_owner"
  });
  if (error) throw new Error(error.message);
  if (!data) throw new Error("Kein Zugriff — nur für Plattform-Owner.");
}
const getIsPlatformOwner_createServerFn_handler = createServerRpc({
  id: "4a9a5e3d4176fb851fcbd4e1c181d0120f9d0ec044e88c2cc289a8f22eeb9a7c",
  name: "getIsPlatformOwner",
  filename: "src/lib/organizations/organizations.functions.ts"
}, (opts) => getIsPlatformOwner.__executeServer(opts));
const getIsPlatformOwner = createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).handler(getIsPlatformOwner_createServerFn_handler, async ({
  context
}) => {
  const {
    data
  } = await context.supabase.rpc("has_role", {
    _user_id: context.userId,
    _role: "platform_owner"
  });
  return !!data;
});
const listPerformanceTeams_createServerFn_handler = createServerRpc({
  id: "c25b46d937a499ac2da3dfa931e697fd5f9c2048eaf3e79d5b61cf7dfffbe984",
  name: "listPerformanceTeams",
  filename: "src/lib/organizations/organizations.functions.ts"
}, (opts) => listPerformanceTeams.__executeServer(opts));
const listPerformanceTeams = createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).handler(listPerformanceTeams_createServerFn_handler, async ({
  context
}) => {
  await assertPlatformOwner(context.supabase, context.userId);
  const {
    data: orgs,
    error
  } = await context.supabase.from("organizations").select("id, name, slug, organization_type, logo_url, primary_color, secondary_color, short_name, sport, status").order("name");
  if (error) throw new Error(error.message);
  if (!orgs || orgs.length === 0) return [];
  const orgIds = orgs.map((o) => o.id);
  const [teamsRes, athletesRes, staffRes] = await Promise.all([context.supabase.from("organization_teams").select("organization_id").in("organization_id", orgIds), context.supabase.from("organization_memberships").select("organization_id").in("organization_id", orgIds).eq("status", "active").eq("role", "athlete"), context.supabase.from("staff_assignments").select("organization_id").in("organization_id", orgIds)]);
  const count = (rows, orgId) => (rows ?? []).filter((r) => r.organization_id === orgId).length;
  return orgs.map((o) => ({
    id: o.id,
    name: o.name,
    slug: o.slug,
    organization_type: o.organization_type,
    logo_url: o.logo_url,
    primary_color: o.primary_color,
    secondary_color: o.secondary_color,
    short_name: o.short_name ?? null,
    sport: o.sport ?? null,
    status: o.status,
    team_count: count(teamsRes.data, o.id),
    athlete_count: count(athletesRes.data, o.id),
    staff_count: count(staffRes.data, o.id)
  }));
});
const SLUG_RESERVED = /* @__PURE__ */ new Set(["auth", "login", "logout", "dashboard", "nutrition", "training", "messages", "community", "profile", "coach", "admin", "tracker", "smart", "ranking", "achievements", "checkout", "impressum", "datenschutz", "trust", "welcome", "api", "app", "mcp", "lovable", "onboarding", "measurements", "progress", "strength-check", "check-in", "training-import", "daily-checklist", "unsubscribe", "guardian-consent", "org", "organizations", "teams", "staff", "invite", "invites", "settings", "account", "notifications", "support", "help", "about", "pricing", "contact", "signup", "signin", "register"]);
const createPerformanceTeamOrganization_createServerFn_handler = createServerRpc({
  id: "8f5208b37236d7e68c9bad2a77aaaa37d039a2ecd0da16e3ce8d49d208cb393c",
  name: "createPerformanceTeamOrganization",
  filename: "src/lib/organizations/organizations.functions.ts"
}, (opts) => createPerformanceTeamOrganization.__executeServer(opts));
const createPerformanceTeamOrganization = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => {
  const name = String(d.name ?? "").trim();
  const slug = String(d.slug ?? "").toLowerCase().trim();
  if (name.length < 2) throw new Error("Teamname zu kurz.");
  if (!/^[a-z0-9][a-z0-9-]{1,49}$/.test(slug)) {
    throw new Error("Ungültiger URL-Slug (a-z, 0-9, -, 2–50 Zeichen).");
  }
  if (SLUG_RESERVED.has(slug)) throw new Error(`Slug "${slug}" ist reserviert.`);
  const features = Array.isArray(d.enabled_features) ? Array.from(new Set(d.enabled_features.map((f) => String(f).trim()).filter(Boolean))) : null;
  return {
    name,
    slug,
    short_name: d.short_name?.trim() || null,
    sport: d.sport?.trim() || null,
    claim: d.claim?.trim() || null,
    logo_url: d.logo_url?.trim() || null,
    alt_logo_url: d.alt_logo_url?.trim() || null,
    primary_color: d.primary_color?.trim() || null,
    secondary_color: d.secondary_color?.trim() || null,
    accent_color: d.accent_color?.trim() || null,
    background_color: d.background_color?.trim() || null,
    text_color: d.text_color?.trim() || null,
    organization_type: d.organization_type?.trim() || "sports_club",
    enabled_features: features,
    license_plan: d.license_plan?.trim() || null,
    license_status: d.license_status?.trim() || null,
    max_customers: typeof d.max_customers === "number" && Number.isFinite(d.max_customers) ? Math.max(0, Math.floor(d.max_customers)) : null,
    max_coaches: typeof d.max_coaches === "number" && Number.isFinite(d.max_coaches) ? Math.max(0, Math.floor(d.max_coaches)) : null
  };
}).handler(createPerformanceTeamOrganization_createServerFn_handler, async ({
  data,
  context
}) => {
  await assertPlatformOwner(context.supabase, context.userId);
  const {
    data: existing
  } = await context.supabase.from("organizations").select("id").eq("slug", data.slug).maybeSingle();
  if (existing) throw new Error(`Slug "${data.slug}" ist bereits vergeben.`);
  const insertRow = {
    name: data.name,
    slug: data.slug,
    short_name: data.short_name,
    sport: data.sport,
    claim: data.claim,
    logo_url: data.logo_url,
    alt_logo_url: data.alt_logo_url,
    primary_color: data.primary_color,
    secondary_color: data.secondary_color,
    accent_color: data.accent_color,
    background_color: data.background_color,
    text_color: data.text_color,
    organization_type: data.organization_type,
    status: "active"
  };
  if (data.license_plan) insertRow.license_plan = data.license_plan;
  if (data.license_status) {
    insertRow.license_status = data.license_status;
    if (data.license_status === "trial" || data.license_status === "active") {
      insertRow.license_started_at = (/* @__PURE__ */ new Date()).toISOString();
    }
  }
  if (data.max_customers !== null) insertRow.max_customers = data.max_customers;
  if (data.max_coaches !== null) insertRow.max_coaches = data.max_coaches;
  const {
    data: inserted,
    error: insErr
  } = await context.supabase.from("organizations").insert(insertRow).select("id, slug").single();
  if (insErr) throw new Error(insErr.message);
  const orgId = inserted.id;
  const {
    error: staffErr
  } = await context.supabase.from("staff_assignments").insert({
    user_id: context.userId,
    organization_id: orgId,
    role: "organization_admin",
    permissions: [],
    team_id: null
  });
  if (staffErr) throw new Error(staffErr.message);
  if (data.enabled_features && data.enabled_features.length > 0) {
    const rows = data.enabled_features.map((feature) => ({
      organization_id: orgId,
      feature,
      enabled: true
    }));
    const {
      error: featErr
    } = await context.supabase.from("organization_features").upsert(rows, {
      onConflict: "organization_id,feature"
    });
    if (featErr) throw new Error(featErr.message);
  }
  return {
    id: orgId,
    slug: inserted.slug
  };
});
const deletePerformanceTeamOrganization_createServerFn_handler = createServerRpc({
  id: "f00ad89b5c6b8584cd9b93e454dd2d32e5c4055215193d79902ca4533b4a32b1",
  name: "deletePerformanceTeamOrganization",
  filename: "src/lib/organizations/organizations.functions.ts"
}, (opts) => deletePerformanceTeamOrganization.__executeServer(opts));
const deletePerformanceTeamOrganization = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => {
  const id = String(d.organization_id ?? "").trim();
  const name = String(d.confirm_name ?? "").trim();
  if (!/^[0-9a-f-]{36}$/i.test(id)) throw new Error("Ungültige Organisations-ID.");
  if (!name) throw new Error("Bitte den Organisationsnamen zur Bestätigung eingeben.");
  return {
    organization_id: id,
    confirm_name: name
  };
}).handler(deletePerformanceTeamOrganization_createServerFn_handler, async ({
  data,
  context
}) => {
  await assertPlatformOwner(context.supabase, context.userId);
  const {
    data: org,
    error: readErr
  } = await context.supabase.from("organizations").select("id, name, slug").eq("id", data.organization_id).maybeSingle();
  if (readErr) throw new Error(readErr.message);
  if (!org) throw new Error("Organisation nicht gefunden.");
  if (String(org.name).trim() !== data.confirm_name.trim()) {
    throw new Error("Der eingegebene Name stimmt nicht mit dem Organisationsnamen überein.");
  }
  const {
    supabaseAdmin
  } = await import("./client.server-D5ro3rAQ.mjs");
  const {
    error: delErr
  } = await supabaseAdmin.from("organizations").delete().eq("id", data.organization_id);
  if (delErr) throw new Error(delErr.message);
  return {
    ok: true,
    id: data.organization_id,
    name: org.name
  };
});
function slugifyTeamName(input) {
  return String(input ?? "").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/ß/g, "ss").replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 50);
}
const createOrgTeam_createServerFn_handler = createServerRpc({
  id: "a33aa90a36c100b1d8692189122891155542092c66619f064399459505c8b54d",
  name: "createOrgTeam",
  filename: "src/lib/organizations/organizations.functions.ts"
}, (opts) => createOrgTeam.__executeServer(opts));
const createOrgTeam = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => {
  const organization_id = String(d.organization_id ?? "").trim();
  const name = String(d.name ?? "").trim();
  if (!/^[0-9a-f-]{36}$/i.test(organization_id)) throw new Error("Ungültige Organisations-ID.");
  if (name.length < 2) throw new Error("Teamname zu kurz.");
  if (name.length > 80) throw new Error("Teamname zu lang.");
  return {
    organization_id,
    name,
    sport: d.sport?.trim() || null,
    age_group: d.age_group?.trim() || null
  };
}).handler(createOrgTeam_createServerFn_handler, async ({
  data,
  context
}) => {
  const base = slugifyTeamName(data.name) || "team";
  const {
    data: existing
  } = await context.supabase.from("organization_teams").select("slug").eq("organization_id", data.organization_id);
  const taken = new Set((existing ?? []).map((r) => String(r.slug)));
  let slug = base;
  let i = 2;
  while (taken.has(slug)) {
    slug = `${base}-${i++}`;
    if (i > 999) throw new Error("Konnte keinen freien Team-Slug erzeugen.");
  }
  let sport = data.sport;
  if (!sport) {
    const {
      data: org
    } = await context.supabase.from("organizations").select("sport").eq("id", data.organization_id).maybeSingle();
    sport = org?.sport ?? null;
  }
  const {
    data: inserted,
    error
  } = await context.supabase.from("organization_teams").insert({
    organization_id: data.organization_id,
    name: data.name,
    slug,
    sport,
    age_group: data.age_group
  }).select("id, name, slug, sport, age_group").single();
  if (error) throw new Error(error.message);
  return inserted;
});
const listOrganizationFeatures_createServerFn_handler = createServerRpc({
  id: "e2ef830314e8b302181fd04c3b645cb2a2b05f291a5ac9920fc9dddb4c67859a",
  name: "listOrganizationFeatures",
  filename: "src/lib/organizations/organizations.functions.ts"
}, (opts) => listOrganizationFeatures.__executeServer(opts));
const listOrganizationFeatures = createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).inputValidator((data) => data).handler(listOrganizationFeatures_createServerFn_handler, async ({
  data,
  context
}) => {
  const {
    data: rows,
    error
  } = await context.supabase.from("organization_features").select("feature, enabled").eq("organization_id", data.orgId);
  if (error) throw new Error(error.message);
  return rows ?? [];
});
const setOrganizationFeature_createServerFn_handler = createServerRpc({
  id: "d1cabb8d7e494fbbbb565191f19237c7d40537c04f3737f2ee98226b3c14f311",
  name: "setOrganizationFeature",
  filename: "src/lib/organizations/organizations.functions.ts"
}, (opts) => setOrganizationFeature.__executeServer(opts));
const setOrganizationFeature = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((data) => data).handler(setOrganizationFeature_createServerFn_handler, async ({
  data,
  context
}) => {
  if (!data.features?.length) return {
    ok: true
  };
  const rows = data.features.map((f) => ({
    organization_id: data.orgId,
    feature: f,
    enabled: data.enabled
  }));
  const {
    error
  } = await context.supabase.from("organization_features").upsert(rows, {
    onConflict: "organization_id,feature"
  });
  if (error) throw new Error(error.message);
  return {
    ok: true
  };
});
async function assertCanManageOrg(supabase, userId, orgId) {
  const {
    data: role
  } = await supabase.from("user_roles").select("role").eq("user_id", userId).eq("role", "platform_owner").maybeSingle();
  if (role) return;
  const {
    data: staff
  } = await supabase.from("staff_assignments").select("role").eq("user_id", userId).eq("organization_id", orgId).maybeSingle();
  const r = staff?.role;
  if (r !== "organization_admin") {
    throw new Error("Keine Berechtigung.");
  }
}
const updateOrganizationTerminology_createServerFn_handler = createServerRpc({
  id: "07f4e28b0150665e2d8c3b6d474c1c847a8ad75ff3f32327dfa9ef7f521c99ce",
  name: "updateOrganizationTerminology",
  filename: "src/lib/organizations/organizations.functions.ts"
}, (opts) => updateOrganizationTerminology.__executeServer(opts));
const updateOrganizationTerminology = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => d).handler(updateOrganizationTerminology_createServerFn_handler, async ({
  data,
  context
}) => {
  await assertCanManageOrg(context.supabase, context.userId, data.orgId);
  const {
    error
  } = await context.supabase.from("organizations").update({
    terminology: data.terminology
  }).eq("id", data.orgId);
  if (error) throw new Error(error.message);
  return {
    ok: true
  };
});
const updateOrganizationBranding_createServerFn_handler = createServerRpc({
  id: "d2bc634df91b9ca6a18ebae5375ecd78a5985ae927201a3a32592a00bfcea46a",
  name: "updateOrganizationBranding",
  filename: "src/lib/organizations/organizations.functions.ts"
}, (opts) => updateOrganizationBranding.__executeServer(opts));
const updateOrganizationBranding = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => d).handler(updateOrganizationBranding_createServerFn_handler, async ({
  data,
  context
}) => {
  await assertCanManageOrg(context.supabase, context.userId, data.orgId);
  const patch = {};
  for (const k of ["primary_color", "secondary_color", "accent_color", "background_color", "text_color", "logo_url", "alt_logo_url", "claim", "short_name", "branding_mode", "branding_extra"]) {
    if (data[k] !== void 0) patch[k] = data[k];
  }
  if (!Object.keys(patch).length) return {
    ok: true
  };
  const {
    error
  } = await context.supabase.from("organizations").update(patch).eq("id", data.orgId);
  if (error) throw new Error(error.message);
  return {
    ok: true
  };
});
const listOrgCoachAssignments_createServerFn_handler = createServerRpc({
  id: "8b5fc832647c7a99ad6afe763ddf7a62fa05318c1a725f3e7ae0b59eaf564444",
  name: "listOrgCoachAssignments",
  filename: "src/lib/organizations/organizations.functions.ts"
}, (opts) => listOrgCoachAssignments.__executeServer(opts));
const listOrgCoachAssignments = createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).inputValidator((d) => d).handler(listOrgCoachAssignments_createServerFn_handler, async ({
  data,
  context
}) => {
  const {
    data: staff
  } = await context.supabase.from("staff_assignments").select("role").eq("user_id", context.userId).eq("organization_id", data.orgId).maybeSingle();
  const {
    data: plat
  } = await context.supabase.from("user_roles").select("role").eq("user_id", context.userId).eq("role", "platform_owner").maybeSingle();
  if (!staff && !plat) throw new Error("Keine Berechtigung.");
  const {
    data: rows,
    error
  } = await context.supabase.from("organization_coach_assignments").select("id, organization_id, coach_user_id, customer_user_id, role, created_at").eq("organization_id", data.orgId).order("created_at", {
    ascending: true
  });
  if (error) throw new Error(error.message);
  const ids = /* @__PURE__ */ new Set();
  for (const r of rows ?? []) {
    ids.add(r.coach_user_id);
    ids.add(r.customer_user_id);
  }
  let nameMap = /* @__PURE__ */ new Map();
  if (ids.size) {
    const {
      data: profs
    } = await context.supabase.from("profiles").select("id, display_name").in("id", Array.from(ids));
    for (const p of profs ?? []) {
      nameMap.set(p.id, p.display_name ?? null);
    }
  }
  return (rows ?? []).map((r) => ({
    ...r,
    coach_name: nameMap.get(r.coach_user_id) ?? null,
    customer_name: nameMap.get(r.customer_user_id) ?? null
  }));
});
const upsertOrgCoachAssignment_createServerFn_handler = createServerRpc({
  id: "3f2db237e6154b9d9d03b08a66de3ea5fdfe0fb544d3d54e309b6657bb9e06a7",
  name: "upsertOrgCoachAssignment",
  filename: "src/lib/organizations/organizations.functions.ts"
}, (opts) => upsertOrgCoachAssignment.__executeServer(opts));
const upsertOrgCoachAssignment = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => d).handler(upsertOrgCoachAssignment_createServerFn_handler, async ({
  data,
  context
}) => {
  await assertCanManageOrg(context.supabase, context.userId, data.orgId);
  const {
    error
  } = await context.supabase.from("organization_coach_assignments").upsert({
    organization_id: data.orgId,
    coach_user_id: data.coachUserId,
    customer_user_id: data.customerUserId,
    role: data.role ?? "primary_coach"
  }, {
    onConflict: "organization_id,coach_user_id,customer_user_id"
  });
  if (error) throw new Error(error.message);
  return {
    ok: true
  };
});
const removeOrgCoachAssignment_createServerFn_handler = createServerRpc({
  id: "b82e0a7f0216e387b664431837dd44c37566148725b5ccf2bb600c94441128cb",
  name: "removeOrgCoachAssignment",
  filename: "src/lib/organizations/organizations.functions.ts"
}, (opts) => removeOrgCoachAssignment.__executeServer(opts));
const removeOrgCoachAssignment = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => d).handler(removeOrgCoachAssignment_createServerFn_handler, async ({
  data,
  context
}) => {
  await assertCanManageOrg(context.supabase, context.userId, data.orgId);
  const {
    error
  } = await context.supabase.from("organization_coach_assignments").delete().eq("id", data.assignmentId).eq("organization_id", data.orgId);
  if (error) throw new Error(error.message);
  return {
    ok: true
  };
});
const listOrgCoachesAndCustomers_createServerFn_handler = createServerRpc({
  id: "266124148440bbddcdace6122d346feeec3cbf301a598aca5dbcbb4182305b2b",
  name: "listOrgCoachesAndCustomers",
  filename: "src/lib/organizations/organizations.functions.ts"
}, (opts) => listOrgCoachesAndCustomers.__executeServer(opts));
const listOrgCoachesAndCustomers = createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).inputValidator((d) => d).handler(listOrgCoachesAndCustomers_createServerFn_handler, async ({
  data,
  context
}) => {
  const {
    data: staff
  } = await context.supabase.from("staff_assignments").select("user_id, role").eq("organization_id", data.orgId).in("role", ["organization_admin", "coach"]);
  const {
    data: mems
  } = await context.supabase.from("organization_memberships").select("user_id, role, status").eq("organization_id", data.orgId);
  const coachIds = new Set((staff ?? []).map((s) => s.user_id));
  const memberIds = new Set((mems ?? []).filter((m) => !coachIds.has(m.user_id)).map((m) => m.user_id));
  const allIds = /* @__PURE__ */ new Set([...coachIds, ...memberIds]);
  let profiles = [];
  if (allIds.size) {
    const {
      data: profs
    } = await context.supabase.from("profiles").select("id, display_name, email").in("id", Array.from(allIds));
    profiles = profs ?? [];
  }
  const byId = new Map(profiles.map((p) => [p.id, p]));
  const coaches = Array.from(coachIds).map((id) => ({
    user_id: id,
    display_name: byId.get(id)?.display_name ?? null,
    email: byId.get(id)?.email ?? null,
    role: (staff ?? []).find((s) => s.user_id === id)?.role ?? "coach"
  }));
  const customers = Array.from(memberIds).map((id) => ({
    user_id: id,
    display_name: byId.get(id)?.display_name ?? null,
    email: byId.get(id)?.email ?? null
  }));
  return {
    coaches,
    customers
  };
});
export {
  acceptOrganizationInvite_createServerFn_handler,
  completeOrganizationOnboarding_createServerFn_handler,
  createOrgTeam_createServerFn_handler,
  createPerformanceTeamOrganization_createServerFn_handler,
  deletePerformanceTeamOrganization_createServerFn_handler,
  getInvitePreview_createServerFn_handler,
  getIsPlatformOwner_createServerFn_handler,
  getMyOrgContexts_createServerFn_handler,
  getMyOrganizations_createServerFn_handler,
  getOrganizationBySlug_createServerFn_handler,
  getOrganizationContext_createServerFn_handler,
  listOrgCoachAssignments_createServerFn_handler,
  listOrgCoachesAndCustomers_createServerFn_handler,
  listOrganizationFeatures_createServerFn_handler,
  listOrganizationsForStaff_createServerFn_handler,
  listPerformanceTeams_createServerFn_handler,
  removeOrgCoachAssignment_createServerFn_handler,
  setOrganizationFeature_createServerFn_handler,
  updateOrganizationBranding_createServerFn_handler,
  updateOrganizationTerminology_createServerFn_handler,
  upsertOrgCoachAssignment_createServerFn_handler
};
