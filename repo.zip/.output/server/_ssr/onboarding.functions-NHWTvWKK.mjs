import { c as createServerRpc } from "./createServerRpc--OrbljSy.mjs";
import { c as createServerFn } from "./server-g-lQHb1O.mjs";
import { r as requireSupabaseAuth } from "./auth-middleware-B5YcFrfv.mjs";

import "../_libs/seroval.mjs";
import "../_libs/react.mjs";

import "../_libs/h3-v2.mjs";
import "../_libs/unenv.mjs";


import "../_libs/rou3.mjs";
import "../_libs/srvx.mjs";





import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval-plugins.mjs";

import "../_libs/tanstack__react-router.mjs";
import "../_libs/react-dom.mjs";
import "../_libs/isbot.mjs";
import "../_libs/supabase__supabase-js.mjs";
import "../_libs/supabase__postgrest-js.mjs";
import "../_libs/supabase__realtime-js.mjs";
import "../_libs/supabase__phoenix.mjs";
import "../_libs/supabase__storage-js.mjs";
import "../_libs/iceberg-js.mjs";
import "../_libs/supabase__auth-js.mjs";
import "../_libs/tslib.mjs";
import "../_libs/supabase__functions-js.mjs";
const ENGINE_FIELDS = ["birthdate", "height_cm", "weight_kg", "sex_for_energy_calculation", "baseline_daily_activity", "performance_goal"];
const NUTRITION_FIELDS = ["diet_style", "meal_prep_style", "allergies", "intolerances"];
const getPerformanceOnboardingCompletion_createServerFn_handler = createServerRpc({
  id: "d2e1213c3544f7340dfabd43af1807782b8200dca73791e700f656b3e8f54734",
  name: "getPerformanceOnboardingCompletion",
  filename: "src/lib/performance-nutrition/onboarding.functions.ts"
}, (opts) => getPerformanceOnboardingCompletion.__executeServer(opts));
const getPerformanceOnboardingCompletion = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => d).handler(getPerformanceOnboardingCompletion_createServerFn_handler, async ({
  data,
  context
}) => {
  const {
    supabase,
    userId
  } = context;
  const [{
    data: profileRow
  }, {
    data: bmRow
  }, {
    data: pnpRow
  }, {
    data: snpRow
  }] = await Promise.all([supabase.from("profiles").select("birthdate, height_cm, gender").eq("id", userId).maybeSingle(), supabase.from("body_measurements").select("weight_kg").eq("user_id", userId).not("weight_kg", "is", null).order("measured_at", {
    ascending: false
  }).limit(1).maybeSingle(), supabase.from("performance_nutrition_profiles").select("sex_for_energy_calculation, baseline_daily_activity, performance_goal").eq("user_id", userId).eq("organization_id", data.organizationId).maybeSingle(), supabase.from("smart_nutrition_profile").select("diet_style, meal_prep_style, allergies, intolerances").eq("user_id", userId).maybeSingle()]);
  const missingPerformanceFields = [];
  if (!profileRow?.birthdate) missingPerformanceFields.push("birthdate");
  if (!profileRow?.height_cm) missingPerformanceFields.push("height_cm");
  if (!bmRow?.weight_kg) missingPerformanceFields.push("weight_kg");
  if (!pnpRow?.sex_for_energy_calculation) missingPerformanceFields.push("sex_for_energy_calculation");
  if (!pnpRow?.baseline_daily_activity) missingPerformanceFields.push("baseline_daily_activity");
  if (!pnpRow?.performance_goal) missingPerformanceFields.push("performance_goal");
  const missingNutritionFields = [];
  if (!snpRow?.diet_style) missingNutritionFields.push("diet_style");
  if (!snpRow?.meal_prep_style) missingNutritionFields.push("meal_prep_style");
  if (snpRow?.allergies == null) missingNutritionFields.push("allergies");
  if (snpRow?.intolerances == null) missingNutritionFields.push("intolerances");
  const engineReady = missingPerformanceFields.length === 0;
  const mealPlanningReady = missingNutritionFields.length === 0;
  const totalRequired = ENGINE_FIELDS.length + NUTRITION_FIELDS.length;
  const missingCount = missingPerformanceFields.length + missingNutritionFields.length;
  const completionPercent = Math.round((totalRequired - missingCount) / totalRequired * 100);
  const status = engineReady && mealPlanningReady ? "COMPLETE" : missingCount === totalRequired ? "MISSING" : "PARTIAL";
  return {
    status,
    engineReady,
    mealPlanningReady,
    missingPerformanceFields,
    missingNutritionFields,
    completionPercent
  };
});
const savePerformanceNutritionPreferences_createServerFn_handler = createServerRpc({
  id: "0fd233469afb4c9e789b2f46298e54058c836b10b2984f60726f4840d088ea80",
  name: "savePerformanceNutritionPreferences",
  filename: "src/lib/performance-nutrition/onboarding.functions.ts"
}, (opts) => savePerformanceNutritionPreferences.__executeServer(opts));
const savePerformanceNutritionPreferences = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => d).handler(savePerformanceNutritionPreferences_createServerFn_handler, async ({
  data,
  context
}) => {
  const {
    supabase,
    userId
  } = context;
  const patch = {
    user_id: userId
  };
  const KEYS = ["favorite_foods", "extra_favorites", "nogo_foods", "extra_nogos", "allergies", "extra_allergies", "intolerances", "diet_style", "diet_notes", "eating_style", "meal_prep_days", "meal_prep_style"];
  for (const k of KEYS) {
    if (data[k] !== void 0) {
      patch[k] = data[k];
    }
  }
  const {
    error
  } = await supabase.from("smart_nutrition_profile").upsert(patch, {
    onConflict: "user_id"
  });
  if (error) throw new Error(error.message);
  const complete = await (async () => {
    const {
      data: snpRow
    } = await supabase.from("smart_nutrition_profile").select("diet_style, meal_prep_style, allergies, intolerances").eq("user_id", userId).maybeSingle();
    return !!snpRow?.diet_style && !!snpRow?.meal_prep_style && snpRow.allergies != null && snpRow.intolerances != null;
  })();
  let jobId = null;
  if (complete) {
    const today = /* @__PURE__ */ new Date();
    const day = today.getUTCDay();
    const monOffset = (day + 6) % 7;
    today.setUTCDate(today.getUTCDate() - monOffset);
    const weekStart = today.toISOString().slice(0, 10);
    const {
      data: jobRow
    } = await supabase.from("performance_plan_jobs").insert({
      organization_id: data.organizationId,
      team_id: null,
      athlete_user_id: userId,
      week_start: weekStart,
      trigger: "PERFORMANCE_PROFILE_COMPLETED",
      status: "pending",
      created_by: userId
    }).select("id").maybeSingle();
    jobId = jobRow?.id ?? null;
  }
  return {
    ok: true,
    jobId,
    mealPlanningReady: complete
  };
});
export {
  getPerformanceOnboardingCompletion_createServerFn_handler,
  savePerformanceNutritionPreferences_createServerFn_handler
};
