import { c as createServerRpc } from "./createServerRpc--OrbljSy.mjs";
import { c as createServerFn } from "./server-g-lQHb1O.mjs";
import { r as requireSupabaseAuth } from "./auth-middleware-B5YcFrfv.mjs";
import { c as createStripeClient, g as getStripeErrorMessage } from "./stripe.server-mcZ3T1eX.mjs";

import "../_libs/seroval.mjs";
import "../_libs/react.mjs";
import "../_libs/stripe.mjs";

import "../_libs/h3-v2.mjs";
import "../_libs/unenv.mjs";


import "../_libs/rou3.mjs";
import "../_libs/srvx.mjs";





import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval-plugins.mjs";

import "../_libs/tanstack__react-router.mjs";
import "../_libs/react-dom.mjs";
import "../_libs/isbot.mjs";
import "../_libs/supabase__supabase-js.mjs";
import "../_libs/supabase__postgrest-js.mjs";
import "../_libs/supabase__realtime-js.mjs";
import "../_libs/supabase__phoenix.mjs";
import "../_libs/supabase__storage-js.mjs";
import "../_libs/iceberg-js.mjs";
import "../_libs/supabase__auth-js.mjs";
import "../_libs/tslib.mjs";
import "../_libs/supabase__functions-js.mjs";
async function resolveOrCreateCustomer(stripe, options) {
  if (options.userId && !/^[a-zA-Z0-9_-]+$/.test(options.userId)) {
    throw new Error("Invalid userId");
  }
  if (options.userId) {
    const found = await stripe.customers.search({
      query: `metadata['userId']:'${options.userId}'`,
      limit: 1
    });
    if (found.data.length) return found.data[0].id;
  }
  if (options.email) {
    const existing = await stripe.customers.list({
      email: options.email,
      limit: 1
    });
    if (existing.data.length) {
      const customer = existing.data[0];
      if (options.userId && customer.metadata?.userId !== options.userId) {
        await stripe.customers.update(customer.id, {
          metadata: {
            ...customer.metadata,
            userId: options.userId
          }
        });
      }
      return customer.id;
    }
  }
  const created = await stripe.customers.create({
    ...options.email && {
      email: options.email
    },
    ...options.userId && {
      metadata: {
        userId: options.userId
      }
    }
  });
  return created.id;
}
const createSmartCheckoutSession_createServerFn_handler = createServerRpc({
  id: "214f9e477cd725d8a741b36703898350fab835e54496365432d310016176a4e4",
  name: "createSmartCheckoutSession",
  filename: "src/lib/payments.functions.ts"
}, (opts) => createSmartCheckoutSession.__executeServer(opts));
const createSmartCheckoutSession = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((data) => {
  if (!/^[a-zA-Z0-9_-]+$/.test(data.priceId)) throw new Error("Invalid priceId");
  if (data.promoCode && !/^[A-Za-z0-9_-]{2,64}$/.test(data.promoCode)) throw new Error("Invalid promoCode");
  return data;
}).handler(createSmartCheckoutSession_createServerFn_handler, async ({
  data,
  context
}) => {
  try {
    const {
      supabase,
      userId
    } = context;
    const {
      data: prof
    } = await supabase.from("profiles").select("is_minor, account_status, guardian_consent_at").eq("id", userId).maybeSingle();
    if (prof?.is_minor && !prof.guardian_consent_at) {
      return {
        error: "BodyFuel kann von Minderjährigen nur mit Zustimmung eines Erziehungsberechtigten genutzt werden. Bitte lass deine Eltern den Bestätigungslink per E-Mail bestätigen — danach kannst du den Kauf abschließen."
      };
    }
    if (prof?.account_status === "pending_guardian_consent") {
      return {
        error: "Dein Account wartet auf die Bestätigung deiner Eltern. Sobald sie den Link aus der E-Mail bestätigt haben, kannst du den Kauf abschließen."
      };
    }
    if (prof?.account_status === "blocked") {
      return {
        error: "Dein Account ist aktuell gesperrt."
      };
    }
    const {
      data: {
        user
      }
    } = await supabase.auth.getUser();
    const stripe = createStripeClient(data.environment);
    const prices = await stripe.prices.list({
      lookup_keys: [data.priceId]
    });
    if (!prices.data.length) throw new Error("Preis nicht gefunden");
    const stripePrice = prices.data[0];
    const isRecurring = stripePrice.type === "recurring";
    const customerId = await resolveOrCreateCustomer(stripe, {
      email: user?.email ?? void 0,
      userId
    });
    let discounts;
    if (data.promoCode) {
      const {
        supabaseAdmin
      } = await import("./client.server-D5ro3rAQ.mjs");
      const {
        data: partner
      } = await supabaseAdmin.from("affiliate_partners").select("id, slug, discount_pct, commission_pct, is_active, discount_code").ilike("discount_code", data.promoCode).eq("is_active", true).maybeSingle();
      if (!partner) {
        return {
          error: `Rabattcode „${data.promoCode}" ist ungültig oder abgelaufen.`
        };
      }
      const pct = Number(partner.discount_pct ?? partner.commission_pct ?? 0);
      if (pct <= 0) {
        return {
          error: "Rabattcode ist inaktiv."
        };
      }
      const couponId = `aff_${partner.id}_${Math.round(pct * 100)}`;
      try {
        await stripe.coupons.retrieve(couponId);
      } catch {
        try {
          await stripe.coupons.create({
            id: couponId,
            percent_off: pct,
            duration: "once",
            name: `Partner ${partner.slug} · ${pct}% Rabatt (1. Monat)`
          });
        } catch (e) {
          console.error("[checkout] coupon create failed", e);
          return {
            error: "Rabattcode konnte nicht angewendet werden."
          };
        }
      }
      discounts = [{
        coupon: couponId
      }];
      await supabaseAdmin.rpc("attach_referral_by_code", {
        _user_id: userId,
        _code: data.promoCode
      });
    }
    const session = await stripe.checkout.sessions.create({
      line_items: [{
        price: stripePrice.id,
        quantity: 1
      }],
      mode: isRecurring ? "subscription" : "payment",
      ui_mode: "embedded_page",
      return_url: data.returnUrl,
      customer: customerId,
      metadata: {
        userId,
        ...data.promoCode ? {
          promoCode: data.promoCode
        } : {}
      },
      ...isRecurring && {
        subscription_data: {
          metadata: {
            userId
          }
        }
      },
      ...discounts ? {
        discounts
      } : {}
    });
    return {
      clientSecret: session.client_secret ?? ""
    };
  } catch (error) {
    return {
      error: getStripeErrorMessage(error)
    };
  }
});
const createPortalSession_createServerFn_handler = createServerRpc({
  id: "71c0e3dc0dd52a502c1e4ab660ba8964d3d58e856aa89eb593678cbe7b062d53",
  name: "createPortalSession",
  filename: "src/lib/payments.functions.ts"
}, (opts) => createPortalSession.__executeServer(opts));
const createPortalSession = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((data) => data).handler(createPortalSession_createServerFn_handler, async ({
  data,
  context
}) => {
  try {
    const {
      supabase,
      userId
    } = context;
    const {
      data: sub
    } = await supabase.from("subscriptions").select("stripe_customer_id").eq("user_id", userId).eq("environment", data.environment).order("created_at", {
      ascending: false
    }).limit(1).maybeSingle();
    if (!sub?.stripe_customer_id) throw new Error("Kein Abo gefunden");
    const stripe = createStripeClient(data.environment);
    const portal = await stripe.billingPortal.sessions.create({
      customer: sub.stripe_customer_id,
      ...data.returnUrl && {
        return_url: data.returnUrl
      }
    });
    return {
      url: portal.url
    };
  } catch (error) {
    return {
      error: getStripeErrorMessage(error)
    };
  }
});
const getMySmartSubscription_createServerFn_handler = createServerRpc({
  id: "f35b35b156734cdf9f32ba6a763b4b4139a84e6c6f1ace76d01acaa7c76c8dec",
  name: "getMySmartSubscription",
  filename: "src/lib/payments.functions.ts"
}, (opts) => getMySmartSubscription.__executeServer(opts));
const getMySmartSubscription = createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).handler(getMySmartSubscription_createServerFn_handler, async ({
  context
}) => {
  const {
    supabase,
    userId
  } = context;
  const {
    data
  } = await supabase.from("subscriptions").select("*").eq("user_id", userId).order("created_at", {
    ascending: false
  }).limit(1).maybeSingle();
  return data;
});
export {
  createPortalSession_createServerFn_handler,
  createSmartCheckoutSession_createServerFn_handler,
  getMySmartSubscription_createServerFn_handler
};
