import { j as jsxRuntimeExports } from "../_libs/react.mjs";
const url = "https://bodyfuel-coaching.com/__l5e/assets-v1/2b2c1b6f-5209-420f-bc59-e3685023531c/player-card-template.png";
const cardTemplate = {
  url
};
const DEFAULT_LAYOUT = {
  ovr: { x: 175, y: 255, fontSize: 150 },
  pos: { x: 175, y: 440, fontSize: 96 },
  jersey: { x: 175, y: 580, fontSize: 56 },
  age: { x: 255, y: 775, fontSize: 32 },
  height: { x: 255, y: 850, fontSize: 32 },
  weight: { x: 255, y: 925, fontSize: 32 },
  spd: { x: 160, y: 1275, fontSize: 72 },
  acc: { x: 305, y: 1275, fontSize: 72 },
  agi: { x: 450, y: 1275, fontSize: 72 },
  pow: { x: 595, y: 1275, fontSize: 72 },
  str: { x: 740, y: 1275, fontSize: 72 },
  end: { x: 885, y: 1275, fontSize: 72 },
  updateDate: { x: 490, y: 1420, fontSize: 26 },
  strongest: { x: 820, y: 1420, fontSize: 26 },
  photo: { x: 236, y: 300, w: 550, h: 700, url: null }
};
const KEY = "bfr:player-card-layout:v1";
function loadLayout() {
  if (typeof window === "undefined") return DEFAULT_LAYOUT;
  try {
    const raw = window.localStorage.getItem(KEY);
    if (!raw) return DEFAULT_LAYOUT;
    const parsed = JSON.parse(raw);
    return { ...DEFAULT_LAYOUT, ...parsed, photo: { ...DEFAULT_LAYOUT.photo, ...parsed.photo ?? {} } };
  } catch {
    return DEFAULT_LAYOUT;
  }
}
function mergeLayout(partial) {
  if (!partial || typeof partial !== "object") return DEFAULT_LAYOUT;
  const p = partial;
  return {
    ...DEFAULT_LAYOUT,
    ...p,
    photo: { ...DEFAULT_LAYOUT.photo, ...p.photo ?? {} }
  };
}
const VB_W = 1023;
const VB_H = 1537;
const POS_ABBR = {
  QUARTERBACK: "QB",
  "RUNNING BACK": "RB",
  "WIDE RECEIVER": "WR",
  "TIGHT END": "TE",
  "OFFENSIVE LINE": "OL",
  "DEFENSIVE LINE": "DL",
  LINEBACKER: "LB",
  CORNERBACK: "CB",
  SAFETY: "S",
  KICKER: "K",
  PUNTER: "P"
};
function computeAge(birthdate) {
  if (!birthdate) return null;
  const d = new Date(birthdate);
  if (Number.isNaN(d.getTime())) return null;
  const now = /* @__PURE__ */ new Date();
  let age = now.getFullYear() - d.getFullYear();
  const m = now.getMonth() - d.getMonth();
  if (m < 0 || m === 0 && now.getDate() < d.getDate()) age--;
  return age;
}
const RED = "#E10600";
const FONT = "Anton, Bebas Neue, sans-serif";
function PlayerCard({
  data,
  layout = DEFAULT_LAYOUT,
  templateUrl
}) {
  const { card, profile, bullsProfile, jerseyNumber } = data;
  const ov = card.manual_overrides ?? {};
  const bfrDisplay = ov.BFR ?? card.bfr;
  const positionFull = (card.position_key ?? bullsProfile?.position ?? profile?.sport_position ?? "").toUpperCase();
  const positionAbbr = POS_ABBR[positionFull] ?? positionFull.slice(0, 3);
  const ageVal = computeAge(profile?.birthdate);
  const heightCm = bullsProfile?.height_cm ?? profile?.height_cm ?? null;
  const weightKg = bullsProfile?.weight_kg ?? null;
  const attrs = [
    { key: "spd", value: ov.SPD ?? card.spd },
    { key: "acc", value: ov.ACC ?? card.acc },
    { key: "agi", value: ov.AGI ?? card.agi },
    { key: "pow", value: ov.POW ?? card.pow },
    { key: "str", value: ov.STR ?? card.str },
    { key: "end", value: ov.END ?? card.end_score }
  ];
  const updateDate = card.bfr != null ? new Date(card.computed_at).toLocaleDateString("de-DE", { day: "2-digit", month: "2-digit", year: "numeric" }) : "";
  const strongest = card.strongest_attribute ?? "";
  const photoUrl = layout.photo.url ?? profile?.avatar_cutout_url ?? profile?.avatar_url ?? null;
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "relative h-full w-full", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
    "svg",
    {
      viewBox: `0 0 ${VB_W} ${VB_H}`,
      preserveAspectRatio: "xMidYMid meet",
      xmlns: "http://www.w3.org/2000/svg",
      className: "h-full w-full",
      style: { filter: "drop-shadow(0 30px 60px rgba(0,0,0,0.85))" },
      children: [
        photoUrl && /* @__PURE__ */ jsxRuntimeExports.jsx(
          "image",
          {
            href: photoUrl,
            x: layout.photo.x,
            y: layout.photo.y,
            width: layout.photo.w,
            height: layout.photo.h,
            preserveAspectRatio: "xMidYMid meet"
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx("image", { href: templateUrl ?? cardTemplate.url, x: "0", y: "0", width: VB_W, height: VB_H, preserveAspectRatio: "xMidYMid meet" }),
        bfrDisplay != null && /* @__PURE__ */ jsxRuntimeExports.jsx("text", { x: layout.ovr.x, y: layout.ovr.y, textAnchor: "middle", fontFamily: FONT, fontSize: layout.ovr.fontSize, fill: RED, children: bfrDisplay }),
        positionAbbr && /* @__PURE__ */ jsxRuntimeExports.jsx("text", { x: layout.pos.x, y: layout.pos.y, textAnchor: "middle", fontFamily: FONT, fontSize: layout.pos.fontSize, fill: RED, letterSpacing: "2", children: positionAbbr }),
        jerseyNumber && /* @__PURE__ */ jsxRuntimeExports.jsxs("text", { x: layout.jersey.x, y: layout.jersey.y, textAnchor: "middle", fontFamily: FONT, fontSize: layout.jersey.fontSize, fill: "#ffffff", children: [
          "#",
          jerseyNumber
        ] }),
        ageVal != null && /* @__PURE__ */ jsxRuntimeExports.jsx("text", { x: layout.age.x, y: layout.age.y, fontFamily: FONT, fontSize: layout.age.fontSize, fill: "#ffffff", letterSpacing: "1", children: ageVal }),
        heightCm != null && /* @__PURE__ */ jsxRuntimeExports.jsxs("text", { x: layout.height.x, y: layout.height.y, fontFamily: FONT, fontSize: layout.height.fontSize, fill: "#ffffff", letterSpacing: "1", children: [
          heightCm,
          " cm"
        ] }),
        weightKg != null && /* @__PURE__ */ jsxRuntimeExports.jsxs("text", { x: layout.weight.x, y: layout.weight.y, fontFamily: FONT, fontSize: layout.weight.fontSize, fill: "#ffffff", letterSpacing: "1", children: [
          weightKg,
          " kg"
        ] }),
        attrs.map((a) => {
          const it = layout[a.key];
          if (a.value == null) return null;
          const fs = it.fontSize ?? 72;
          return /* @__PURE__ */ jsxRuntimeExports.jsxs("g", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("rect", { x: it.x - 55, y: it.y - fs, width: 110, height: fs + 25, fill: "#000000", opacity: "0.85", rx: "8" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("text", { x: it.x, y: it.y, textAnchor: "middle", fontFamily: FONT, fontSize: fs, fill: "#ffffff", children: a.value })
          ] }, a.key);
        }),
        updateDate && /* @__PURE__ */ jsxRuntimeExports.jsx("text", { x: layout.updateDate.x, y: layout.updateDate.y, fontFamily: FONT, fontSize: layout.updateDate.fontSize, fill: "#ffffff", letterSpacing: "1", children: updateDate }),
        strongest && /* @__PURE__ */ jsxRuntimeExports.jsx("text", { x: layout.strongest.x, y: layout.strongest.y, fontFamily: FONT, fontSize: layout.strongest.fontSize, fill: RED, letterSpacing: "2", children: strongest })
      ]
    }
  ) });
}
export {
  DEFAULT_LAYOUT as D,
  PlayerCard as P,
  VB_W as V,
  VB_H as a,
  loadLayout as l,
  mergeLayout as m
};
