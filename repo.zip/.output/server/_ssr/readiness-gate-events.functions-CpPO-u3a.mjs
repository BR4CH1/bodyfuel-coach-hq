import { c as createSsrRpc } from "./createSsrRpc-r3tzPO1F.mjs";
import { c as createServerFn } from "./server-g-lQHb1O.mjs";
import { r as requireSupabaseAuth } from "./auth-middleware-B5YcFrfv.mjs";
const listRecentReadinessGateEvents = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((data) => data).handler(createSsrRpc("08ee886261d60b62ad0915f40669c3b5d1562fea4d65c23d3807d411d1d77e31"));
export {
  listRecentReadinessGateEvents as l
};
