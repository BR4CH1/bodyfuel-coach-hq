import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import { a as useServerFn, L as Label, I as Input, S as Switch, B as Button } from "./router-BmNvgrMe.mjs";
import { a as useQueryClient, u as useQuery, b as useMutation } from "../_libs/tanstack__react-query.mjs";
import { t as toast } from "../_libs/sonner.mjs";
import { getNutritionTargets, setNutritionTargets, extractTargetsFromPlan } from "./nutrition.functions-BVD9gwX2.mjs";
import { L as Link } from "../_libs/tanstack__react-router.mjs";
import { f as getCustomerPlanOverview, t as transitionPlanStatus, h as deletePlanDraft, u as updatePlanScheduling, i as setAutoPublish } from "./AppLayout-lnbnJZfJ.mjs";
import { generateAiNutritionPlanDraft } from "./nutrition-plan-ai.functions-Lkj_xb1B.mjs";
import { g as getPartnerLink } from "./partner.functions-DJD4yjFr.mjs";
import { c as createSsrRpc } from "./createSsrRpc-r3tzPO1F.mjs";
import { c as createServerFn } from "./server-g-lQHb1O.mjs";
import { r as requireSupabaseAuth } from "./auth-middleware-B5YcFrfv.mjs";
import { b as getCustomerSmartProfile, d as setCustomerWeeklyBudget } from "./autopilot-jobs.functions-DxvdXJgH.mjs";
import { D as Dumbbell, ae as Moon, L as LoaderCircle, p as Sparkles, i as Users, Y as Pencil, aF as Calendar, ap as FileText, aE as ListChecks, K as Eye, t as CircleCheck, u as Clock, ar as Rocket, o as Trash2 } from "../_libs/lucide-react.mjs";
function NutritionTargetsEditor({ userId }) {
  const getFn = useServerFn(getNutritionTargets);
  const setFn = useServerFn(setNutritionTargets);
  const extractFn = useServerFn(extractTargetsFromPlan);
  const qc = useQueryClient();
  const { data: loaded, isLoading: loading } = useQuery({
    queryKey: ["nutrition-targets", userId],
    queryFn: () => getFn({ data: { user_id: userId } })
  });
  const [kcal, setKcal] = reactExports.useState(2200);
  const [protein, setProtein] = reactExports.useState(150);
  const [carbs, setCarbs] = reactExports.useState(220);
  const [fat, setFat] = reactExports.useState(70);
  const [water, setWater] = reactExports.useState(8);
  const [useRest, setUseRest] = reactExports.useState(false);
  const [kcalR, setKcalR] = reactExports.useState(2e3);
  const [proteinR, setProteinR] = reactExports.useState(150);
  const [carbsR, setCarbsR] = reactExports.useState(170);
  const [fatR, setFatR] = reactExports.useState(65);
  const [saving, setSaving] = reactExports.useState(false);
  const [extracting, setExtracting] = reactExports.useState(false);
  reactExports.useEffect(() => {
    const t = loaded;
    if (!t) return;
    setKcal(t.kcal);
    setProtein(t.protein_g);
    setCarbs(t.carbs_g);
    setFat(t.fat_g);
    setWater(t.water_glasses);
    if (t.kcal_rest != null) {
      setUseRest(true);
      setKcalR(t.kcal_rest);
      setProteinR(t.protein_g_rest ?? t.protein_g);
      setCarbsR(t.carbs_g_rest ?? t.carbs_g);
      setFatR(t.fat_g_rest ?? t.fat_g);
    } else {
      setUseRest(false);
    }
  }, [loaded]);
  const extractFromPlan = async () => {
    setExtracting(true);
    try {
      const t = await extractFn({ data: { user_id: userId } });
      setKcal(t.kcal);
      setProtein(t.protein_g);
      setCarbs(t.carbs_g);
      setFat(t.fat_g);
      if (t.water_glasses) setWater(t.water_glasses);
      if (t.kcal_rest != null) {
        setUseRest(true);
        setKcalR(t.kcal_rest);
        setProteinR(t.protein_g_rest ?? t.protein_g);
        setCarbsR(t.carbs_g_rest ?? t.carbs_g);
        setFatR(t.fat_g_rest ?? t.fat_g);
        toast.success("Trainings- und Restday-Werte aus Plan übernommen.");
      } else {
        toast.success("Werte aus Plan übernommen — bitte prüfen & speichern.");
      }
    } catch (e) {
      toast.error(e.message);
    } finally {
      setExtracting(false);
    }
  };
  const save = async () => {
    setSaving(true);
    try {
      await setFn({
        data: {
          user_id: userId,
          kcal,
          protein_g: protein,
          carbs_g: carbs,
          fat_g: fat,
          water_glasses: water,
          kcal_rest: useRest ? kcalR : null,
          protein_g_rest: useRest ? proteinR : null,
          carbs_g_rest: useRest ? carbsR : null,
          fat_g_rest: useRest ? fatR : null
        }
      });
      await qc.invalidateQueries({ queryKey: ["nutrition-targets", userId] });
      toast.success("Ziele gespeichert.");
    } catch (e) {
      toast.error(e.message);
    } finally {
      setSaving(false);
    }
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl border border-border bg-card p-6", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "font-display text-lg font-bold", children: "Ernährungsziele" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-1 text-xs text-muted-foreground", children: "Vorgaben für Kalorien, Makros und Wasser. Kalorien werden auf 50-er-Schritte gerundet." }),
    loading ? /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-4 text-sm text-muted-foreground", children: "Lade…" }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-5 flex items-center gap-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Dumbbell, { className: "h-4 w-4 text-gold" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("h3", { className: "text-sm font-semibold", children: [
          "Trainingstag ",
          useRest ? "" : "(Standard)"
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-2 grid gap-3 sm:grid-cols-5", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-1", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { children: "kcal" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { type: "number", value: kcal, onChange: (e) => setKcal(Number(e.target.value)) })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-1", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { children: "Protein (g)" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { type: "number", value: protein, onChange: (e) => setProtein(Number(e.target.value)) })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-1", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { children: "Carbs (g)" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { type: "number", value: carbs, onChange: (e) => setCarbs(Number(e.target.value)) })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-1", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { children: "Fett (g)" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { type: "number", value: fat, onChange: (e) => setFat(Number(e.target.value)) })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-1", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { children: "Wasser (Gläser à 0,25 L)" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { type: "number", value: water, onChange: (e) => setWater(Number(e.target.value)) })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-5 flex items-center justify-between rounded-lg border border-border bg-background/40 px-3 py-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Moon, { className: "h-4 w-4 text-blue-400" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-sm font-semibold", children: "Restday-Werte separat" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[11px] text-muted-foreground", children: "An trainingsfreien Tagen werden automatisch diese Werte verwendet." })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Switch, { checked: useRest, onCheckedChange: setUseRest })
      ] }),
      useRest && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-3 grid gap-3 sm:grid-cols-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-1", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { children: "kcal (Rest)" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { type: "number", value: kcalR, onChange: (e) => setKcalR(Number(e.target.value)) })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-1", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { children: "Protein (g)" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { type: "number", value: proteinR, onChange: (e) => setProteinR(Number(e.target.value)) })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-1", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { children: "Carbs (g)" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { type: "number", value: carbsR, onChange: (e) => setCarbsR(Number(e.target.value)) })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-1", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { children: "Fett (g)" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { type: "number", value: fatR, onChange: (e) => setFatR(Number(e.target.value)) })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-5 flex flex-wrap gap-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          Button,
          {
            onClick: save,
            disabled: saving,
            className: "bg-gradient-gold text-primary-foreground",
            children: saving ? "Speichere…" : "Speichern"
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          Button,
          {
            type: "button",
            variant: "outline",
            onClick: extractFromPlan,
            disabled: extracting,
            children: [
              extracting ? /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "h-4 w-4 animate-spin" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Sparkles, { className: "h-4 w-4" }),
              extracting ? "Lese Plan…" : "Aus aktuellem Plan extrahieren (Smart)"
            ]
          }
        )
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-2 text-[11px] text-muted-foreground", children: "Sobald ein Smart-Plan aktiv wird, werden Trainings- und Restday-Werte automatisch hier übernommen — du kannst sie jederzeit anpassen." })
    ] })
  ] });
}
const generatePartnerNutritionPlanDraft = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => d).handler(createSsrRpc("fbb2fcc64626cff980021e68cc2135215c20b1f9293df6f47ea6ae58ab383a60"));
const STATUS_LABEL$1 = {
  draft: "Entwurf",
  approved: "Freigegeben",
  published: "Veröffentlicht",
  active: "Aktiv",
  archived: "Archiviert"
};
const STATUS_COLOR$1 = {
  draft: "bg-amber-500/15 text-amber-600 border-amber-500/30",
  approved: "bg-blue-500/15 text-blue-600 border-blue-500/30",
  published: "bg-violet-500/15 text-violet-600 border-violet-500/30",
  active: "bg-emerald-500/15 text-emerald-600 border-emerald-500/30",
  archived: "bg-muted text-muted-foreground border-border"
};
function fmtDate$1(s) {
  if (!s) return "—";
  return new Date(s).toLocaleDateString("de-DE", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric"
  });
}
function PlanManagementCard({ userId, returnOrgId }) {
  const qc = useQueryClient();
  const getFn = useServerFn(getCustomerPlanOverview);
  const genFn = useServerFn(generateAiNutritionPlanDraft);
  const transFn = useServerFn(transitionPlanStatus);
  const delFn = useServerFn(deletePlanDraft);
  const schedFn = useServerFn(updatePlanScheduling);
  const autoFn = useServerFn(setAutoPublish);
  const partnerLinkFn = useServerFn(getPartnerLink);
  const partnerGenFn = useServerFn(generatePartnerNutritionPlanDraft);
  const smartProfileFn = useServerFn(getCustomerSmartProfile);
  const setBudgetFn = useServerFn(setCustomerWeeklyBudget);
  const { data, isLoading } = useQuery({
    queryKey: ["plan-overview", userId],
    queryFn: () => getFn({ data: { user_id: userId } })
  });
  const partnerLink = useQuery({
    queryKey: ["partner-link", userId],
    queryFn: () => partnerLinkFn({ data: { user_id: userId } })
  });
  const invalidate = () => {
    qc.invalidateQueries({ queryKey: ["plan-overview", userId] });
    qc.invalidateQueries({ queryKey: ["nutrition-targets", userId] });
  };
  const todayISO = (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
  const defaultEndISO = (() => {
    const d = /* @__PURE__ */ new Date();
    d.setDate(d.getDate() + 6);
    return d.toISOString().slice(0, 10);
  })();
  const [startDate, setStartDate] = reactExports.useState(todayISO);
  const [endDate, setEndDate] = reactExports.useState(defaultEndISO);
  const computePlanDays = () => {
    const s = new Date(startDate);
    const e = new Date(endDate);
    if (isNaN(s.getTime()) || isNaN(e.getTime())) return 7;
    const diff = Math.round((e.getTime() - s.getTime()) / 864e5) + 1;
    return Math.max(1, Math.min(31, diff));
  };
  const smartProfile = useQuery({
    queryKey: ["smart-profile", userId],
    queryFn: () => smartProfileFn({ data: { user_id: userId } })
  });
  const [budgetInput, setBudgetInput] = reactExports.useState("");
  reactExports.useEffect(() => {
    const v = smartProfile.data?.weekly_budget_eur;
    if (v != null) setBudgetInput(String(v));
    else setBudgetInput("");
  }, [smartProfile.data?.weekly_budget_eur]);
  const saveBudget = useMutation({
    mutationFn: (val) => setBudgetFn({ data: { user_id: userId, weekly_budget_eur: val } }),
    onSuccess: () => {
      toast.success("Wochenbudget gespeichert.");
      qc.invalidateQueries({ queryKey: ["smart-profile", userId] });
    },
    onError: (e) => toast.error(e?.message ?? "Fehler beim Speichern")
  });
  const gen = useMutation({
    mutationFn: () => {
      const planDays = computePlanDays();
      return genFn({
        data: {
          user_id: userId,
          start_mode: "today",
          scheduled_start_date: startDate,
          plan_days: planDays
        }
      });
    },
    onSuccess: () => {
      const days = computePlanDays();
      toast.success(
        `Plan-Entwurf erstellt (${startDate} → ${endDate}, ${days} Tag${days === 1 ? "" : "e"}).`
      );
      invalidate();
    },
    onError: (e) => toast.error(e?.message ?? "Fehler beim Erstellen")
  });
  const trans = useMutation({
    mutationFn: ({ id, to }) => transFn({ data: { plan_id: id, to } }),
    onSuccess: (_, vars) => {
      toast.success(
        vars.to === "active" ? "Plan aktiviert — Ziele wurden automatisch übernommen." : `Status: ${STATUS_LABEL$1[vars.to]}`
      );
      invalidate();
    },
    onError: (e) => toast.error(e?.message ?? "Fehler")
  });
  const del = useMutation({
    mutationFn: (id) => delFn({ data: { plan_id: id } }),
    onSuccess: () => {
      toast.success("Plan gelöscht.");
      invalidate();
    },
    onError: (e) => toast.error(e?.message ?? "Fehler")
  });
  const auto = useMutation({
    mutationFn: (v) => autoFn({ data: { user_id: userId, auto_publish: v } }),
    onSuccess: () => invalidate(),
    onError: (e) => toast.error(e?.message ?? "Fehler")
  });
  const partnerGen = useMutation({
    mutationFn: () => {
      const planDays = computePlanDays();
      return partnerGenFn({
        data: {
          user_a: userId,
          user_b: partnerLink.data.partner_id,
          start_mode: "today",
          scheduled_start_date: startDate,
          plan_days: planDays
        }
      });
    },
    onSuccess: () => {
      const days = computePlanDays();
      toast.success(
        `Gemeinsamer Plan erstellt (${startDate} → ${endDate}, ${days} Tag${days === 1 ? "" : "e"}).`
      );
      invalidate();
    },
    onError: (e) => toast.error(e?.message ?? "Fehler beim Gemeinsamen Plan")
  });
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl border border-border bg-card p-6", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start justify-between gap-3", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs uppercase tracking-[0.2em] text-muted-foreground", children: "Ernährung" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "font-display text-xl font-bold", children: "Plan Management" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap gap-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            onClick: () => gen.mutate(),
            disabled: gen.isPending,
            className: "inline-flex items-center gap-2 rounded-lg bg-gradient-gold px-3 py-2 text-sm font-semibold text-primary-foreground disabled:opacity-60",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Sparkles, { className: "h-4 w-4" }),
              gen.isPending ? "Erstelle…" : "Plan solo"
            ]
          }
        ),
        partnerLink.data && /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            onClick: () => partnerGen.mutate(),
            disabled: partnerGen.isPending,
            className: "inline-flex items-center gap-2 rounded-lg border border-emerald-500/40 bg-emerald-500/10 px-3 py-2 text-sm font-semibold text-emerald-600 hover:bg-emerald-500/20 disabled:opacity-60",
            title: `Gemeinsam mit ${partnerLink.data.partner_name}`,
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Users, { className: "h-4 w-4" }),
              partnerGen.isPending ? "Erstelle…" : "Plan gemeinsam"
            ]
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "a",
          {
            href: returnOrgId ? `/coach/import-plan?type=nutrition&client=${userId}&orgId=${returnOrgId}` : `/coach/import-plan?type=nutrition&client=${userId}`,
            className: "inline-flex items-center gap-2 rounded-lg border border-gold/40 bg-background px-3 py-2 text-sm font-semibold hover:bg-accent",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Sparkles, { className: "h-4 w-4" }),
              "Eigenen Plan importieren"
            ]
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          Link,
          {
            to: "/coach/plan-builder/$userId",
            params: { userId },
            search: returnOrgId ? { orgId: returnOrgId } : {},
            className: "inline-flex items-center gap-2 rounded-lg border border-border bg-background px-3 py-2 text-sm font-semibold hover:bg-accent",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Pencil, { className: "h-4 w-4" }),
              "Manuell erstellen"
            ]
          }
        )
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-4 flex flex-wrap items-center gap-3 rounded-xl border border-dashed border-border bg-background/40 px-4 py-3 text-xs", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-semibold uppercase tracking-wider text-muted-foreground", children: "Zeitraum" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "inline-flex items-center gap-1.5", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Von" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "input",
          {
            type: "date",
            value: startDate,
            min: todayISO,
            onChange: (e) => {
              const v = e.target.value;
              setStartDate(v);
              if (v && endDate && new Date(v) > new Date(endDate)) {
                setEndDate(v);
              }
            },
            className: "rounded-md border border-input bg-background px-2 py-1 text-xs"
          }
        )
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "inline-flex items-center gap-1.5", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Bis" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "input",
          {
            type: "date",
            value: endDate,
            min: startDate || todayISO,
            onChange: (e) => setEndDate(e.target.value),
            className: "rounded-md border border-input bg-background px-2 py-1 text-xs"
          }
        )
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-muted-foreground", children: [
        "(",
        computePlanDays(),
        " Tag",
        computePlanDays() === 1 ? "" : "e",
        ", max. 31)"
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-2 flex flex-wrap items-center gap-3 rounded-xl border border-dashed border-border bg-background/40 px-4 py-3 text-xs", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-semibold uppercase tracking-wider text-muted-foreground", children: "Wochenbudget" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "inline-flex items-center gap-1.5", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "input",
          {
            type: "text",
            inputMode: "numeric",
            pattern: "[0-9]*",
            placeholder: "z. B. 80",
            value: budgetInput,
            onChange: (e) => setBudgetInput(e.target.value.replace(/[^0-9]/g, "").slice(0, 4)),
            className: "w-20 rounded-md border border-input bg-background px-2 py-1 text-xs"
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "€ / Woche (pro Person)" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          onClick: () => {
            const v = budgetInput.trim() === "" ? null : parseInt(budgetInput, 10);
            saveBudget.mutate(Number.isNaN(v) ? null : v);
          },
          disabled: saveBudget.isPending,
          className: "rounded-md bg-primary px-3 py-1 text-xs font-semibold text-primary-foreground disabled:opacity-60",
          children: saveBudget.isPending ? "Speichere…" : "Speichern"
        }
      ),
      partnerLink.data && (smartProfile.data?.weekly_budget_eur ?? 0) > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-muted-foreground", children: "Gemeinsamer Plan rechnet mit Summe beider Budgets." })
    ] }),
    isLoading && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-4 text-sm text-muted-foreground", children: "Lade…" }),
    !isLoading && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-4 grid gap-4 lg:grid-cols-2", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        PlanColumn,
        {
          label: "Aktiver Plan",
          tone: "active",
          userId,
          plan: data?.active ?? null,
          onArchive: (id) => trans.mutate({ id, to: "archived" })
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        PlanColumn,
        {
          label: "Nächster Plan",
          tone: "next",
          userId,
          plan: data?.next ?? null,
          onApprove: (id) => trans.mutate({ id, to: "approved" }),
          onPublish: (id) => trans.mutate({ id, to: "published" }),
          onActivate: (id) => trans.mutate({ id, to: "active" }),
          onDelete: (id) => {
            if (confirm("Entwurf wirklich löschen?")) del.mutate(id);
          },
          onUpdateDates: (id, start, end) => schedFn({
            data: {
              plan_id: id,
              scheduled_start_date: start,
              scheduled_end_date: end
            }
          }).then(() => {
            toast.success("Termine gespeichert.");
            invalidate();
          }).catch((e) => toast.error(e?.message ?? "Fehler"))
        }
      )
    ] }),
    data && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-4 flex flex-wrap items-center justify-between gap-3 rounded-xl border border-border bg-background/40 px-4 py-3 text-xs", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 text-muted-foreground", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Calendar, { className: "h-3.5 w-3.5" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
          "Nächster Einkauf in ",
          /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: data.days_until_next_shopping }),
          " Tag",
          data.days_until_next_shopping === 1 ? "" : "en"
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "inline-flex cursor-pointer items-center gap-2 text-muted-foreground", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "input",
          {
            type: "checkbox",
            className: "h-4 w-4 accent-current",
            checked: data.auto_publish,
            onChange: (e) => auto.mutate(e.target.checked)
          }
        ),
        "Automatisch aktivieren (sonst Coach-Freigabe nötig)"
      ] })
    ] }),
    data && data.archive.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsxs("details", { className: "mt-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("summary", { className: "cursor-pointer text-sm font-semibold text-muted-foreground hover:text-foreground", children: [
        "Planarchiv (",
        data.archive.length,
        ")"
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("ul", { className: "mt-3 divide-y divide-border text-sm", children: data.archive.map((p) => /* @__PURE__ */ jsxRuntimeExports.jsxs("li", { className: "flex items-center justify-between gap-2 py-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 min-w-0", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(FileText, { className: "h-4 w-4 text-muted-foreground shrink-0" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "truncate", children: p.title })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3 shrink-0", children: [
          p.compliance && /* @__PURE__ */ jsxRuntimeExports.jsx(ComplianceDot, { c: p.compliance }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs text-muted-foreground", children: fmtDate$1(p.created_at) })
        ] })
      ] }, p.id)) })
    ] })
  ] });
}
function PlanColumn(props) {
  const { label, tone, plan, userId } = props;
  const [editDates, setEditDates] = reactExports.useState(false);
  const [start, setStart] = reactExports.useState(plan?.scheduled_start_date ?? "");
  const [end, setEnd] = reactExports.useState(plan?.scheduled_end_date ?? "");
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(
    "div",
    {
      className: `rounded-xl border p-4 ${tone === "active" ? "border-emerald-500/30 bg-emerald-500/5" : "border-amber-500/30 bg-amber-500/5"}`,
      children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs uppercase tracking-[0.2em] text-muted-foreground", children: label }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
            plan?.compliance && /* @__PURE__ */ jsxRuntimeExports.jsx(ComplianceDot, { c: plan.compliance }),
            plan && /* @__PURE__ */ jsxRuntimeExports.jsx(
              "span",
              {
                className: `rounded-full border px-2 py-0.5 text-[10px] font-semibold uppercase ${STATUS_COLOR$1[plan.status]}`,
                children: STATUS_LABEL$1[plan.status]
              }
            )
          ] })
        ] }),
        !plan && /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-3 text-sm text-muted-foreground", children: tone === "active" ? "Kein aktiver Plan." : "Kein nächster Plan vorbereitet." }),
        plan && /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "mt-2 font-display text-base font-bold", children: plan.title }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-2 grid grid-cols-2 gap-2 text-xs text-muted-foreground", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1.5", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Calendar, { className: "h-3.5 w-3.5" }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
                fmtDate$1(plan.scheduled_start_date),
                " – ",
                fmtDate$1(plan.scheduled_end_date)
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1.5", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(ListChecks, { className: "h-3.5 w-3.5" }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
                plan.days_count,
                " Tage · ",
                plan.meals_count,
                " Mahlzeiten"
              ] })
            ] })
          ] }),
          (plan.kcal || plan.protein_g) && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-3 grid grid-cols-4 gap-2 text-center text-[11px]", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Macro, { label: "kcal", value: plan.kcal }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Macro, { label: "P", value: plan.protein_g, suffix: "g" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Macro, { label: "KH", value: plan.carbs_g, suffix: "g" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Macro, { label: "F", value: plan.fat_g, suffix: "g" })
          ] }),
          tone === "next" && editDates && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-3 grid grid-cols-2 gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "input",
              {
                type: "date",
                value: start ?? "",
                onChange: (e) => setStart(e.target.value),
                className: "rounded-md border border-input bg-background px-2 py-1 text-xs"
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "input",
              {
                type: "date",
                value: end ?? "",
                onChange: (e) => setEnd(e.target.value),
                className: "rounded-md border border-input bg-background px-2 py-1 text-xs"
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                onClick: () => {
                  props.onUpdateDates?.(plan.id, start || null, end || null);
                  setEditDates(false);
                },
                className: "col-span-2 rounded-md bg-primary px-2 py-1 text-xs font-semibold text-primary-foreground",
                children: "Termine speichern"
              }
            )
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-3 flex flex-wrap gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "a",
              {
                href: `/coach/plan-builder/${userId}?planId=${plan.id}`,
                className: "inline-flex items-center gap-1.5 rounded-md border border-border bg-background px-2.5 py-1.5 text-xs font-medium hover:bg-accent",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Pencil, { className: "h-3.5 w-3.5" }),
                  " Bearbeiten"
                ]
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "a",
              {
                href: `/coach/plan-preview/${plan.id}`,
                className: "inline-flex items-center gap-1.5 rounded-md border border-border bg-background px-2.5 py-1.5 text-xs font-medium hover:bg-accent",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Eye, { className: "h-3.5 w-3.5" }),
                  " Vorschau"
                ]
              }
            ),
            tone === "next" && /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                onClick: () => setEditDates((v) => !v),
                className: "inline-flex items-center gap-1.5 rounded-md border border-border bg-background px-2.5 py-1.5 text-xs font-medium hover:bg-accent",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Calendar, { className: "h-3.5 w-3.5" }),
                  " Termine"
                ]
              }
            ),
            tone === "next" && plan.status === "draft" && /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                onClick: () => props.onApprove?.(plan.id),
                className: "inline-flex items-center gap-1.5 rounded-md bg-blue-600 px-2.5 py-1.5 text-xs font-semibold text-white hover:opacity-90",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheck, { className: "h-3.5 w-3.5" }),
                  " Freigeben"
                ]
              }
            ),
            tone === "next" && plan.status === "approved" && /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                onClick: () => props.onPublish?.(plan.id),
                className: "inline-flex items-center gap-1.5 rounded-md bg-violet-600 px-2.5 py-1.5 text-xs font-semibold text-white hover:opacity-90",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Clock, { className: "h-3.5 w-3.5" }),
                  " Veröffentlichen"
                ]
              }
            ),
            tone === "next" && /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                onClick: () => props.onActivate?.(plan.id),
                className: "inline-flex items-center gap-1.5 rounded-md bg-emerald-600 px-2.5 py-1.5 text-xs font-semibold text-white hover:opacity-90",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Rocket, { className: "h-3.5 w-3.5" }),
                  " Jetzt aktivieren"
                ]
              }
            ),
            tone === "next" && /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                onClick: () => props.onDelete?.(plan.id),
                className: "inline-flex items-center gap-1.5 rounded-md border border-destructive/40 bg-destructive/10 px-2.5 py-1.5 text-xs font-medium text-destructive hover:bg-destructive/20",
                children: /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "h-3.5 w-3.5" })
              }
            ),
            tone === "active" && /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                onClick: () => props.onArchive?.(plan.id),
                className: "inline-flex items-center gap-1.5 rounded-md border border-border bg-background px-2.5 py-1.5 text-xs font-medium hover:bg-accent",
                children: "Archivieren"
              }
            )
          ] })
        ] })
      ]
    }
  );
}
function Macro({ label, value, suffix }) {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-md bg-background/60 px-2 py-1.5", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[10px] uppercase text-muted-foreground", children: label }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "font-semibold", children: [
      value ?? "—",
      suffix ?? ""
    ] })
  ] });
}
function ComplianceDot({
  c
}) {
  const color = c.tone === "green" ? "bg-emerald-500" : c.tone === "yellow" ? "bg-amber-500" : "bg-rose-500";
  const label = c.tone === "green" ? "Stark dabei" : c.tone === "yellow" ? "Geht so" : "Wenig aktiv";
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(
    "span",
    {
      title: `${label} · ${c.score}% · ${c.days_tracked} Check-ins`,
      className: "inline-flex items-center gap-1.5 text-[10px] font-semibold text-muted-foreground",
      children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: `h-2.5 w-2.5 rounded-full ${color}` }),
        c.score,
        "%"
      ]
    }
  );
}
const getCustomerTrainingPlanOverview = createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).inputValidator((d) => d).handler(createSsrRpc("aeeaf97bf2682e1d4829797deddc3950a6eea608a51dbbdfa6e586098707be38"));
const transitionTrainingPlanStatus = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => d).handler(createSsrRpc("844a5ba1b65ea1dcf0867db5f4a8701e746de6e48fdc3f2932fa154cebdeb6e8"));
const deleteTrainingPlanDraft = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => d).handler(createSsrRpc("7d47dcd8a347cbc6dd555b0ade456d220a9fa2c797cae192f9d0fae1fa795f6b"));
const updateTrainingPlanScheduling = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => d).handler(createSsrRpc("f12758107624b034575841baf5c44147e6fe5b0c907a2a34abb62f1017d1ea96"));
const setAutoPublishTraining = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => d).handler(createSsrRpc("e2cb5e57634910600d45b1c2c527b16ec384db4803825cf27e3210e84a28fe9b"));
const generateAiTrainingPlanDraft = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => d).handler(createSsrRpc("735afd7b5d13bf7da0791c8a38f421f6199fe74a31bd848002030db01e55911b"));
const STATUS_LABEL = {
  draft: "Entwurf",
  approved: "Freigegeben",
  published: "Veröffentlicht",
  active: "Aktiv",
  archived: "Archiviert"
};
const STATUS_COLOR = {
  draft: "bg-amber-500/15 text-amber-600 border-amber-500/30",
  approved: "bg-blue-500/15 text-blue-600 border-blue-500/30",
  published: "bg-violet-500/15 text-violet-600 border-violet-500/30",
  active: "bg-emerald-500/15 text-emerald-600 border-emerald-500/30",
  archived: "bg-muted text-muted-foreground border-border"
};
function fmtDate(s) {
  if (!s) return "—";
  return new Date(s).toLocaleDateString("de-DE", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric"
  });
}
function TrainingPlanManagementCard({ userId, returnOrgId }) {
  const qc = useQueryClient();
  const getFn = useServerFn(getCustomerTrainingPlanOverview);
  const genFn = useServerFn(generateAiTrainingPlanDraft);
  const transFn = useServerFn(transitionTrainingPlanStatus);
  const delFn = useServerFn(deleteTrainingPlanDraft);
  const schedFn = useServerFn(updateTrainingPlanScheduling);
  const autoFn = useServerFn(setAutoPublishTraining);
  const { data, isLoading } = useQuery({
    queryKey: ["training-plan-overview", userId],
    queryFn: () => getFn({ data: { user_id: userId } })
  });
  const invalidate = () => {
    qc.invalidateQueries({ queryKey: ["training-plan-overview", userId] });
  };
  const gen = useMutation({
    mutationFn: (start_mode) => genFn({ data: { user_id: userId, start_mode } }),
    onSuccess: (_d, mode) => {
      toast.success(
        mode === "today" ? "Trainingsplan-Entwurf ab heute erstellt." : "Trainingsplan-Entwurf ab nächster Woche erstellt."
      );
      invalidate();
    },
    onError: (e) => toast.error(e?.message ?? "Fehler beim Erstellen")
  });
  const trans = useMutation({
    mutationFn: ({ id, to }) => transFn({ data: { plan_id: id, to } }),
    onSuccess: (_, vars) => {
      toast.success(
        vars.to === "active" ? "Trainingsplan aktiviert." : `Status: ${STATUS_LABEL[vars.to]}`
      );
      invalidate();
    },
    onError: (e) => toast.error(e?.message ?? "Fehler")
  });
  const del = useMutation({
    mutationFn: (id) => delFn({ data: { plan_id: id } }),
    onSuccess: () => {
      toast.success("Plan gelöscht.");
      invalidate();
    },
    onError: (e) => toast.error(e?.message ?? "Fehler")
  });
  const auto = useMutation({
    mutationFn: (v) => autoFn({ data: { user_id: userId, auto_publish: v } }),
    onSuccess: () => invalidate()
  });
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl border border-border bg-card p-6", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start justify-between gap-3", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Dumbbell, { className: "h-5 w-5 text-gold" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs uppercase tracking-[0.2em] text-muted-foreground", children: "Training" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "font-display text-xl font-bold", children: "Trainingsplan Management" })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap gap-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            onClick: () => gen.mutate("today"),
            disabled: gen.isPending,
            className: "inline-flex items-center gap-2 rounded-lg bg-gradient-gold px-3 py-2 text-sm font-semibold text-primary-foreground disabled:opacity-60",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Sparkles, { className: "h-4 w-4" }),
              gen.isPending ? "Erstelle…" : "Smart-Plan generieren"
            ]
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            onClick: () => gen.mutate("next_week"),
            disabled: gen.isPending,
            className: "inline-flex items-center gap-2 rounded-lg border border-border bg-background px-3 py-2 text-sm font-semibold hover:bg-accent disabled:opacity-60",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Sparkles, { className: "h-4 w-4" }),
              gen.isPending ? "Erstelle…" : "Plan ab nächster Woche"
            ]
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          Link,
          {
            to: "/coach/training-builder/$userId",
            params: { userId },
            search: returnOrgId ? { orgId: returnOrgId } : {},
            className: "inline-flex items-center gap-2 rounded-lg border border-gold/40 bg-background px-3 py-2 text-sm font-semibold hover:bg-accent",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Pencil, { className: "h-4 w-4" }),
              "Manuell erstellen"
            ]
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "a",
          {
            href: returnOrgId ? `/coach/import-plan?type=training&client=${userId}&orgId=${returnOrgId}` : `/coach/import-plan?type=training&client=${userId}`,
            className: "inline-flex items-center gap-2 rounded-lg border border-border bg-background px-3 py-2 text-sm font-semibold hover:bg-accent",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Pencil, { className: "h-4 w-4" }),
              "Eigenen Plan importieren"
            ]
          }
        )
      ] })
    ] }),
    isLoading && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-4 text-sm text-muted-foreground", children: "Lade…" }),
    !isLoading && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-4 grid gap-4 lg:grid-cols-2", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        TrainingPlanColumn,
        {
          label: "Aktiver Plan",
          tone: "active",
          userId,
          plan: data?.active ?? null,
          onArchive: (id) => trans.mutate({ id, to: "archived" })
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        TrainingPlanColumn,
        {
          label: "Nächster Plan",
          tone: "next",
          userId,
          plan: data?.next ?? null,
          onApprove: (id) => trans.mutate({ id, to: "approved" }),
          onPublish: (id) => trans.mutate({ id, to: "published" }),
          onActivate: (id) => trans.mutate({ id, to: "active" }),
          onDelete: (id) => {
            if (confirm("Entwurf wirklich löschen?")) del.mutate(id);
          },
          onUpdateDates: (id, start, end) => schedFn({
            data: {
              plan_id: id,
              scheduled_start_date: start,
              scheduled_end_date: end
            }
          }).then(() => {
            toast.success("Termine gespeichert.");
            invalidate();
          }).catch((e) => toast.error(e?.message ?? "Fehler"))
        }
      )
    ] }),
    data && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-4 flex flex-wrap items-center justify-between gap-3 rounded-xl border border-border bg-background/40 px-4 py-3 text-xs", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 text-muted-foreground", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Calendar, { className: "h-3.5 w-3.5" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
          "Trainingstage:",
          " ",
          /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: data.training_weekdays?.length ? data.training_weekdays.join(", ") : "—" })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "inline-flex cursor-pointer items-center gap-2 text-muted-foreground", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "input",
          {
            type: "checkbox",
            className: "h-4 w-4 accent-current",
            checked: data.auto_publish,
            onChange: (e) => auto.mutate(e.target.checked)
          }
        ),
        "Automatisch aktivieren (sonst Coach-Freigabe nötig)"
      ] })
    ] }),
    data && data.archive.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsxs("details", { className: "mt-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("summary", { className: "cursor-pointer text-sm font-semibold text-muted-foreground hover:text-foreground", children: [
        "Planarchiv (",
        data.archive.length,
        ")"
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("ul", { className: "mt-3 divide-y divide-border text-sm", children: data.archive.map((p) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "li",
        {
          className: "flex items-center justify-between gap-2 py-2",
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 min-w-0", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Dumbbell, { className: "h-4 w-4 text-muted-foreground shrink-0" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "truncate", children: p.title })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs text-muted-foreground shrink-0", children: fmtDate(p.created_at) })
          ]
        },
        p.id
      )) })
    ] })
  ] });
}
function TrainingPlanColumn(props) {
  const { label, tone, plan, userId } = props;
  const [editDates, setEditDates] = reactExports.useState(false);
  const [start, setStart] = reactExports.useState(plan?.scheduled_start_date ?? "");
  const [end, setEnd] = reactExports.useState(plan?.scheduled_end_date ?? "");
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(
    "div",
    {
      className: `rounded-xl border p-4 ${tone === "active" ? "border-emerald-500/30 bg-emerald-500/5" : "border-amber-500/30 bg-amber-500/5"}`,
      children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs uppercase tracking-[0.2em] text-muted-foreground", children: label }),
          plan && /* @__PURE__ */ jsxRuntimeExports.jsx(
            "span",
            {
              className: `rounded-full border px-2 py-0.5 text-[10px] font-semibold uppercase ${STATUS_COLOR[plan.status]}`,
              children: STATUS_LABEL[plan.status]
            }
          )
        ] }),
        !plan && /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-3 text-sm text-muted-foreground", children: tone === "active" ? "Kein aktiver Trainingsplan." : "Kein nächster Trainingsplan vorbereitet." }),
        plan && /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "mt-2 font-display text-base font-bold", children: plan.title }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-2 grid grid-cols-2 gap-2 text-xs text-muted-foreground", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1.5", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Calendar, { className: "h-3.5 w-3.5" }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
                fmtDate(plan.scheduled_start_date),
                " –",
                " ",
                fmtDate(plan.scheduled_end_date)
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1.5", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(ListChecks, { className: "h-3.5 w-3.5" }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
                plan.days_count,
                " Tage · ",
                plan.exercises_count,
                " Übungen"
              ] })
            ] })
          ] }),
          tone === "next" && editDates && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-3 grid grid-cols-2 gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "input",
              {
                type: "date",
                value: start ?? "",
                onChange: (e) => setStart(e.target.value),
                className: "rounded-md border border-input bg-background px-2 py-1 text-xs"
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "input",
              {
                type: "date",
                value: end ?? "",
                onChange: (e) => setEnd(e.target.value),
                className: "rounded-md border border-input bg-background px-2 py-1 text-xs"
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                onClick: () => {
                  props.onUpdateDates?.(plan.id, start || null, end || null);
                  setEditDates(false);
                },
                className: "col-span-2 rounded-md bg-primary px-2 py-1 text-xs font-semibold text-primary-foreground",
                children: "Termine speichern"
              }
            )
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-3 flex flex-wrap gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "a",
              {
                href: `/coach/training-builder/${userId}?planId=${plan.id}`,
                className: "inline-flex items-center gap-1.5 rounded-md border border-border bg-background px-2.5 py-1.5 text-xs font-medium hover:bg-accent",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Pencil, { className: "h-3.5 w-3.5" }),
                  " Bearbeiten"
                ]
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "a",
              {
                href: `/coach/plan-preview/${plan.id}`,
                className: "inline-flex items-center gap-1.5 rounded-md border border-border bg-background px-2.5 py-1.5 text-xs font-medium hover:bg-accent",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Eye, { className: "h-3.5 w-3.5" }),
                  " Vorschau"
                ]
              }
            ),
            tone === "next" && /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                onClick: () => setEditDates((v) => !v),
                className: "inline-flex items-center gap-1.5 rounded-md border border-border bg-background px-2.5 py-1.5 text-xs font-medium hover:bg-accent",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Calendar, { className: "h-3.5 w-3.5" }),
                  " Termine"
                ]
              }
            ),
            tone === "next" && plan.status === "draft" && /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                onClick: () => props.onApprove?.(plan.id),
                className: "inline-flex items-center gap-1.5 rounded-md bg-blue-600 px-2.5 py-1.5 text-xs font-semibold text-white hover:opacity-90",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheck, { className: "h-3.5 w-3.5" }),
                  " Freigeben"
                ]
              }
            ),
            tone === "next" && plan.status === "approved" && /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                onClick: () => props.onPublish?.(plan.id),
                className: "inline-flex items-center gap-1.5 rounded-md bg-violet-600 px-2.5 py-1.5 text-xs font-semibold text-white hover:opacity-90",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Clock, { className: "h-3.5 w-3.5" }),
                  " Veröffentlichen"
                ]
              }
            ),
            tone === "next" && /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                onClick: () => props.onActivate?.(plan.id),
                className: "inline-flex items-center gap-1.5 rounded-md bg-emerald-600 px-2.5 py-1.5 text-xs font-semibold text-white hover:opacity-90",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Rocket, { className: "h-3.5 w-3.5" }),
                  " Jetzt aktivieren"
                ]
              }
            ),
            tone === "next" && /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                onClick: () => props.onDelete?.(plan.id),
                className: "inline-flex items-center gap-1.5 rounded-md border border-destructive/40 bg-destructive/10 px-2.5 py-1.5 text-xs font-medium text-destructive hover:bg-destructive/20",
                children: /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "h-3.5 w-3.5" })
              }
            ),
            tone === "active" && /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                onClick: () => props.onArchive?.(plan.id),
                className: "inline-flex items-center gap-1.5 rounded-md border border-border bg-background px-2.5 py-1.5 text-xs font-medium hover:bg-accent",
                children: "Archivieren"
              }
            )
          ] })
        ] })
      ]
    }
  );
}
export {
  NutritionTargetsEditor as N,
  PlanManagementCard as P,
  TrainingPlanManagementCard as T,
  generatePartnerNutritionPlanDraft as g
};
