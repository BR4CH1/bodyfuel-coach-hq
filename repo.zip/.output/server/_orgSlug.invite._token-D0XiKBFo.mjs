import { r as reactExports, j as jsxRuntimeExports } from "./_libs/react.mjs";
import { e as useNavigate, L as Link } from "./_libs/tanstack__react-router.mjs";
import { aE as Route$T, u as useSession, a as useServerFn, aF as acceptOrganizationInvite, aG as getInvitePreview, B as Button, aH as roleLabelFromDbRole, aI as scopeLabel, L as Label, I as Input } from "./_ssr/router-BmNvgrMe.mjs";
import { t as toast } from "./_libs/sonner.mjs";
import { s as supabase } from "./_ssr/client-mgvTz6tP.mjs";
import "./_libs/idb.mjs";

import "./_libs/seroval.mjs";
import "./_libs/unenv.mjs";

import "./_libs/lovable.dev__mcp-js.mjs";
import "./_libs/modelcontextprotocol__sdk.mjs";
import "./_libs/zod-to-json-schema.mjs";
import "./_libs/ajv-formats.mjs";
import "./_libs/stripe.mjs";
import { a3 as Flame, a5 as ShieldCheck, i as Users, ag as Mail, aj as Lock } from "./_libs/lucide-react.mjs";
import "./_libs/tanstack__router-core.mjs";
import "./_libs/tanstack__history.mjs";
import "./_libs/cookie-es.mjs";
import "./_libs/seroval-plugins.mjs";


import "./_libs/react-dom.mjs";
import "./_libs/isbot.mjs";
import "./_libs/tanstack__query-core.mjs";
import "./_libs/tanstack__react-query.mjs";
import "./_libs/radix-ui__react-slot.mjs";
import "./_libs/radix-ui__react-compose-refs.mjs";
import "./_libs/class-variance-authority.mjs";
import "./_libs/clsx.mjs";
import "./_libs/tailwind-merge.mjs";
import "./_libs/radix-ui__react-switch.mjs";
import "./_libs/radix-ui__primitive.mjs";
import "./_libs/radix-ui__react-context.mjs";
import "./_libs/@radix-ui/react-use-controllable-state+[...].mjs";
import "./_libs/@radix-ui/react-use-layout-effect+[...].mjs";
import "./_libs/radix-ui__react-use-previous.mjs";
import "./_libs/radix-ui__react-use-size.mjs";
import "./_libs/radix-ui__react-primitive.mjs";
import "./_ssr/createSsrRpc-r3tzPO1F.mjs";
import "./_ssr/server-g-lQHb1O.mjs";
import "./_libs/h3-v2.mjs";
import "./_libs/rou3.mjs";
import "./_libs/srvx.mjs";






import "./_ssr/auth-middleware-B5YcFrfv.mjs";
import "./_libs/supabase__supabase-js.mjs";
import "./_libs/supabase__postgrest-js.mjs";
import "./_libs/supabase__realtime-js.mjs";
import "./_libs/supabase__phoenix.mjs";
import "./_libs/supabase__storage-js.mjs";
import "./_libs/iceberg-js.mjs";
import "./_libs/supabase__auth-js.mjs";
import "./_libs/tslib.mjs";
import "./_libs/supabase__functions-js.mjs";
import "./_libs/radix-ui__react-label.mjs";
import "./_libs/tanstack__zod-adapter.mjs";
import "./_libs/zod.mjs";
import "./_libs/radix-ui__react-dialog.mjs";
import "./_libs/radix-ui__react-id.mjs";
import "./_libs/@radix-ui/react-dismissable-layer+[...].mjs";
import "./_libs/@radix-ui/react-use-callback-ref+[...].mjs";
import "./_libs/radix-ui__react-focus-scope.mjs";
import "./_libs/radix-ui__react-portal.mjs";
import "./_libs/radix-ui__react-presence.mjs";
import "./_libs/radix-ui__react-focus-guards.mjs";
import "./_libs/react-remove-scroll.mjs";
import "./_libs/react-remove-scroll-bar.mjs";
import "./_libs/react-style-singleton.mjs";
import "./_libs/get-nonce.mjs";
import "./_libs/use-sidecar.mjs";
import "./_libs/use-callback-ref.mjs";
import "./_libs/aria-hidden.mjs";
import "./_libs/radix-ui__react-checkbox.mjs";
import "./_ssr/coach-analytics.rules-DadTu4Zq.mjs";
import "./_ssr/football-positions-BJzdkmjv.mjs";
import "./_ssr/athlete-training-session-pool-CmIQKgmz.mjs";
import "./_libs/lovable.dev__webhooks-js.mjs";
import "./_ssr/registry-BHGsuy94.mjs";
import "./_libs/react-email__html.mjs";
import "./_libs/react-email__head.mjs";
import "./_libs/react-email__preview.mjs";
import "./_libs/react-email__body.mjs";
import "./_libs/react-email__container.mjs";
import "./_libs/react-email__section.mjs";
import "./_libs/react-email__heading.mjs";
import "./_libs/react-email__text.mjs";
import "./_libs/react-email__button.mjs";
import "./_libs/react-email__hr.mjs";
import "./_libs/react-email__img.mjs";
import "./_ssr/task-engine.server-BbzZOvQb.mjs";
import "./_ssr/stripe.server-mcZ3T1eX.mjs";
import "./_libs/lovable.dev__email-js.mjs";
import "./_libs/react-email__render.mjs";
import "./_libs/prettier.mjs";
import "./_libs/html-to-text.mjs";
import "./_libs/selderee__plugin-htmlparser2.mjs";
import "./_libs/selderee.mjs";
import "./_libs/parseley.mjs";
import "./_libs/leac.mjs";
import "./_libs/peberminta.mjs";
import "./_libs/domhandler.mjs";
import "./_libs/domelementtype.mjs";
import "./_libs/htmlparser2.mjs";
import "./_libs/entities.mjs";
import "./_libs/deepmerge.mjs";
import "./_libs/dom-serializer.mjs";
import "./_libs/react-email__link.mjs";
import "./_libs/jose.mjs";
import "./_libs/ajv.mjs";
import "./_libs/fast-deep-equal.mjs";
import "./_libs/json-schema-traverse.mjs";
import "./_libs/fast-uri.mjs";
function InviteAccept() {
  const {
    orgSlug,
    token
  } = Route$T.useParams();
  const {
    supabaseUser,
    loading
  } = useSession();
  const navigate = useNavigate();
  const accept = useServerFn(acceptOrganizationInvite);
  const preview = useServerFn(getInvitePreview);
  const [info, setInfo] = reactExports.useState(null);
  const [mode, setMode] = reactExports.useState("signup");
  const [email, setEmail] = reactExports.useState("");
  const [password, setPassword] = reactExports.useState("");
  const [busy, setBusy] = reactExports.useState(false);
  const [accepting, setAccepting] = reactExports.useState(false);
  const [error, setError] = reactExports.useState(null);
  reactExports.useEffect(() => {
    preview({
      data: {
        token
      }
    }).then((res) => {
      setInfo(res);
      if (res.ok && res.email) setEmail(res.email);
    }).catch((e) => {
      setError(e instanceof Error ? e.message : "Einladung konnte nicht geladen werden.");
      setInfo({
        ok: false,
        reason: "error"
      });
    });
  }, [preview, token]);
  reactExports.useEffect(() => {
    if (loading || !supabaseUser || accepting) return;
    if (!info || info.ok === false) return;
    if (info.status !== "pending") return;
    const inviteEmail = info.email?.trim().toLowerCase();
    const userEmail = supabaseUser.email?.trim().toLowerCase();
    if (inviteEmail && userEmail && inviteEmail !== userEmail) {
      setError(`Diese Einladung ist für ${info.email} ausgestellt. Du bist als ${supabaseUser.email} eingeloggt.`);
      return;
    }
    setAccepting(true);
    accept({
      data: {
        token
      }
    }).then((res) => {
      toast.success("Zugang aktiviert.");
      navigate({
        to: "/$orgSlug",
        params: {
          orgSlug: res.slug ?? orgSlug
        },
        replace: true
      });
    }).catch((e) => {
      setError(e instanceof Error ? e.message : "Einladung ungültig.");
      setAccepting(false);
    });
  }, [supabaseUser, loading, accept, token, orgSlug, navigate, accepting, info]);
  const signOutAndReload = async () => {
    await supabase.auth.signOut();
    window.location.reload();
  };
  const submit = async (e) => {
    e.preventDefault();
    if (!info || !info.ok) return;
    const normEmail = email.trim().toLowerCase();
    const inviteEmail = info.email?.trim().toLowerCase();
    if (inviteEmail && normEmail !== inviteEmail) {
      toast.error("Bitte die eingeladene E-Mail-Adresse verwenden.");
      return;
    }
    if (password.length < 8) {
      toast.error("Passwort mit mindestens 8 Zeichen wählen.");
      return;
    }
    setBusy(true);
    try {
      if (mode === "signup") {
        const {
          data: signUpData,
          error: err
        } = await supabase.auth.signUp({
          email: normEmail,
          password,
          options: {
            emailRedirectTo: `${window.location.origin}/${orgSlug}/invite/${token}`
          }
        });
        if (err) throw err;
        if (!signUpData.session) {
          toast.info("Account erstellt. Bitte prüfe dein E-Mail Postfach und bestätige den Link, um fortzufahren.");
        } else {
          toast.success("Account erstellt.");
        }
      } else {
        const {
          error: err
        } = await supabase.auth.signInWithPassword({
          email: normEmail,
          password
        });
        if (err) throw err;
      }
    } catch (err) {
      const raw = err instanceof Error ? err.message : "Anmeldung fehlgeschlagen";
      if (/already registered|user already/i.test(raw)) {
        toast.error("Für diese E-Mail existiert bereits ein Account. Bitte einloggen.");
        setMode("signin");
      } else {
        toast.error(raw);
      }
    } finally {
      setBusy(false);
    }
  };
  if (!info || loading) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx(Centered, { children: "Einladung wird geladen…" });
  }
  if (!info.ok) {
    return /* @__PURE__ */ jsxRuntimeExports.jsxs(Centered, { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "font-display text-xl font-semibold", children: "Einladung ungültig" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-2 text-sm text-muted-foreground", children: error ?? "Diese Einladung existiert nicht mehr." }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { asChild: true, className: "mt-6", variant: "outline", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/auth", search: {
        next: void 0
      }, children: "Zum Login" }) })
    ] });
  }
  if (info.status !== "pending") {
    return /* @__PURE__ */ jsxRuntimeExports.jsxs(Centered, { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "font-display text-xl font-semibold", children: info.status === "accepted" ? "Einladung bereits angenommen" : info.status === "expired" ? "Einladung abgelaufen" : "Einladung nicht mehr gültig" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-2 text-sm text-muted-foreground", children: "Bitte die Vereinsleitung um eine neue Einladung." }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { asChild: true, className: "mt-6", variant: "outline", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/auth", search: {
        next: void 0
      }, children: "Zum Login" }) })
    ] });
  }
  if (supabaseUser) {
    const inviteEmail = info.email?.trim().toLowerCase();
    const userEmail = supabaseUser.email?.trim().toLowerCase();
    const mismatch = !!inviteEmail && !!userEmail && inviteEmail !== userEmail;
    if (mismatch) {
      return /* @__PURE__ */ jsxRuntimeExports.jsxs(Centered, { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "font-display text-xl font-semibold", children: "Falscher Account" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "mt-2 text-sm text-muted-foreground", children: [
          "Diese Einladung ist für",
          " ",
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-foreground", children: info.email }),
          " ausgestellt. Du bist als",
          " ",
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-foreground", children: supabaseUser.email }),
          " ",
          "eingeloggt."
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { className: "mt-6", onClick: signOutAndReload, children: "Ausloggen & mit richtiger E-Mail annehmen" })
      ] });
    }
    return /* @__PURE__ */ jsxRuntimeExports.jsxs(Centered, { children: [
      "Zugang wird aktiviert…",
      error ? ` (${error})` : ""
    ] });
  }
  const roleLabel = roleLabelFromDbRole(info.role);
  const scope = scopeLabel(info.team_name);
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative flex min-h-screen items-center justify-center overflow-hidden bg-background px-4 py-10", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "pointer-events-none absolute inset-0", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute -left-32 top-10 h-96 w-96 rounded-full bg-gold/10 blur-3xl" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute -right-20 bottom-0 h-96 w-96 rounded-full bg-gold/5 blur-3xl" })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative w-full max-w-md rounded-3xl border border-border bg-card p-7 shadow-gold sm:p-10", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-6 flex items-center gap-3", children: [
        info.organization.logo_url ? /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: info.organization.logo_url, alt: "", className: "h-11 w-11 rounded-xl object-cover" }) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid h-11 w-11 place-items-center rounded-xl bg-gradient-gold", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Flame, { className: "h-5 w-5 text-primary-foreground", strokeWidth: 2.5 }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-display text-lg font-bold tracking-wider", children: info.organization.name || "BODYFUEL" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[10px] uppercase tracking-[0.2em] text-muted-foreground", children: "Staff Einladung" })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "font-display text-2xl font-bold", children: "Willkommen im Trainerteam" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "mt-1 text-sm text-muted-foreground", children: [
        "Du wurdest eingeladen als Teil des Staff bei",
        " ",
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-foreground", children: info.organization.name }),
        ". Erstelle dein Konto, um Zugriff zu erhalten."
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-4 space-y-2 rounded-2xl border border-border bg-muted/30 p-4 text-sm", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldCheck, { className: "h-4 w-4 text-gold" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-muted-foreground", children: "Funktion:" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-medium", children: roleLabel })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Users, { className: "h-4 w-4 text-gold" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-muted-foreground", children: "Zuständigkeit:" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-medium", children: scope })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-6 flex gap-2 rounded-xl bg-muted p-1 text-sm", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("button", { type: "button", onClick: () => setMode("signup"), className: `flex-1 rounded-lg py-2 font-medium transition ${mode === "signup" ? "bg-card text-foreground shadow" : "text-muted-foreground"}`, children: "Konto erstellen" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("button", { type: "button", onClick: () => setMode("signin"), className: `flex-1 rounded-lg py-2 font-medium transition ${mode === "signin" ? "bg-card text-foreground shadow" : "text-muted-foreground"}`, children: "Bereits Account" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("form", { onSubmit: submit, className: "mt-6 space-y-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { htmlFor: "email", children: "E-Mail" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Mail, { className: "pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { id: "email", name: "email", type: "email", value: email, onChange: (e) => setEmail(e.target.value), className: "pl-9", required: true, readOnly: !!info.email, autoComplete: "email" })
          ] }),
          info.email && /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-muted-foreground", children: "Die Einladung ist an diese Adresse gebunden." })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { htmlFor: "password", children: mode === "signup" ? "Passwort wählen" : "Passwort" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Lock, { className: "pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { id: "password", name: "password", type: "password", value: password, onChange: (e) => setPassword(e.target.value), className: "pl-9", required: true, minLength: 8, autoComplete: mode === "signup" ? "new-password" : "current-password" })
          ] }),
          mode === "signup" && /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-muted-foreground", children: "Mindestens 8 Zeichen." })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { type: "submit", disabled: busy, className: "w-full bg-gradient-gold text-primary-foreground hover:opacity-90", children: busy ? "..." : mode === "signup" ? "Konto erstellen & annehmen" : "Einloggen & annehmen" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-6 text-center text-xs text-muted-foreground", children: "Nach der Anmeldung wirst du direkt zu deinem Bereich weitergeleitet." })
    ] })
  ] });
}
function Centered({
  children
}) {
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid min-h-screen place-items-center bg-background px-6 text-center text-foreground", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "max-w-sm text-sm text-muted-foreground", children }) });
}
export {
  InviteAccept as component
};
