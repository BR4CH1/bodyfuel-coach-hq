import { j as jsxRuntimeExports } from "./_libs/react.mjs";

const SplitNotFoundComponent = () => /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid min-h-screen place-items-center bg-background p-6 text-center text-muted-foreground", children: "Diese Organisation existiert nicht." });
export {
  SplitNotFoundComponent as notFoundComponent
};
