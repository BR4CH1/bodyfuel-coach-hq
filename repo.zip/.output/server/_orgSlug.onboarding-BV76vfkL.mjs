import { r as reactExports, j as jsxRuntimeExports } from "./_libs/react.mjs";
import { e as useNavigate } from "./_libs/tanstack__react-router.mjs";
import { R as Route$2n, u as useSession, a as useServerFn, o as getOrganizationContext, a2 as completeOrganizationOnboardingV2, I as Input, B as Button, a3 as completeStaffOrganizationOnboarding, L as Label } from "./_ssr/router-BmNvgrMe.mjs";
import { u as useQuery, a as useQueryClient, b as useMutation } from "./_libs/tanstack__react-query.mjs";
import { t as toast } from "./_libs/sonner.mjs";
import { c as createSsrRpc } from "./_ssr/createSsrRpc-r3tzPO1F.mjs";
import { c as createServerFn } from "./_ssr/server-g-lQHb1O.mjs";
import { r as requireSupabaseAuth } from "./_ssr/auth-middleware-B5YcFrfv.mjs";
import { s as supabase } from "./_ssr/client-mgvTz6tP.mjs";
import { d as deriveOrgRole } from "./_ssr/org-role-CjKFa8wS.mjs";
import { T as Textarea } from "./_ssr/textarea-CAY_SJkd.mjs";
import { S as Select, a as SelectTrigger, b as SelectValue, c as SelectContent, d as SelectItem } from "./_ssr/select-_LI6tzbO.mjs";
import "./_libs/idb.mjs";
import "./_libs/unenv.mjs";

import "./_libs/lovable.dev__mcp-js.mjs";
import "./_libs/modelcontextprotocol__sdk.mjs";
import "./_libs/zod-to-json-schema.mjs";
import "./_libs/ajv-formats.mjs";
import "./_libs/stripe.mjs";

import "./_libs/seroval.mjs";
import "./_libs/tanstack__router-core.mjs";
import "./_libs/tanstack__history.mjs";
import "./_libs/cookie-es.mjs";
import "./_libs/seroval-plugins.mjs";


import "./_libs/react-dom.mjs";
import "./_libs/isbot.mjs";
import "./_libs/tanstack__query-core.mjs";
import "./_libs/radix-ui__react-slot.mjs";
import "./_libs/radix-ui__react-compose-refs.mjs";
import "./_libs/class-variance-authority.mjs";
import "./_libs/clsx.mjs";
import "./_libs/tailwind-merge.mjs";
import "./_libs/radix-ui__react-switch.mjs";
import "./_libs/radix-ui__primitive.mjs";
import "./_libs/radix-ui__react-context.mjs";
import "./_libs/@radix-ui/react-use-controllable-state+[...].mjs";
import "./_libs/@radix-ui/react-use-layout-effect+[...].mjs";
import "./_libs/radix-ui__react-use-previous.mjs";
import "./_libs/radix-ui__react-use-size.mjs";
import "./_libs/radix-ui__react-primitive.mjs";
import "./_libs/radix-ui__react-label.mjs";
import "./_libs/tanstack__zod-adapter.mjs";
import "./_libs/zod.mjs";
import "./_libs/supabase__supabase-js.mjs";
import "./_libs/supabase__postgrest-js.mjs";
import "./_libs/supabase__realtime-js.mjs";
import "./_libs/supabase__phoenix.mjs";
import "./_libs/supabase__storage-js.mjs";

import "./_libs/iceberg-js.mjs";
import "./_libs/supabase__auth-js.mjs";
import "./_libs/tslib.mjs";
import "./_libs/supabase__functions-js.mjs";

import "./_libs/radix-ui__react-dialog.mjs";
import "./_libs/radix-ui__react-id.mjs";
import "./_libs/@radix-ui/react-dismissable-layer+[...].mjs";
import "./_libs/@radix-ui/react-use-callback-ref+[...].mjs";
import "./_libs/radix-ui__react-focus-scope.mjs";
import "./_libs/radix-ui__react-portal.mjs";
import "./_libs/radix-ui__react-presence.mjs";
import "./_libs/radix-ui__react-focus-guards.mjs";
import "./_libs/react-remove-scroll.mjs";
import "./_libs/react-remove-scroll-bar.mjs";
import "./_libs/react-style-singleton.mjs";
import "./_libs/get-nonce.mjs";
import "./_libs/use-sidecar.mjs";
import "./_libs/use-callback-ref.mjs";
import "./_libs/aria-hidden.mjs";
import "./_libs/radix-ui__react-checkbox.mjs";
import "./_ssr/coach-analytics.rules-DadTu4Zq.mjs";
import "./_ssr/football-positions-BJzdkmjv.mjs";
import "./_ssr/athlete-training-session-pool-CmIQKgmz.mjs";
import "./_libs/lovable.dev__webhooks-js.mjs";
import "./_ssr/registry-BHGsuy94.mjs";
import "./_libs/react-email__html.mjs";
import "./_libs/react-email__head.mjs";
import "./_libs/react-email__preview.mjs";
import "./_libs/react-email__body.mjs";
import "./_libs/react-email__container.mjs";
import "./_libs/react-email__section.mjs";
import "./_libs/react-email__heading.mjs";
import "./_libs/react-email__text.mjs";
import "./_libs/react-email__button.mjs";
import "./_libs/react-email__hr.mjs";
import "./_libs/react-email__img.mjs";
import "./_ssr/task-engine.server-BbzZOvQb.mjs";
import "./_ssr/stripe.server-mcZ3T1eX.mjs";
import "./_libs/lovable.dev__email-js.mjs";
import "./_libs/react-email__render.mjs";
import "./_libs/prettier.mjs";
import "./_libs/html-to-text.mjs";
import "./_libs/selderee__plugin-htmlparser2.mjs";
import "./_libs/selderee.mjs";
import "./_libs/parseley.mjs";
import "./_libs/leac.mjs";
import "./_libs/peberminta.mjs";
import "./_libs/domhandler.mjs";
import "./_libs/domelementtype.mjs";
import "./_libs/htmlparser2.mjs";
import "./_libs/entities.mjs";
import "./_libs/deepmerge.mjs";
import "./_libs/dom-serializer.mjs";
import "./_libs/lucide-react.mjs";
import "./_libs/react-email__link.mjs";
import "./_libs/h3-v2.mjs";
import "./_libs/rou3.mjs";
import "./_libs/srvx.mjs";




import "./_libs/jose.mjs";
import "./_libs/ajv.mjs";
import "./_libs/fast-deep-equal.mjs";
import "./_libs/json-schema-traverse.mjs";
import "./_libs/fast-uri.mjs";
import "./_libs/radix-ui__react-select.mjs";
import "./_libs/radix-ui__number.mjs";
import "./_libs/radix-ui__react-collection.mjs";
import "./_libs/radix-ui__react-direction.mjs";
import "./_libs/radix-ui__react-popper.mjs";
import "./_libs/floating-ui__react-dom.mjs";
import "./_libs/floating-ui__dom.mjs";
import "./_libs/floating-ui__core.mjs";
import "./_libs/floating-ui__utils.mjs";
import "./_libs/radix-ui__react-arrow.mjs";
import "./_libs/@radix-ui/react-visually-hidden+[...].mjs";
createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => d).handler(createSsrRpc("d2e1213c3544f7340dfabd43af1807782b8200dca73791e700f656b3e8f54734"));
const savePerformanceNutritionPreferences = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => d).handler(createSsrRpc("0fd233469afb4c9e789b2f46298e54058c836b10b2984f60726f4840d088ea80"));
const GYM_OPTIONS = [{
  v: "full_gym",
  l: "Vollständiges Fitnessstudio"
}, {
  v: "limited_gym",
  l: "Eingeschränktes Fitnessstudio"
}, {
  v: "home_gym",
  l: "Home Gym"
}, {
  v: "no_gym",
  l: "Kein Gym"
}];
const GOAL_OPTIONS = [{
  v: "Speed",
  l: "Schnelligkeit"
}, {
  v: "Explosiveness",
  l: "Explosivität"
}, {
  v: "Strength",
  l: "Kraft"
}, {
  v: "Conditioning",
  l: "Kondition"
}, {
  v: "Robustness",
  l: "Verletzungsprävention / Robustheit"
}, {
  v: "Overall Athletic Development",
  l: "Athletische Grundlagen (Allround)"
}];
const ENERGY_SEX_OPTIONS = [{
  v: "MALE",
  l: "Männlich"
}, {
  v: "FEMALE",
  l: "Weiblich"
}, {
  v: "UNSPECIFIED",
  l: "Keine Angabe (Coach-Review nötig)"
}];
const BASELINE_ACTIVITY_OPTIONS = [{
  v: "MOSTLY_SEATED",
  l: "Überwiegend sitzend (Büro/Schule)"
}, {
  v: "MIXED",
  l: "Gemischt (teils sitzend, teils aktiv)"
}, {
  v: "PHYSICALLY_ACTIVE",
  l: "Körperlich aktiv (viel auf den Beinen)"
}, {
  v: "VERY_PHYSICALLY_ACTIVE",
  l: "Sehr körperlich aktiv (Bau/Handwerk)"
}];
const PERFORMANCE_NUTRITION_GOAL_OPTIONS = [{
  v: "FAT_LOSS",
  l: "Körperfett reduzieren"
}, {
  v: "MAINTENANCE",
  l: "Gewicht halten"
}, {
  v: "PERFORMANCE",
  l: "Leistung / Performance"
}, {
  v: "MUSCLE_GAIN",
  l: "Muskelaufbau"
}];
const FAVORITE_FOODS_CHIPS = ["Hähnchen", "Rind", "Pute", "Eier", "Skyr", "Fisch", "Reis", "Nudeln", "Kartoffeln", "Wraps", "Haferflocken", "Obst", "Gemüse", "Käse", "Nüsse", "Proteinpulver"];
const ALLERGY_CHIPS = ["Laktose", "Gluten", "Nüsse", "Soja", "Ei", "Fisch", "Meeresfrüchte"];
const INTOLERANCE_CHIPS = ["Fructose", "Histamin", "Sorbit", "FODMAP"];
const DIET_STYLE_OPTIONS = [{
  v: "omnivore",
  l: "Alles / Omnivor"
}, {
  v: "flexitarian",
  l: "Flexitarisch (selten Fleisch)"
}, {
  v: "pescetarian",
  l: "Pescetarisch (Fisch, kein Fleisch)"
}, {
  v: "vegetarian",
  l: "Vegetarisch"
}, {
  v: "vegan",
  l: "Vegan"
}, {
  v: "other",
  l: "Andere / Sonstige"
}];
const EATING_STYLE_OPTIONS = [{
  v: "meal_prep",
  l: "Meal Prep (viel vorkochen)"
}, {
  v: "fresh",
  l: "Frisch täglich zubereiten"
}, {
  v: "mixed",
  l: "Gemischt"
}];
const MEAL_PREP_STYLE_OPTIONS = [{
  v: "daily",
  l: "Täglich frisch kochen"
}, {
  v: "2_3_week",
  l: "2-3x pro Woche kochen"
}, {
  v: "meal_prep",
  l: "Meal Prep für die ganze Woche"
}, {
  v: "low_effort",
  l: "So wenig kochen wie möglich"
}];
function deriveEnergySex(gender) {
  if (gender === "male") return "MALE";
  if (gender === "female") return "FEMALE";
  return "UNSPECIFIED";
}
const STAFF_FUNCTION_OPTIONS_COACH = ["Head Coach", "Offensive Coordinator", "Defensive Coordinator", "Positionscoach Offense", "Positionscoach Defense", "Special Teams Coach", "Athletik- / Strength & Conditioning Coach", "Player Care / Medical", "Sonstige"];
const STAFF_FUNCTION_OPTIONS_ORG_ADMIN = ["Vereinsleitung", "1. Vorsitz", "2. Vorsitz", "Sportlicher Leiter", "Geschäftsstelle", "Sonstige"];
const STAFF_FUNCTION_OPTIONS_STAFF = ["Player Care / Medical", "Video-Analyst", "Team-Manager", "Sonstige"];
const DAYS = [{
  v: 1,
  l: "Mo"
}, {
  v: 2,
  l: "Di"
}, {
  v: 3,
  l: "Mi"
}, {
  v: 4,
  l: "Do"
}, {
  v: 5,
  l: "Fr"
}, {
  v: 6,
  l: "Sa"
}, {
  v: 0,
  l: "So"
}];
function OrgOnboardingDispatcher() {
  const {
    org
  } = Route$2n.useLoaderData();
  const {
    supabaseUser
  } = useSession();
  const navigate = useNavigate();
  const fetchCtx = useServerFn(getOrganizationContext);
  reactExports.useEffect(() => {
    if (!supabaseUser) navigate({
      to: "/$orgSlug",
      params: {
        orgSlug: org.slug
      },
      replace: true
    });
  }, [supabaseUser, org.slug, navigate]);
  const {
    data: ctx
  } = useQuery({
    queryKey: ["org-ctx", org.slug, supabaseUser?.id ?? "anon"],
    enabled: !!supabaseUser,
    queryFn: () => fetchCtx({
      data: {
        slug: org.slug
      }
    })
  });
  const flags = reactExports.useMemo(() => {
    if (!ctx) return null;
    return deriveOrgRole({
      membership: ctx.membership,
      staff: ctx.staff,
      is_super_admin: ctx.is_super_admin
    });
  }, [ctx]);
  reactExports.useEffect(() => {
    if (!ctx) return;
    if (!ctx.membership && !ctx.staff && !ctx.is_super_admin) {
      navigate({
        to: "/$orgSlug",
        params: {
          orgSlug: org.slug
        },
        replace: true
      });
    }
  }, [ctx, navigate, org.slug]);
  if (!ctx || !flags) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid min-h-screen place-items-center text-muted-foreground", children: "Laden…" });
  }
  if (flags.isPlayer) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx(AthleteOnboarding, { ctx });
  }
  if (flags.isAnyStaff) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx(StaffOnboarding, { ctx });
  }
  navigate({
    to: "/$orgSlug",
    params: {
      orgSlug: org.slug
    },
    replace: true
  });
  return null;
}
function AthleteOnboarding({
  ctx
}) {
  const {
    org
  } = Route$2n.useLoaderData();
  const {
    supabaseUser
  } = useSession();
  const navigate = useNavigate();
  const qc = useQueryClient();
  const complete = useServerFn(completeOrganizationOnboardingV2);
  const [displayName, setDisplayName] = reactExports.useState(ctx.profile?.display_name ?? "");
  const [birthdate, setBirthdate] = reactExports.useState(ctx.profile?.birthdate ?? "");
  const [heightCm, setHeightCm] = reactExports.useState(ctx.profile?.height_cm ? String(ctx.profile.height_cm) : "");
  const [weightKg, setWeightKg] = reactExports.useState("");
  const [teamId, setTeamId] = reactExports.useState("");
  const [primary, setPrimary] = reactExports.useState("");
  const [secondary, setSecondary] = reactExports.useState("");
  const [jersey, setJersey] = reactExports.useState("");
  const [gym, setGym] = reactExports.useState("");
  const [days, setDays] = reactExports.useState([]);
  const [limitations, setLimitations] = reactExports.useState("");
  const [goal, setGoal] = reactExports.useState("");
  const [energySex, setEnergySex] = reactExports.useState("");
  const [baselineActivity, setBaselineActivity] = reactExports.useState("");
  const [nutritionGoal, setNutritionGoal] = reactExports.useState("");
  const [favFoods, setFavFoods] = reactExports.useState([]);
  const [extraFavs, setExtraFavs] = reactExports.useState("");
  const [nogoFoods, setNogoFoods] = reactExports.useState([]);
  const [extraNogos, setExtraNogos] = reactExports.useState("");
  const [allergies, setAllergies] = reactExports.useState([]);
  const [extraAllergies, setExtraAllergies] = reactExports.useState("");
  const [intolerances, setIntolerances] = reactExports.useState([]);
  const [dietStyle, setDietStyle] = reactExports.useState("");
  const [dietNotes, setDietNotes] = reactExports.useState("");
  const [eatingStyle, setEatingStyle] = reactExports.useState("");
  const [mealPrepStyle, setMealPrepStyle] = reactExports.useState("");
  const [allergiesTouched, setAllergiesTouched] = reactExports.useState(false);
  const [intolerancesTouched, setIntolerancesTouched] = reactExports.useState(false);
  const savePrefs = useServerFn(savePerformanceNutritionPreferences);
  reactExports.useEffect(() => {
    const tm = ctx.team_membership;
    if (tm?.team_id) setTeamId(tm.team_id);
    else if (ctx.teams.length === 1) setTeamId(ctx.teams[0].id);
    if (tm?.position) setPrimary(tm.position);
    if (tm?.secondary_position) setSecondary(tm.secondary_position);
    if (tm?.jersey_number != null) setJersey(String(tm.jersey_number));
    if (tm?.gym_access) setGym(tm.gym_access);
    if (Array.isArray(tm?.available_training_days)) setDays(tm.available_training_days);
    if (tm?.limitations) setLimitations(tm.limitations);
    if (tm?.personal_goal) setGoal(tm.personal_goal);
    const g = ctx.profile?.gender ?? null;
    if (g) setEnergySex(deriveEnergySex(g));
  }, [ctx]);
  reactExports.useEffect(() => {
    let cancelled = false;
    (async () => {
      const {
        data: snp
      } = await supabase.from("smart_nutrition_profile").select("favorite_foods, extra_favorites, nogo_foods, extra_nogos, allergies, extra_allergies, intolerances, diet_style, diet_notes, eating_style, meal_prep_style").eq("user_id", supabaseUser?.id ?? "").maybeSingle();
      if (cancelled || !snp) return;
      const s = snp;
      if (Array.isArray(s.favorite_foods)) setFavFoods(s.favorite_foods);
      if (s.extra_favorites) setExtraFavs(s.extra_favorites);
      if (Array.isArray(s.nogo_foods)) setNogoFoods(s.nogo_foods);
      if (s.extra_nogos) setExtraNogos(s.extra_nogos);
      if (Array.isArray(s.allergies)) {
        setAllergies(s.allergies);
        setAllergiesTouched(true);
      }
      if (s.extra_allergies) setExtraAllergies(s.extra_allergies);
      if (Array.isArray(s.intolerances)) {
        setIntolerances(s.intolerances);
        setIntolerancesTouched(true);
      }
      if (s.diet_style) setDietStyle(s.diet_style);
      if (s.diet_notes) setDietNotes(s.diet_notes);
      if (s.eating_style) setEatingStyle(s.eating_style);
      if (s.meal_prep_style) setMealPrepStyle(s.meal_prep_style);
    })();
    return () => {
      cancelled = true;
    };
  }, [supabaseUser?.id]);
  const isGym = ctx.organization.organization_type === "fitness_studio";
  const save = useMutation({
    mutationFn: async () => {
      if (!displayName.trim()) throw new Error("Bitte Namen angeben.");
      if (!birthdate) throw new Error("Bitte Geburtsdatum angeben.");
      if (!heightCm || Number(heightCm) < 100) throw new Error("Bitte Größe in cm angeben.");
      if (!weightKg || Number(weightKg) < 30) throw new Error("Bitte aktuelles Gewicht in kg angeben.");
      if (!isGym) {
        if (!teamId) throw new Error("Bitte Team auswählen.");
        if (!primary) throw new Error("Bitte primäre Position angeben.");
      }
      if (!energySex) throw new Error("Bitte Angabe zum biologischen Geschlecht für die Energieberechnung.");
      if (!baselineActivity) throw new Error("Bitte Alltagsaktivität angeben.");
      if (!nutritionGoal) throw new Error("Bitte Ernährungsziel angeben.");
      if (!dietStyle) throw new Error("Bitte Ernährungsform angeben.");
      if (!mealPrepStyle) throw new Error("Bitte angeben, wie du kochen willst.");
      if (!allergiesTouched) throw new Error("Bitte bestätige, ob du Allergien hast (auch ohne Auswahl).");
      if (!intolerancesTouched) throw new Error("Bitte bestätige, ob du Unverträglichkeiten hast (auch ohne Auswahl).");
      await complete({
        data: {
          organization_id: ctx.organization.id,
          team_id: isGym ? teamId || null : teamId,
          primary_position: isGym ? null : primary,
          secondary_position: isGym ? null : secondary || null,
          jersey_number: isGym ? null : jersey ? Number(jersey) : null,
          gym_access: gym || null,
          available_training_days: days.length ? days : null,
          limitations: limitations || null,
          personal_goal: goal || null,
          display_name: displayName.trim(),
          birthdate,
          height_cm: Number(heightCm),
          weight_kg: Number(weightKg),
          sex_for_energy_calculation: energySex,
          baseline_daily_activity: baselineActivity,
          performance_nutrition_goal: nutritionGoal
        }
      });
      await savePrefs({
        data: {
          organizationId: ctx.organization.id,
          favorite_foods: favFoods,
          extra_favorites: extraFavs || null,
          nogo_foods: nogoFoods,
          extra_nogos: extraNogos || null,
          allergies,
          extra_allergies: extraAllergies || null,
          intolerances,
          diet_style: dietStyle,
          diet_notes: dietNotes || null,
          eating_style: eatingStyle || null,
          meal_prep_style: mealPrepStyle
        }
      });
      return {
        ok: true
      };
    },
    onSuccess: async () => {
      toast.success(`Willkommen bei ${org.name}!`);
      await qc.invalidateQueries({
        queryKey: ["entitlements"]
      });
      navigate({
        to: "/$orgSlug/home",
        params: {
          orgSlug: org.slug
        },
        replace: true
      });
    },
    onError: (e) => toast.error(e?.message ?? "Fehler beim Speichern")
  });
  const bg = org.primary_color ?? "#000000";
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "min-h-screen bg-background text-foreground", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mx-auto max-w-xl px-5 py-8 pb-32", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(OnboardingHeader, { title: org.name, subtitle: "Athleten-Onboarding" }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "mb-6 text-xs text-muted-foreground", children: [
      "Willkommen im ",
      org.name,
      "-Bereich. Bitte vervollständige deine Basisdaten sowie deine Position im Team."
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(SectionHeader, { children: "Basisdaten" }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid gap-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Name *", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: displayName, onChange: (e) => setDisplayName(e.target.value), placeholder: "Vor- und Nachname" }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Geburtsdatum *", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { type: "date", value: birthdate, onChange: (e) => setBirthdate(e.target.value) }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-2 gap-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Größe (cm) *", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { type: "number", inputMode: "numeric", value: heightCm, onChange: (e) => setHeightCm(e.target.value), placeholder: "z.B. 182" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Gewicht (kg) *", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { type: "number", inputMode: "decimal", step: "0.1", value: weightKg, onChange: (e) => setWeightKg(e.target.value), placeholder: "aktuell" }) })
      ] })
    ] }),
    isGym ? ctx.teams.length > 0 ? /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(SectionHeader, { className: "mt-6", children: "Gruppe (optional)" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid gap-4", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Gruppe", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Select, { value: teamId, onValueChange: setTeamId, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(SelectTrigger, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(SelectValue, { placeholder: "Optional — Gruppe auswählen" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(SelectContent, { children: ctx.teams.map((t) => /* @__PURE__ */ jsxRuntimeExports.jsx(SelectItem, { value: t.id, children: t.name }, t.id)) })
      ] }) }) })
    ] }) : null : /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(SectionHeader, { className: "mt-6", children: "Team & Position" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid gap-4", children: [
        ctx.teams.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Team *", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Select, { value: teamId, onValueChange: setTeamId, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(SelectTrigger, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(SelectValue, { placeholder: "Team auswählen" }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(SelectContent, { children: ctx.teams.map((t) => /* @__PURE__ */ jsxRuntimeExports.jsx(SelectItem, { value: t.id, children: t.name }, t.id)) })
        ] }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Primäre Position *", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: primary, onChange: (e) => setPrimary(e.target.value), placeholder: "z.B. Linebacker" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Zweitposition (optional)", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: secondary, onChange: (e) => setSecondary(e.target.value) }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Trikotnummer (optional)", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { type: "number", value: jersey, onChange: (e) => setJersey(e.target.value) }) })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(SectionHeader, { className: "mt-6", children: "Training" }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid gap-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Gym-Zugang", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Select, { value: gym, onValueChange: setGym, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(SelectTrigger, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(SelectValue, { placeholder: "Auswählen" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(SelectContent, { children: GYM_OPTIONS.map((o) => /* @__PURE__ */ jsxRuntimeExports.jsx(SelectItem, { value: o.v, children: o.l }, o.v)) })
      ] }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Verfügbare Athletik-Trainingstage", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex flex-wrap gap-1.5", children: DAYS.map((d) => {
        const on = days.includes(d.v);
        return /* @__PURE__ */ jsxRuntimeExports.jsx("button", { type: "button", onClick: () => setDays((cur) => cur.includes(d.v) ? cur.filter((x) => x !== d.v) : [...cur, d.v]), className: `rounded-md border px-3 py-1.5 text-xs font-semibold uppercase ${on ? "border-transparent text-white" : "border-border bg-card"}`, style: on ? {
          background: bg
        } : {}, children: d.l }, d.v);
      }) }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(Field, { label: "Aktuelle körperliche Einschränkungen (optional)", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Textarea, { value: limitations, onChange: (e) => setLimitations(e.target.value), placeholder: "Freitext — keine medizinische Diagnose.", rows: 3 }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-1 text-[10px] text-muted-foreground", children: "Hinweis: Keine medizinische Diagnosefunktion." })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Persönliches Athletik-Ziel", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Select, { value: goal, onValueChange: setGoal, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(SelectTrigger, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(SelectValue, { placeholder: "Ziel wählen" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(SelectContent, { children: GOAL_OPTIONS.map((o) => /* @__PURE__ */ jsxRuntimeExports.jsx(SelectItem, { value: o.v, children: o.l }, o.v)) })
      ] }) })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(SectionHeader, { className: "mt-6", children: "Ernährung & Aktivität" }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "mb-3 text-[11px] text-muted-foreground", children: [
      "Grundlage für dein persönliches Kalorien- und Makro-Ziel im ",
      org.name,
      "-Bereich. Diese Angaben fließen ausschließlich in die vereinsinterne Performance-Berechnung ein."
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid gap-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs(Field, { label: "Biologisches Geschlecht (für Energieberechnung) *", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Select, { value: energySex, onValueChange: setEnergySex, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(SelectTrigger, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(SelectValue, { placeholder: "Auswählen" }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(SelectContent, { children: ENERGY_SEX_OPTIONS.map((o) => /* @__PURE__ */ jsxRuntimeExports.jsx(SelectItem, { value: o.v, children: o.l }, o.v)) })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-1 text-[10px] text-muted-foreground", children: "Wird nur zur Berechnung des Energiebedarfs verwendet (DRI 2023)." })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Alltagsaktivität (ohne Football-/Athletik-Training) *", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Select, { value: baselineActivity, onValueChange: setBaselineActivity, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(SelectTrigger, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(SelectValue, { placeholder: "Auswählen" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(SelectContent, { children: BASELINE_ACTIVITY_OPTIONS.map((o) => /* @__PURE__ */ jsxRuntimeExports.jsx(SelectItem, { value: o.v, children: o.l }, o.v)) })
      ] }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Ernährungsziel *", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Select, { value: nutritionGoal, onValueChange: setNutritionGoal, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(SelectTrigger, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(SelectValue, { placeholder: "Auswählen" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(SelectContent, { children: PERFORMANCE_NUTRITION_GOAL_OPTIONS.map((o) => /* @__PURE__ */ jsxRuntimeExports.jsx(SelectItem, { value: o.v, children: o.l }, o.v)) })
      ] }) })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(SectionHeader, { className: "mt-6", children: "Ernährungsform" }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid gap-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Wie ernährst du dich? *", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Select, { value: dietStyle, onValueChange: setDietStyle, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(SelectTrigger, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(SelectValue, { placeholder: "Auswählen" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(SelectContent, { children: DIET_STYLE_OPTIONS.map((o) => /* @__PURE__ */ jsxRuntimeExports.jsx(SelectItem, { value: o.v, children: o.l }, o.v)) })
      ] }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Anmerkungen zur Ernährung (optional)", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Textarea, { value: dietNotes, onChange: (e) => setDietNotes(e.target.value), rows: 2, placeholder: "z.B. wenig Rotes Fleisch, kein Schweinefleisch..." }) })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(SectionHeader, { className: "mt-6", children: "Lieblingsfoods" }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid gap-3", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Was isst du besonders gerne?", children: /* @__PURE__ */ jsxRuntimeExports.jsx(ChipGrid, { items: FAVORITE_FOODS_CHIPS, selected: favFoods, onChange: setFavFoods, bg }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Weitere Lieblingsfoods (optional)", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Textarea, { value: extraFavs, onChange: (e) => setExtraFavs(e.target.value), rows: 2, placeholder: "Kommagetrennt: z.B. Süßkartoffel, Linsen, Tofu" }) })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(SectionHeader, { className: "mt-6", children: "Was du NICHT essen willst" }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid gap-3", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "No-Gos aus der Liste", children: /* @__PURE__ */ jsxRuntimeExports.jsx(ChipGrid, { items: FAVORITE_FOODS_CHIPS, selected: nogoFoods, onChange: setNogoFoods, bg }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Weitere No-Gos (optional)", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Textarea, { value: extraNogos, onChange: (e) => setExtraNogos(e.target.value), rows: 2, placeholder: "Kommagetrennt: z.B. Rosenkohl, Sellerie" }) })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(SectionHeader, { className: "mt-6", children: "Allergien & Unverträglichkeiten" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mb-3 text-[11px] text-muted-foreground", children: 'Sicherheitsrelevant — dein Plan wird streng gefiltert. Wenn du keine hast, wähle einfach nichts aus und tippe auf „Keine Allergien / Unverträglichkeiten".' }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid gap-3", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Allergien", children: /* @__PURE__ */ jsxRuntimeExports.jsx(ChipGrid, { items: ALLERGY_CHIPS, selected: allergies, onChange: (v) => {
        setAllergies(v);
        setAllergiesTouched(true);
      }, bg }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Weitere Allergien (optional)", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: extraAllergies, onChange: (e) => setExtraAllergies(e.target.value), placeholder: "Kommagetrennt" }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Unverträglichkeiten", children: /* @__PURE__ */ jsxRuntimeExports.jsx(ChipGrid, { items: INTOLERANCE_CHIPS, selected: intolerances, onChange: (v) => {
        setIntolerances(v);
        setIntolerancesTouched(true);
      }, bg }) }),
      (!allergiesTouched || !intolerancesTouched) && /* @__PURE__ */ jsxRuntimeExports.jsx("button", { type: "button", onClick: () => {
        setAllergies([]);
        setAllergiesTouched(true);
        setIntolerances([]);
        setIntolerancesTouched(true);
      }, className: "mt-1 self-start rounded-md border border-border bg-card px-3 py-1.5 text-xs font-semibold", children: "Keine Allergien / Unverträglichkeiten" })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(SectionHeader, { className: "mt-6", children: "Essalltag & Meal Prep" }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid gap-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Wie möchtest du deine Mahlzeiten vorbereiten? *", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Select, { value: mealPrepStyle, onValueChange: setMealPrepStyle, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(SelectTrigger, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(SelectValue, { placeholder: "Auswählen" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(SelectContent, { children: MEAL_PREP_STYLE_OPTIONS.map((o) => /* @__PURE__ */ jsxRuntimeExports.jsx(SelectItem, { value: o.v, children: o.l }, o.v)) })
      ] }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Grundsätzlicher Essalltag (optional)", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Select, { value: eatingStyle, onValueChange: setEatingStyle, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(SelectTrigger, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(SelectValue, { placeholder: "Auswählen" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(SelectContent, { children: EATING_STYLE_OPTIONS.map((o) => /* @__PURE__ */ jsxRuntimeExports.jsx(SelectItem, { value: o.v, children: o.l }, o.v)) })
      ] }) })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { size: "lg", className: "mt-8 w-full text-white", style: {
      background: bg
    }, disabled: save.isPending, onClick: () => save.mutate(), children: save.isPending ? "Speichern…" : "Onboarding abschließen" })
  ] }) });
}
function StaffOnboarding({
  ctx
}) {
  const {
    org
  } = Route$2n.useLoaderData();
  const navigate = useNavigate();
  const qc = useQueryClient();
  const complete = useServerFn(completeStaffOrganizationOnboarding);
  const [displayName, setDisplayName] = reactExports.useState(ctx.profile?.display_name ?? "");
  const [birthdate, setBirthdate] = reactExports.useState(ctx.profile?.birthdate ?? "");
  const [nickname, setNickname] = reactExports.useState(ctx.profile?.nickname ?? "");
  const [functionLabel, setFunctionLabel] = reactExports.useState(ctx.staff?.function_label ?? "");
  const [functionCustom, setFunctionCustom] = reactExports.useState("");
  const staffOptions = reactExports.useMemo(() => {
    const role = ctx.staff?.role;
    if (role === "organization_admin") return STAFF_FUNCTION_OPTIONS_ORG_ADMIN;
    if (role === "coach") return STAFF_FUNCTION_OPTIONS_COACH;
    return STAFF_FUNCTION_OPTIONS_STAFF;
  }, [ctx.staff?.role]);
  const save = useMutation({
    mutationFn: async () => {
      if (!displayName.trim()) throw new Error("Bitte Namen angeben.");
      const label = functionLabel === "Sonstige" ? functionCustom.trim() || null : functionLabel || null;
      return complete({
        data: {
          organization_id: ctx.organization.id,
          display_name: displayName.trim(),
          nickname: nickname.trim() || null,
          birthdate: birthdate || null,
          function_label: label
        }
      });
    },
    onSuccess: async () => {
      toast.success(`Willkommen bei ${org.name}!`);
      await qc.invalidateQueries({
        queryKey: ["entitlements"]
      });
      navigate({
        to: "/coach/teams/$orgId",
        params: {
          orgId: ctx.organization.id
        },
        replace: true
      });
    },
    onError: (e) => toast.error(e?.message ?? "Fehler beim Speichern")
  });
  const bg = org.primary_color ?? "#000000";
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "min-h-screen bg-background text-foreground", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mx-auto max-w-xl px-5 py-8 pb-32", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(OnboardingHeader, { title: org.name, subtitle: "Staff-Onboarding" }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "mb-6 text-xs text-muted-foreground", children: [
      "Willkommen im Coach-Bereich von ",
      org.name,
      ". Bitte hinterlege deine Basisdaten und deine Rolle im Verein. Es werden keine athletischen Werte (Größe, Gewicht, Trainingsziele) erfasst – dieser Bereich ist rein organisatorisch."
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(SectionHeader, { children: "Basisdaten" }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid gap-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Name *", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: displayName, onChange: (e) => setDisplayName(e.target.value), placeholder: "Vor- und Nachname" }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Rufname (optional)", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: nickname, onChange: (e) => setNickname(e.target.value), placeholder: "wie du im Team gerufen wirst" }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Geburtsdatum (optional)", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { type: "date", value: birthdate, onChange: (e) => setBirthdate(e.target.value) }) })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(SectionHeader, { className: "mt-6", children: "Funktion im Team" }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid gap-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs(Field, { label: "Rolle / Funktion", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Select, { value: functionLabel, onValueChange: setFunctionLabel, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(SelectTrigger, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(SelectValue, { placeholder: "Auswählen" }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(SelectContent, { children: staffOptions.map((o) => /* @__PURE__ */ jsxRuntimeExports.jsx(SelectItem, { value: o, children: o }, o)) })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-1 text-[10px] text-muted-foreground", children: "Nur zur Anzeige im Coach-Cockpit. Deine Berechtigungen werden dadurch nicht verändert." })
      ] }),
      functionLabel === "Sonstige" && /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Deine Funktion", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: functionCustom, onChange: (e) => setFunctionCustom(e.target.value), placeholder: "z.B. Video-Analyst" }) })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { size: "lg", className: "mt-8 w-full text-white", style: {
      background: bg
    }, disabled: save.isPending, onClick: () => save.mutate(), children: save.isPending ? "Speichern…" : "Onboarding abschließen" })
  ] }) });
}
function OnboardingHeader({
  title,
  subtitle
}) {
  const {
    org
  } = Route$2n.useLoaderData();
  const bg = org.primary_color ?? "#000000";
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-6 flex items-center gap-3", children: [
    org.logo_url ? /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: org.logo_url, alt: title, className: "h-12 w-12 rounded-full object-cover" }) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid h-12 w-12 place-items-center rounded-full text-white text-sm font-bold", style: {
      background: bg
    }, children: title.slice(0, 2).toUpperCase() }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[10px] font-bold uppercase tracking-[0.2em] text-muted-foreground", children: subtitle }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "font-display text-2xl font-bold", children: title })
    ] })
  ] });
}
function SectionHeader({
  children,
  className
}) {
  return /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: `mb-3 text-[11px] font-bold uppercase tracking-[0.2em] text-muted-foreground ${className ?? ""}`, children });
}
function Field({
  label,
  children
}) {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { className: "text-[10px] font-bold uppercase tracking-wider text-muted-foreground", children: label }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-1.5", children })
  ] });
}
function ChipGrid({
  items,
  selected,
  onChange,
  bg
}) {
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex flex-wrap gap-1.5", children: items.map((it) => {
    const on = selected.includes(it);
    return /* @__PURE__ */ jsxRuntimeExports.jsx("button", { type: "button", onClick: () => onChange(on ? selected.filter((x) => x !== it) : [...selected, it]), className: `rounded-md border px-3 py-1.5 text-xs font-semibold ${on ? "border-transparent text-white" : "border-border bg-card"}`, style: on ? {
      background: bg
    } : {}, children: it }, it);
  }) });
}
export {
  OrgOnboardingDispatcher as component
};
