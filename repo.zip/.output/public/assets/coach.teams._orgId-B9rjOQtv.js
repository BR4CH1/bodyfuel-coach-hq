import{b6 as s,j as t,b7 as a,O as e}from"./index-BPKrCpKP.js";function r(){const{orgId:o}=s.useParams();return t.jsx(a,{orgId:o})}const c=()=>t.jsx(e,{});export{r as CoachOrgDetail,c as component};
