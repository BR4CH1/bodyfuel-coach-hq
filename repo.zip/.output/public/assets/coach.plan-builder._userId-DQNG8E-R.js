import{j as t}from"./index-BPKrCpKP.js";const e=()=>t.jsx("div",{className:"p-6 text-sm text-muted-foreground",children:"Seite nicht gefunden."});export{e as notFoundComponent};
