import{N as e,Q as a,V as d}from"./index-BPKrCpKP.js";const r=e({method:"POST"}).middleware([a]).handler(d("08ee886261d60b62ad0915f40669c3b5d1562fea4d65c23d3807d411d1d77e31"));export{r as l};
