import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { AppLayout } from "@/components/bodyfuel/AppLayout";
import { createCustomer } from "@/lib/coaching.functions";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useFormDraft, clearFormDraft } from "@/hooks/use-form-draft";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export const Route = createFileRoute("/coach/customers/new")({
  head: () => ({ meta: [{ title: "Neuer Kunde — BODYFUEL" }] }),
  component: () => (
    <AppLayout>
      <NewCustomerForm />
    </AppLayout>
  ),
});

const DEFAULT_PRICE = { smart: 14.99, coaching: 69, starter: 79, premium: 199, trial: 0, free: 0 } as const;

type PackageOption = "smart" | "coaching" | "starter" | "premium" | "trial" | "free";

function NewCustomerForm() {
  const fn = useServerFn(createCustomer);
  const navigate = useNavigate();
  const [busy, setBusy] = useState(false);
  const [form, setForm] = useState({
    first_name: "",
    last_name: "",
    email: "",
    phone: "",
    package: "coaching" as PackageOption,
    price_eur: 69,
    start_date: new Date().toISOString().slice(0, 10),
    end_date: new Date(Date.now() + 30 * 86400000).toISOString().slice(0, 10),
    trial_days: 7,
    notes: "",
    bulls: false,
    skip_invite: false,
  });
  const isTrial = form.package === "trial";
  const isFree = form.package === "free";

  const DRAFT_KEY = "bf.coach.newCustomer.v1";
  useFormDraft(DRAFT_KEY, { form }, (d) => {
    if (d.form && typeof d.form === "object") {
      setForm((cur) => ({ ...cur, ...(d.form as typeof cur) }));
    }
  });

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.first_name || !form.last_name || !form.email) {
      return toast.error("Vorname, Nachname und E-Mail erforderlich.");
    }
    setBusy(true);
    try {
      const startMs = new Date(form.start_date).getTime();
      const endMs = new Date(form.end_date).getTime();
      const duration_days = Math.max(
        1,
        Math.round((endMs - startMs) / 86400000),
      );
      await fn({ data: { ...form, duration_days, origin: window.location.origin } });
      clearFormDraft(DRAFT_KEY);
      toast.success(
        form.skip_invite
          ? "Account angelegt — keine Einladung verschickt."
          : isFree
            ? "Free-User angelegt — Einladung verschickt."
            : isTrial
              ? "Trial-Kunde angelegt — Einladung verschickt."
              : "Kunde angelegt — Einladung verschickt.",
      );
      navigate({ to: "/coach/customers" });
    } catch (err) {
      toast.error((err as Error).message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="mx-auto max-w-2xl space-y-6">
      <div>
        <p className="text-xs uppercase tracking-[0.2em] text-muted-foreground">Coach</p>
        <h1 className="font-display text-3xl font-bold">Neuer Kunde</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Der Kunde erhält automatisch eine E-Mail mit Einladungslink.
        </p>
      </div>

      <form onSubmit={submit} className="space-y-5 rounded-2xl border border-border bg-card p-6">
        <div className="grid gap-4 sm:grid-cols-2">
          <div className="space-y-2">
            <Label>Vorname *</Label>
            <Input
              value={form.first_name}
              onChange={(e) => setForm({ ...form, first_name: e.target.value })}
              required
            />
          </div>
          <div className="space-y-2">
            <Label>Nachname *</Label>
            <Input
              value={form.last_name}
              onChange={(e) => setForm({ ...form, last_name: e.target.value })}
              required
            />
          </div>
        </div>

        <div className="grid gap-4 sm:grid-cols-2">
          <div className="space-y-2">
            <Label>E-Mail *</Label>
            <Input
              type="email"
              value={form.email}
              onChange={(e) => setForm({ ...form, email: e.target.value })}
              required
            />
          </div>
        </div>

        <div className="space-y-2">
          <Label>Telefon</Label>
          <Input
            value={form.phone}
            onChange={(e) => setForm({ ...form, phone: e.target.value })}
          />
        </div>

        <div className="grid gap-4 sm:grid-cols-2">
          <div className="space-y-2">
            <Label>Paket</Label>
            <Select
              value={form.package}
              onValueChange={(v) =>
                setForm({
                  ...form,
                  package: v as PackageOption,
                  price_eur: DEFAULT_PRICE[v as keyof typeof DEFAULT_PRICE],
                })
              }
            >
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="free">Free (Tracker)</SelectItem>
                <SelectItem value="trial">Trial (7-Tage-Test)</SelectItem>
                <SelectItem value="smart">BodyFuel Smart (14,99 €)</SelectItem>
                <SelectItem value="coaching">BodyFuel Coaching (69 €)</SelectItem>
              </SelectContent>
            </Select>
          </div>
          {!isTrial && !isFree && (
            <div className="space-y-2">
              <Label>Individueller Preis (€)</Label>
              <Input
                type="number"
                step="0.01"
                value={form.price_eur}
                onChange={(e) => setForm({ ...form, price_eur: Number(e.target.value) })}
                required
              />
            </div>
          )}
        </div>

        {isFree && (
          <p className="rounded-xl border border-border bg-secondary/30 p-3 text-xs text-muted-foreground">
            Free-User erhalten Zugriff auf den Tracker (Ernährung, Wasser, Gewicht, Aktivität, Punkte & Level). Kein Paket, keine Rechnung.
          </p>
        )}

        {isFree ? null : isTrial ? (
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-2">
              <Label>Trial-Dauer (Tage)</Label>
              <Input
                type="number"
                min={1}
                max={365}
                value={form.trial_days}
                onChange={(e) =>
                  setForm({
                    ...form,
                    trial_days: Math.max(1, Math.min(365, Number(e.target.value) || 1)),
                  })
                }
              />
              <p className="text-[11px] text-muted-foreground">
                Kunde erhält Trial-Zugang. Kein Paket / keine Rechnung.
              </p>
            </div>
          </div>
        ) : (
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-2">
              <Label>Startdatum</Label>
              <Input
                type="date"
                value={form.start_date}
                onChange={(e) => setForm({ ...form, start_date: e.target.value })}
              />
            </div>
            <div className="space-y-2">
              <Label>Enddatum</Label>
              <Input
                type="date"
                min={form.start_date}
                value={form.end_date}
                onChange={(e) => setForm({ ...form, end_date: e.target.value })}
              />
              <p className="text-[11px] text-muted-foreground">
                Die Laufzeit ergibt sich aus Start- und Enddatum.
              </p>
            </div>
          </div>
        )}

        <div className="space-y-2">
          <Label>Notizen</Label>
          <Textarea
            rows={3}
            value={form.notes}
            onChange={(e) => setForm({ ...form, notes: e.target.value })}
          />
        </div>

        <label className="flex items-start gap-3 rounded-xl border border-border bg-secondary/30 p-3 cursor-pointer">
          <input
            type="checkbox"
            checked={form.bulls}
            onChange={(e) => setForm({ ...form, bulls: e.target.checked })}
            className="mt-0.5 h-4 w-4"
          />
          <div>
            <div className="text-sm font-semibold">Bulls Performance Hub freischalten</div>
            <div className="text-xs text-muted-foreground">
              Spieler der Coesfeld Bulls erhalten Zugriff auf den kostenlosen Bulls-Bereich.
            </div>
          </div>
        </label>

        <label className="flex items-start gap-3 rounded-xl border border-border bg-secondary/30 p-3 cursor-pointer">
          <input
            type="checkbox"
            checked={form.skip_invite}
            onChange={(e) => setForm({ ...form, skip_invite: e.target.checked })}
            className="mt-0.5 h-4 w-4"
          />
          <div>
            <div className="text-sm font-semibold">Ohne Einladung anlegen (still)</div>
            <div className="text-xs text-muted-foreground">
              Für Influencer / Test-Accounts: Account wird angelegt, keine E-Mail verschickt. Das gewählte Paket wird automatisch <strong>kostenlos für 30 Tage</strong> freigeschaltet — keine Zahlung nötig. Passwort kannst du später per Reset-Link teilen.
            </div>
          </div>
        </label>

        <Button
          type="submit"
          disabled={busy}
          className="w-full bg-gradient-gold text-primary-foreground"
        >
          {busy ? "Lege an …" : form.skip_invite ? "Account still anlegen" : "Kunde anlegen & Einladung senden"}
        </Button>
      </form>
    </div>
  );
}
